-- -----------------------------
-- YzmCMS MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : hccms
-- 
-- Part : #1
-- Date : 2022-11-28 11:20:57
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `hc_admin`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin`;
CREATE TABLE `hc_admin` (
  `adminid` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `adminname` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `rolename` varchar(30) NOT NULL DEFAULT '',
  `realname` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(30) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `loginip` varchar(15) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `errnum` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addpeople` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin`
-- -----------------------------
INSERT INTO `hc_admin` VALUES ('1','admin','ffe317ecad2405070e6f5ffefb3a38a5','1','超级管理员','','','','1669605399','127.0.0.1','1665387014','','创始人');

-- -----------------------------
-- Table structure for `hc_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_log`;
CREATE TABLE `hc_admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(15) NOT NULL DEFAULT '',
  `action` varchar(20) NOT NULL DEFAULT '',
  `querystring` varchar(255) NOT NULL DEFAULT '',
  `adminid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adminname` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `logtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `logtime` (`logtime`),
  KEY `adminid` (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin_log`
-- -----------------------------
INSERT INTO `hc_admin_log` VALUES ('1','admin','index','清除错误日志','1','admin','127.0.0.1','1667532510');

-- -----------------------------
-- Table structure for `hc_admin_login_log`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_login_log`;
CREATE TABLE `hc_admin_login_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adminname` varchar(30) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `loginip` varchar(15) NOT NULL DEFAULT '',
  `address` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `loginresult` tinyint(1) NOT NULL DEFAULT '0' COMMENT '登录结果1为登录成功0为登录失败',
  `cause` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `admin_index` (`adminname`,`loginresult`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin_login_log`
-- -----------------------------
INSERT INTO `hc_admin_login_log` VALUES ('1','admin','1665387037','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('2','admin','1665451075','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('3','admin','1665711596','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('4','admin','1665814065','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('5','admin','1665814617','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('6','admin','1665968920','127.0.0.1','','a11523518','','密码错误！');
INSERT INTO `hc_admin_login_log` VALUES ('7','admin','1665968932','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('8','admin','1665973667','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('9','admin','1666079104','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('10','admin','1666141626','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('11','admin','1667394060','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('12','admin','1667407867','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('13','admin','1667441848','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('14','admin','1667528430','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('15','pangbo','1667784103','127.0.0.1','','a11523518','','该用户不存在！');
INSERT INTO `hc_admin_login_log` VALUES ('16','pangbo','1667784112','127.0.0.1','','a11523518','','该用户不存在！');
INSERT INTO `hc_admin_login_log` VALUES ('17','pangbo','1667784123','127.0.0.1','','a11523518','','该用户不存在！');
INSERT INTO `hc_admin_login_log` VALUES ('18','admin','1667784144','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('19','admin','1667884305','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('20','admin','1667980587','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('21','admin','1668043526','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('22','pangbo','1668130283','127.0.0.1','','123456','','该用户不存在！');
INSERT INTO `hc_admin_login_log` VALUES ('23','pangbo','1668130321','127.0.0.1','','123456','','该用户不存在！');
INSERT INTO `hc_admin_login_log` VALUES ('24','admin','1668130329','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('25','pangbo','1668391082','127.0.0.1','','123456','','该用户不存在！');
INSERT INTO `hc_admin_login_log` VALUES ('26','admin','1668391089','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('27','admin','1668475032','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('28','admin','1668562495','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('29','admin','1668738317','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('30','admin','1669018284','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('31','admin','1669187901','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('32','admin','1669257958','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('33','admin','1669356915','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('34','admin','1669357904','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('35','admin','1669358080','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('36','admin','1669365242','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('37','admin','1669365523','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('38','admin','1669605399','127.0.0.1','','','1','登录成功！');

-- -----------------------------
-- Table structure for `hc_admin_role`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_role`;
CREATE TABLE `hc_admin_role` (
  `roleid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `rolename` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleid`),
  KEY `disabled` (`disabled`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin_role`
-- -----------------------------
INSERT INTO `hc_admin_role` VALUES ('1','超级管理员','超级管理员','1','');
INSERT INTO `hc_admin_role` VALUES ('2','总编','总编','1','');
INSERT INTO `hc_admin_role` VALUES ('3','发布人员','发布人员','1','');

-- -----------------------------
-- Table structure for `hc_admin_role_priv`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_role_priv`;
CREATE TABLE `hc_admin_role_priv` (
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL DEFAULT '',
  `c` char(20) NOT NULL DEFAULT '',
  `a` char(30) NOT NULL DEFAULT '',
  `data` char(100) NOT NULL DEFAULT '',
  KEY `roleid` (`roleid`,`m`,`c`,`a`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_adver`
-- -----------------------------
DROP TABLE IF EXISTS `hc_adver`;
CREATE TABLE `hc_adver` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1文字2代码3图片',
  `title` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `text` varchar(200) NOT NULL DEFAULT '',
  `img` varchar(200) NOT NULL DEFAULT '',
  `code` text NOT NULL,
  `describe` varchar(250) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_all_content`
-- -----------------------------
DROP TABLE IF EXISTS `hc_all_content`;
CREATE TABLE `hc_all_content` (
  `allid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `modelid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(30) NOT NULL DEFAULT '',
  `title` varchar(150) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`allid`),
  KEY `userid_index` (`userid`,`issystem`,`status`),
  KEY `modelid_index` (`modelid`,`id`),
  KEY `status` (`siteid`,`status`),
  KEY `issystem` (`siteid`,`issystem`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_all_content`
-- -----------------------------
INSERT INTO `hc_all_content` VALUES ('53','','2','11','26','1','admin','iSLA1300D 规格','1665392990','1669194720','http://localhost:91/dayinshebei/26.html','/uploads/202211/10/221110032746776.png','1','1');
INSERT INTO `hc_all_content` VALUES ('67','','2','12','35','1','admin','加工中心TL-1160VMC-L','1668069551','1668069672','http://localhost:91/jijiagongshebei/35.html','/uploads/202211/10/221110044036463.png','1','1');
INSERT INTO `hc_all_content` VALUES ('3','','2','24','1','1','admin','3D打印样式测试','1665392990','1667802434','http://localhost:91/chunjixiejiagong/1.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('54','','2','25','27','1','admin','3D打印样式测试','1665392990','1667802418','http://localhost:91/jingmi3ddayin/27.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('55','','2','25','28','1','admin','3D打印样式测试','1665392990','1667802409','http://localhost:91/jingmi3ddayin/28.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('56','','2','7','29','1','admin','转向总成部件(成熟工艺案例)','1665392990','1668413028','http://localhost:91/qichelingbujian/29.html','/uploads/202211/10/221110054539675.png','1','1');
INSERT INTO `hc_all_content` VALUES ('57','','2','7','30','1','admin','羊角总成部件(成熟工艺案例)','1665392990','1668413018','http://localhost:91/qichelingbujian/30.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('58','','2','42','31','1','admin','变速箱','1665392990','1668073398','http://localhost:91/cndjiagong/31.html','/uploads/202211/10/221110054300918.png','1','1');
INSERT INTO `hc_all_content` VALUES ('59','','2','47','32','1','admin','复膜设备','1665392990','1669356995','http://localhost:91/qitashebei/32.html','/uploads/202211/25/221125021619238.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('60','','2','11','33','1','admin','惠普4200尼龙打印机','1665392990','1668067951','http://localhost:91/dayinshebei/33.html','/uploads/202211/10/221110041042965.png','1','1');
INSERT INTO `hc_all_content` VALUES ('61','','2','11','34','1','admin','iSLM420DN 规格','1665392990','1669194450','http://localhost:91/dayinshebei/34.html','/uploads/202211/10/221110034553991.png','1','1');
INSERT INTO `hc_all_content` VALUES ('68','','2','12','36','1','admin','加工中心TL-850VMC-L','1668069682','1668069718','http://localhost:91/jijiagongshebei/36.html','/uploads/202211/10/221110044149118.png','1','1');
INSERT INTO `hc_all_content` VALUES ('69','','2','12','37','1','admin','CK6160数控车床','1668069752','1668069786','http://localhost:91/jijiagongshebei/37.html','/uploads/202211/10/221110044254131.png','1','1');
INSERT INTO `hc_all_content` VALUES ('70','','2','12','38','1','admin','数控车床2SK5OP','1668069788','1668069818','http://localhost:91/jijiagongshebei/38.html','/uploads/202211/10/221110044331585.png','1','1');
INSERT INTO `hc_all_content` VALUES ('71','','2','12','39','1','admin','五轴联动加工中心','1668069840','1669259202','http://localhost:91/jijiagongshebei/39.html','/uploads/202211/10/221110044420596.png','1','1');
INSERT INTO `hc_all_content` VALUES ('72','','2','42','40','1','admin','CNC加工1','1668073197','1668392536','http://localhost:91/cndjiagong/40.html','/uploads/202211/10/221110054021213.png','1','1');
INSERT INTO `hc_all_content` VALUES ('73','','2','42','41','1','admin','CNC加工2','1668073335','1668392526','http://localhost:91/cndjiagong/41.html','/uploads/202211/10/221110054224636.png','1','1');
INSERT INTO `hc_all_content` VALUES ('74','','2','42','42','1','admin','底盘零部件','1668073405','1668073456','http://localhost:91/cndjiagong/42.html','/uploads/202211/10/221110054342143.png','1','1');
INSERT INTO `hc_all_content` VALUES ('75','','2','42','43','1','admin','机器人手臂','1668073477','1668073500','http://localhost:91/cndjiagong/43.html','/uploads/202211/10/221110054449118.png','1','1');
INSERT INTO `hc_all_content` VALUES ('76','','2','42','44','1','admin','减速机壳体','1668073504','1668073525','http://localhost:91/cndjiagong/44.html','/uploads/202211/10/221110054517905.png','1','1');
INSERT INTO `hc_all_content` VALUES ('77','','2','42','45','1','admin','汽车变速箱部件','1668073527','1668073545','http://localhost:91/cndjiagong/45.html','/uploads/202211/10/221110054539675.png','1','1');
INSERT INTO `hc_all_content` VALUES ('78','','2','42','46','1','admin','三项机电壳体','1668073547','1668393336','http://localhost:91/cndjiagong/46.html','/uploads/202211/10/221110054604637.png','1','1');
INSERT INTO `hc_all_content` VALUES ('79','','2','42','47','1','admin','汽车转向零部','1668073618','1668073636','http://localhost:91/cndjiagong/47.html','/uploads/202211/10/221110054710880.png','1','1');
INSERT INTO `hc_all_content` VALUES ('80','','2','42','48','1','admin','CNC加工10','1668073638','1668392516','http://localhost:91/cndjiagong/48.html','/uploads/202211/10/221110054736408.png','1','1');
INSERT INTO `hc_all_content` VALUES ('44','','1','52','19','1','admin','2018年12月','1667787047','1667787297','http://localhost:91/Companyhonor/19.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('45','','1','52','20','1','admin','2019年3月','1667787073','1667787281','http://localhost:91/Companyhonor/20.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('46','','1','52','21','1','admin','2019年10月','1667787090','1667787105','http://localhost:91/Companyhonor/21.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('47','','1','52','22','1','admin','2020年3月','1667787110','1667787126','http://localhost:91/Companyhonor/22.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('48','','1','52','23','1','admin','2020年5月','1667787128','1667787149','http://localhost:91/Companyhonor/23.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('35','','1','53','10','1','admin','江苏3D能打印什么？','1667469451','1668564174','http://localhost:91/xinwenzhongxin/10.html','/uploads/202211/16/221116100215445.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('36','','1','53','11','1','admin','江苏3D能打印什么？','1667469451','1668564156','http://localhost:91/xinwenzhongxin/11.html','/uploads/202211/16/221116100234144.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('37','','1','53','12','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/12.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('38','','1','53','13','1','admin','江苏3D能打印什么？','1667469451','1668564145','http://localhost:91/xinwenzhongxin/13.html','/uploads/202211/16/221116100224272.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('39','','1','53','14','1','admin','江苏3D能打印什么？','1667469451','1668564200','http://localhost:91/xinwenzhongxin/14.html','/uploads/202211/16/221116100204274.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('40','','1','53','15','1','admin','江苏3D能打印什么？','1667469451','1668564126','http://localhost:91/xinwenzhongxin/15.html','/uploads/202211/16/221116100204274.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('49','','1','52','24','1','admin','2021年7月','1667787153','1667787165','http://localhost:91/Companyhonor/24.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('50','','1','52','25','1','admin','2021年8月','1667787170','1667787186','http://localhost:91/Companyhonor/25.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('51','','1','52','26','1','admin','2021年10月','1667787190','1667787205','http://localhost:91/Companyhonor/26.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('52','','1','52','27','1','admin','2022年5月','1667787210','1667787227','http://localhost:91/Companyhonor/27.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('81','','2','42','49','1','admin','CNC加工11','1668073666','1668392506','http://localhost:91/cndjiagong/49.html','/uploads/202211/10/221110054800404.png','1','1');
INSERT INTO `hc_all_content` VALUES ('82','','2','42','50','1','admin','羊角总成部件','1668073691','1668073708','http://localhost:91/cndjiagong/50.html','/uploads/202211/10/221110054821295.png','1','1');
INSERT INTO `hc_all_content` VALUES ('83','','2','42','51','1','admin','CNC加工13','1668073710','1668392496','http://localhost:91/cndjiagong/51.html','/uploads/202211/10/221110054846301.png','1','1');
INSERT INTO `hc_all_content` VALUES ('84','','2','42','52','1','admin','R系列转向机壳','1668073735','1668132491','http://localhost:91/cndjiagong/52.html','/uploads/202211/10/221110054907456.png','1','1');
INSERT INTO `hc_all_content` VALUES ('85','','2','13','53','1','admin','2.5次元影像测量仪','1668074772','1668074805','http://localhost:91/jianceshebei/53.html','/uploads/202211/10/221110060636790.png','1','1');
INSERT INTO `hc_all_content` VALUES ('86','','2','13','54','1','admin','三坐标测量仪','1668074807','1668074933','http://localhost:91/jianceshebei/54.html','/uploads/202211/10/221110060656312.png','1','1');
INSERT INTO `hc_all_content` VALUES ('87','','2','8','55','1','admin','薄壁产品零部件(成熟工艺案例)','1668132803','1668413384','http://localhost:91/hangkonghang/55.html','/uploads/202211/11/221111101341959.png','1','1');
INSERT INTO `hc_all_content` VALUES ('88','','2','9','56','1','admin','通讯产品零部件(成熟工艺案例)','1668132916','1668413581','http://localhost:91/jungong/56.html','/uploads/202211/11/221111101341959.png','1','1');
INSERT INTO `hc_all_content` VALUES ('89','','2','26','57','1','admin','医疗','1668133108','1668133160','http://localhost:91/yiliao/57.html','/uploads/202211/11/221111101903555.png','1','1');
INSERT INTO `hc_all_content` VALUES ('90','','2','27','58','1','admin','机构复杂零件1','1668133108','1668133226','http://localhost:91/jigoufuza/58.html','/uploads/202211/11/221111101903555.png','1','1');
INSERT INTO `hc_all_content` VALUES ('91','','2','28','59','1','admin','摩擦焊接零件1','1668133108','1668133251','http://localhost:91/bobimocahan/59.html','/uploads/202211/11/221111101903555.png','1','1');
INSERT INTO `hc_all_content` VALUES ('92','','2','43','60','1','admin','1','1668133375','1668133475','http://localhost:91/slaguangguhuadayinchanpin/60.html','/uploads/202211/11/221111102342177.png','1','1');
INSERT INTO `hc_all_content` VALUES ('93','','2','43','61','1','admin','2','1668133519','1668133562','http://localhost:91/slaguangguhuadayinchanpin/61.html','/uploads/202211/11/221111102524812.png','1','1');
INSERT INTO `hc_all_content` VALUES ('94','','2','43','62','1','admin','3','1668133574','1668133593','http://localhost:91/slaguangguhuadayinchanpin/62.html','/uploads/202211/11/221111102623379.png','1','1');
INSERT INTO `hc_all_content` VALUES ('95','','2','43','63','1','admin','5','1668133596','1668133615','http://localhost:91/slaguangguhuadayinchanpin/63.html','/uploads/202211/11/221111102643104.png','1','1');
INSERT INTO `hc_all_content` VALUES ('96','','2','43','64','1','admin','6','1668133618','1668133638','http://localhost:91/slaguangguhuadayinchanpin/64.html','/uploads/202211/11/221111102710794.png','1','1');
INSERT INTO `hc_all_content` VALUES ('97','','2','43','65','1','admin','7','1668133640','1668133653','http://localhost:91/slaguangguhuadayinchanpin/65.html','/uploads/202211/11/221111102726113.png','1','1');
INSERT INTO `hc_all_content` VALUES ('98','','2','43','66','1','admin','8','1668133660','1668133674','http://localhost:91/slaguangguhuadayinchanpin/66.html','/uploads/202211/11/221111102746481.png','1','1');
INSERT INTO `hc_all_content` VALUES ('99','','2','43','67','1','admin','9','1668133676','1668133694','http://localhost:91/slaguangguhuadayinchanpin/67.html','/uploads/202211/11/221111102805162.png','1','1');
INSERT INTO `hc_all_content` VALUES ('100','','2','43','68','1','admin','17','1668133697','1668392409','http://localhost:91/slaguangguhuadayinchanpin/68.html','/uploads/202211/11/221111102824966.png','1','1');
INSERT INTO `hc_all_content` VALUES ('101','','2','43','69','1','admin','11','1668133733','1668133743','http://localhost:91/slaguangguhuadayinchanpin/69.html','/uploads/202211/11/221111102858609.png','1','1');
INSERT INTO `hc_all_content` VALUES ('163','','2','7','130','1','admin','发动机部件(成熟工艺案例)','1668412526','1668413011','http://localhost:91/qichelingbujian/130.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('103','','2','43','71','1','admin','14','1668133761','1668133798','http://localhost:91/slaguangguhuadayinchanpin/71.html','/uploads/202211/11/221111102952229.png','1','1');
INSERT INTO `hc_all_content` VALUES ('164','','2','7','131','1','admin','变速箱部件(成熟工艺案例)','1668412537','1668413004','http://localhost:91/qichelingbujian/131.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('105','','2','43','73','1','admin','16','1668133820','1668133833','http://localhost:91/slaguangguhuadayinchanpin/73.html','/uploads/202211/11/221111103027481.png','1','1');
INSERT INTO `hc_all_content` VALUES ('106','','2','44','74','1','admin','17','1668133848','1668482142','http://localhost:91/slajinshudayinchanpin/74.html','/uploads/202211/11/221111103105448.png','1','1');
INSERT INTO `hc_all_content` VALUES ('107','','2','44','75','1','admin','18','1668133874','1668482150','http://localhost:91/slajinshudayinchanpin/75.html','/uploads/202211/11/221111103119385.png','1','1');
INSERT INTO `hc_all_content` VALUES ('108','','2','44','76','1','admin','19','1668133883','1668482157','http://localhost:91/slajinshudayinchanpin/76.html','/uploads/202211/11/221111103130811.png','1','1');
INSERT INTO `hc_all_content` VALUES ('109','','2','44','77','1','admin','20','1668134255','1668482166','http://localhost:91/slajinshudayinchanpin/77.html','/uploads/202211/11/221111103740954.png','1','1');
INSERT INTO `hc_all_content` VALUES ('110','','2','44','78','1','admin','21','1668134271','1668482173','http://localhost:91/slajinshudayinchanpin/78.html','/uploads/202211/11/221111103757376.png','1','1');
INSERT INTO `hc_all_content` VALUES ('112','','2','44','80','1','admin','22','1668134331','1668482182','http://localhost:91/slajinshudayinchanpin/80.html','/uploads/202211/11/221111103900758.png','1','1');
INSERT INTO `hc_all_content` VALUES ('113','','2','44','81','1','admin','23','1668134351','1668482215','http://localhost:91/slajinshudayinchanpin/81.html','/uploads/202211/11/221111103917477.png','1','1');
INSERT INTO `hc_all_content` VALUES ('114','','2','44','82','1','admin','24','1668134368','1668482223','http://localhost:91/slajinshudayinchanpin/82.html','/uploads/202211/11/221111103934616.png','1','1');
INSERT INTO `hc_all_content` VALUES ('115','','2','44','83','1','admin','25','1668134384','1668482232','http://localhost:91/slajinshudayinchanpin/83.html','/uploads/202211/11/221111103950492.png','1','1');
INSERT INTO `hc_all_content` VALUES ('116','','2','44','84','1','admin','26','1668134400','1668482242','http://localhost:91/slajinshudayinchanpin/84.html','/uploads/202211/11/221111104006197.png','1','1');
INSERT INTO `hc_all_content` VALUES ('117','','2','44','85','1','admin','27','1668134414','1668482252','http://localhost:91/slajinshudayinchanpin/85.html','/uploads/202211/11/221111104023689.png','1','1');
INSERT INTO `hc_all_content` VALUES ('118','','2','44','86','1','admin','28','1668134442','1668482260','http://localhost:91/slajinshudayinchanpin/86.html','/uploads/202211/11/221111104051683.png','1','1');
INSERT INTO `hc_all_content` VALUES ('119','','2','44','87','1','admin','29','1668134460','1668482269','http://localhost:91/slajinshudayinchanpin/87.html','/uploads/202211/11/221111104106337.png','1','1');
INSERT INTO `hc_all_content` VALUES ('120','','2','44','88','1','admin','30','1668134476','1668482279','http://localhost:91/slajinshudayinchanpin/88.html','/uploads/202211/11/221111104123379.png','1','1');
INSERT INTO `hc_all_content` VALUES ('121','','2','44','89','1','admin','31','1668134491','1668482287','http://localhost:91/slajinshudayinchanpin/89.html','/uploads/202211/11/221111104138654.png','1','1');
INSERT INTO `hc_all_content` VALUES ('122','','2','44','90','1','admin','32','1668134507','1668482295','http://localhost:91/slajinshudayinchanpin/90.html','/uploads/202211/11/221111104152709.png','1','1');
INSERT INTO `hc_all_content` VALUES ('123','','2','44','91','1','admin','33','1668134521','1668482302','http://localhost:91/slajinshudayinchanpin/91.html','/uploads/202211/11/221111104206367.png','1','1');
INSERT INTO `hc_all_content` VALUES ('124','','2','44','92','1','admin','34','1668134535','1668482310','http://localhost:91/slajinshudayinchanpin/92.html','/uploads/202211/11/221111104222390.png','1','1');
INSERT INTO `hc_all_content` VALUES ('125','','2','44','93','1','admin','35','1668134550','1668482323','http://localhost:91/slajinshudayinchanpin/93.html','/uploads/202211/11/221111104237780.png','1','1');
INSERT INTO `hc_all_content` VALUES ('126','','2','44','94','1','admin','36','1668134571','1668482332','http://localhost:91/slajinshudayinchanpin/94.html','/uploads/202211/11/221111104300258.png','1','1');
INSERT INTO `hc_all_content` VALUES ('127','','2','44','95','1','admin','37','1668134626','1668482341','http://localhost:91/slajinshudayinchanpin/95.html','/uploads/202211/11/221111104351641.png','1','1');
INSERT INTO `hc_all_content` VALUES ('128','','2','44','96','1','admin','38','1668134639','1668482350','http://localhost:91/slajinshudayinchanpin/96.html','/uploads/202211/11/221111104407176.png','1','1');
INSERT INTO `hc_all_content` VALUES ('129','','2','44','97','1','admin','39','1668134655','1668482359','http://localhost:91/slajinshudayinchanpin/97.html','/uploads/202211/11/221111104423623.png','1','1');
INSERT INTO `hc_all_content` VALUES ('130','','2','44','98','1','admin','40','1668134672','1668482367','http://localhost:91/slajinshudayinchanpin/98.html','/uploads/202211/11/221111104438936.png','1','1');
INSERT INTO `hc_all_content` VALUES ('131','','2','45','99','1','admin','41','1668134704','1668482392','http://localhost:91/slanilongdayinchanpin/99.html','/uploads/202211/11/221111104521172.png','1','1');
INSERT INTO `hc_all_content` VALUES ('132','','2','45','100','1','admin','42','1668134742','1668482399','http://localhost:91/slanilongdayinchanpin/100.html','/uploads/202211/11/221111104548937.png','1','1');
INSERT INTO `hc_all_content` VALUES ('133','','2','45','101','1','admin','43','1668134757','1668482406','http://localhost:91/slanilongdayinchanpin/101.html','/uploads/202211/11/221111104602138.png','1','1');
INSERT INTO `hc_all_content` VALUES ('134','','2','45','102','1','admin','44','1668134772','1668482415','http://localhost:91/slanilongdayinchanpin/102.html','/uploads/202211/11/221111104619445.png','1','1');
INSERT INTO `hc_all_content` VALUES ('135','','2','45','103','1','admin','45','1668134787','1668482424','http://localhost:91/slanilongdayinchanpin/103.html','/uploads/202211/11/221111104637918.png','1','1');
INSERT INTO `hc_all_content` VALUES ('136','','2','46','104','1','admin','48','1668134820','1668482491','http://localhost:91/fumochanpin/104.html','/uploads/202211/11/221111104708470.png','1','1');
INSERT INTO `hc_all_content` VALUES ('137','','2','46','105','1','admin','49','1668134857','1668482499','http://localhost:91/fumochanpin/105.html','/uploads/202211/11/221111104744366.png','1','1');
INSERT INTO `hc_all_content` VALUES ('138','','2','46','106','1','admin','50','1668134892','1668482506','http://localhost:91/fumochanpin/106.html','/uploads/202211/11/221111104817199.png','1','1');
INSERT INTO `hc_all_content` VALUES ('139','','2','46','107','1','admin','51','1668134911','1668482513','http://localhost:91/fumochanpin/107.html','/uploads/202211/11/221111104838443.png','1','1');
INSERT INTO `hc_all_content` VALUES ('140','','2','68','108','1','admin','52','1668134938','1668482584','http://localhost:91/jingmizhuzaochanpin/108.html','/uploads/202211/11/221111104910263.png','1','1');
INSERT INTO `hc_all_content` VALUES ('141','','2','68','109','1','admin','53','1668134958','1668482591','http://localhost:91/jingmizhuzaochanpin/109.html','/uploads/202211/11/221111104926392.png','1','1');
INSERT INTO `hc_all_content` VALUES ('142','','2','68','110','1','admin','54','1668134978','1668482600','http://localhost:91/jingmizhuzaochanpin/110.html','/uploads/202211/11/221111104944472.png','1','1');
INSERT INTO `hc_all_content` VALUES ('143','','2','68','111','1','admin','55','1668134991','1668482608','http://localhost:91/jingmizhuzaochanpin/111.html','/uploads/202211/11/221111104957806.png','1','1');
INSERT INTO `hc_all_content` VALUES ('144','','2','68','112','1','admin','56','1668135006','1668482617','http://localhost:91/jingmizhuzaochanpin/112.html','/uploads/202211/11/221111105012682.png','1','1');
INSERT INTO `hc_all_content` VALUES ('145','','2','68','113','1','admin','57','1668135020','1668482654','http://localhost:91/jingmizhuzaochanpin/113.html','/uploads/202211/11/221111105026978.png','1','1');
INSERT INTO `hc_all_content` VALUES ('146','','2','68','114','1','admin','58','1668135034','1668482662','http://localhost:91/jingmizhuzaochanpin/114.html','/uploads/202211/11/221111105039733.png','1','1');
INSERT INTO `hc_all_content` VALUES ('147','','2','68','115','1','admin','59','1668135048','1668482672','http://localhost:91/jingmizhuzaochanpin/115.html','/uploads/202211/11/221111105055341.png','1','1');
INSERT INTO `hc_all_content` VALUES ('148','','2','68','116','1','admin','60','1668135064','1668482681','http://localhost:91/jingmizhuzaochanpin/116.html','/uploads/202211/11/221111105115213.png','1','1');
INSERT INTO `hc_all_content` VALUES ('149','','2','68','117','1','admin','61','1668135083','1668482690','http://localhost:91/jingmizhuzaochanpin/117.html','/uploads/202211/11/221111105131619.png','1','1');
INSERT INTO `hc_all_content` VALUES ('150','','2','68','118','1','admin','62','1668135096','1668482698','http://localhost:91/jingmizhuzaochanpin/118.html','/uploads/202211/11/221111105142412.png','1','1');
INSERT INTO `hc_all_content` VALUES ('151','','2','68','119','1','admin','63','1668135107','1668482707','http://localhost:91/jingmizhuzaochanpin/119.html','/uploads/202211/11/221111105153578.png','1','1');
INSERT INTO `hc_all_content` VALUES ('152','','2','68','120','1','admin','64','1668135121','1668482715','http://localhost:91/jingmizhuzaochanpin/120.html','/uploads/202211/11/221111105208790.png','1','1');
INSERT INTO `hc_all_content` VALUES ('153','','2','69','121','1','admin','65','1668135152','1668482760','http://localhost:91/qita/121.html','/uploads/202211/11/221111105241714.png','1','1');
INSERT INTO `hc_all_content` VALUES ('154','','2','69','122','1','admin','66','1668135188','1668482767','http://localhost:91/qita/122.html','/uploads/202211/11/221111105315755.png','1','1');
INSERT INTO `hc_all_content` VALUES ('155','','2','69','123','1','admin','67','1668135204','1668482775','http://localhost:91/qita/123.html','/uploads/202211/11/221111105331815.png','1','1');
INSERT INTO `hc_all_content` VALUES ('156','','2','69','124','1','admin','68','1668135218','1668482783','http://localhost:91/qita/124.html','/uploads/202211/11/221111105345189.png','1','1');
INSERT INTO `hc_all_content` VALUES ('157','','2','69','125','1','admin','69','1668135233','1668482791','http://localhost:91/qita/125.html','/uploads/202211/11/221111105359631.png','1','1');
INSERT INTO `hc_all_content` VALUES ('158','','2','69','126','1','admin','70','1668135247','1668482799','http://localhost:91/qita/126.html','/uploads/202211/11/221111105415739.png','1','1');
INSERT INTO `hc_all_content` VALUES ('159','','2','69','127','1','admin','71','1668135264','1668482808','http://localhost:91/qita/127.html','/uploads/202211/11/221111105430636.png','1','1');
INSERT INTO `hc_all_content` VALUES ('160','','2','45','128','1','admin','72','1668133746','1668482877','http://localhost:91/slanilongdayinchanpin/128.html','/uploads/202211/11/221111102913591.png','1','1');
INSERT INTO `hc_all_content` VALUES ('161','','2','45','129','1','admin','73','1668133806','1668482887','http://localhost:91/slanilongdayinchanpin/129.html','/uploads/202211/11/221111103012434.png','1','1');
INSERT INTO `hc_all_content` VALUES ('165','','2','7','132','1','admin','底盘零部件(成熟工艺案例)','1668412548','1668412996','http://localhost:91/qichelingbujian/132.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('166','','2','7','133','1','admin','底盘零部件(成熟工艺案例)','1668412558','1668412989','http://localhost:91/qichelingbujian/133.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('167','','2','8','134','1','admin','水冷产品零部件(成熟工艺案例)','1668413386','1668413400','http://localhost:91/hangkonghang/134.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('168','','2','8','135','1','admin','通讯产品零部件(成熟工艺案例)','1668413423','1668413443','http://localhost:91/hangkonghang/135.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('169','','2','9','136','1','admin','薄壁产品零部件(成熟工艺案例)','1668413459','1668413467','http://localhost:91/jungong/136.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('170','','2','9','137','1','admin','水冷产品零部件(成熟工艺案例) ','1668413471','1668413484','http://localhost:91/jungong/137.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('174','','1','96','37','1','admin','企业职能','1669018480','1669365271','http://localhost:91/gongsijianjie/37.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('175','','1','96','38','1','admin','技术服务','1669018578','1669018592','http://localhost:91/gongsijianjie/38.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('176','','1','96','39','1','admin','3D打印材料研发销售','1669018597','1669365266','http://localhost:91/gongsijianjie/39.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('177','','1','96','40','1','admin','三维反求技术','1669018651','1669365261','http://localhost:91/gongsijianjie/40.html','','1','1');

-- -----------------------------
-- Table structure for `hc_article`
-- -----------------------------
DROP TABLE IF EXISTS `hc_article`;
CREATE TABLE `hc_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(180) NOT NULL DEFAULT '',
  `color` char(9) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `copyfrom` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `flag` varchar(12) NOT NULL DEFAULT '' COMMENT '1置顶,2头条,3特荐,4推荐,5热点,6幻灯,7跳转',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groupids_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '收费类型',
  `is_push` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否百度推送',
  `rong_id` varchar(100) NOT NULL DEFAULT '',
  `article_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`),
  KEY `catid` (`catid`,`status`),
  KEY `userid` (`userid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_article`
-- -----------------------------
INSERT INTO `hc_article` VALUES ('10','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1668564174','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','54','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/16/221116100215445.jpg','http://localhost:91/xinwenzhongxin/10.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('11','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1668564156','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','37','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/16/221116100234144.jpeg','http://localhost:91/xinwenzhongxin/11.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('12','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/12.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('13','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1668564145','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','44','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/16/221116100224272.jpg','http://localhost:91/xinwenzhongxin/13.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('14','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1668564200','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/16/221116100204274.jpg','http://localhost:91/xinwenzhongxin/14.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('15','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1668564126','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/16/221116100204274.jpg','http://localhost:91/xinwenzhongxin/15.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('19','52','1','admin','管理员','2018年12月','','1667787047','1667787297','2018年,12月','国家电网旗下优秀供应商','17','<p>国家电网旗下优秀供应商</p>','网络','','http://localhost:91/Companyhonor/19.html','','1','1','10','','','1','','1','');
INSERT INTO `hc_article` VALUES ('20','52','1','admin','管理员','2019年3月','','1667787073','1667787281','F1,in,Schools,青少年,科技创新,挑战赛','2019年3月','98','<p>F1 in Schools青少年科技创新挑战赛技术支持单位</p>','网络','','http://localhost:91/Companyhonor/20.html','','1','1','10','','','1','','2','');
INSERT INTO `hc_article` VALUES ('21','52','1','admin','管理员','2019年10月','','1667787090','1667787105','南京,增材,制造,研究院,合作,示范','南京增材制造研究院合作示范单位','66','<p>南京增材制造研究院合作示范单位</p>','网络','','http://localhost:91/Companyhonor/21.html','','1','1','10','','','1','','3','');
INSERT INTO `hc_article` VALUES ('22','52','1','admin','管理员','2020年3月','','1667787110','1667787126','2020年,3月','国家增材制造中心合作江苏示范单位','59','<p>国家增材制造中心合作江苏示范单位</p>','网络','','http://localhost:91/Companyhonor/22.html','','1','1','10','','','1','','4','');
INSERT INTO `hc_article` VALUES ('23','52','1','admin','管理员','2020年5月','','1667787128','1667787149','2020年,5月','西安交通大学技术合作示范单位','55','<p>西安交通大学技术合作示范单位</p>','网络','','http://localhost:91/Companyhonor/23.html','','1','1','10','','','1','','5','');
INSERT INTO `hc_article` VALUES ('24','52','1','admin','管理员','2021年7月','','1667787153','1667787165','2021年,7月','中国科学院优秀合作单位','14','<p>中国科学院优秀合作单位</p>','网络','','http://localhost:91/Companyhonor/24.html','','1','1','10','','','1','','6','');
INSERT INTO `hc_article` VALUES ('25','52','1','admin','管理员','2021年8月','','1667787170','1667787186','2021年,8月','全国增材制造创新产业联盟会员单位','13','<p>全国增材制造创新产业联盟会员单位</p>','网络','','http://localhost:91/Companyhonor/25.html','','1','1','10','','','1','','7','');
INSERT INTO `hc_article` VALUES ('26','52','1','admin','管理员','2021年10月','','1667787190','1667787205','2021年,10月','上汽集团优秀供应商','63','<p>上汽集团优秀供应商</p>','网络','','http://localhost:91/Companyhonor/26.html','','1','1','10','','','1','','8','');
INSERT INTO `hc_article` VALUES ('27','52','1','admin','管理员','2022年5月','','1667787210','1667787227','2022年,5月','深圳市大族激光科技股份有限公司合格供应商','77','<p>深圳市大族激光科技股份有限公司合格供应商</p>','网络','','http://localhost:91/Companyhonor/27.html','','1','1','10','','','1','','9','');
INSERT INTO `hc_article` VALUES ('37','96','1','admin','管理员','企业职能','','1669018480','1669365271','企业,职能','    一接受企业委托，和研究院一起开展科学研究和技术攻关，为企业提供技术咨询和决策咨询、解决企业面临的技术难题等。    二结合公司优势以公司完备的3D打印，机加工，检测...','14','<div>&nbsp;&nbsp;&nbsp;&nbsp;一接受企业委托，和研究院一起开展科学研究和技术攻关，为企业提供技术咨询和决策咨询、解决企业面临的技术难题等。</div><div>&nbsp;&nbsp;&nbsp;&nbsp;二结合公司优势以公司完备的3D打印，机加工，检测，真空复膜及相关辅助设备和公司的技术团队为企业，机构，院校，研究所提供全面的3D打印结合精密加工制造生产及新型工艺方案的技术服务及解决方案。</div>','网络','','http://localhost:91/gongsijianjie/37.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('38','96','1','admin','管理员','技术服务','','1669018578','1669018592','技术服务','    3D打印，精密铸造和CNC机械加工相结合在航空航天应用技术服务：叶片、整体叶盘和涡轮盘、无人机机身蜂窝结构件、机身承力件、机身整体化制造；航天器尾喷管、航天发动机关...','54','<div>&nbsp;&nbsp;&nbsp;&nbsp;3D打印，精密铸造和CNC机械加工相结合在航空航天应用技术服务：叶片、整体叶盘和涡轮盘、无人机机身蜂窝结构件、机身承力件、机身整体化制造；航天器尾喷管、航天发动机关键件。</div><div>&nbsp;&nbsp;&nbsp;&nbsp;3D打印，精密铸造和CNC机械加工相结合在汽车开发应用技术服务：汽车零部件开发、汽车展览样车开发、汽车工程样车制造、复合材料车身研发。</div><p><br/></p>','网络','','http://localhost:91/gongsijianjie/38.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('39','96','1','admin','管理员','3D打印材料研发销售','','1669018597','1669365266','3D,打印,材质','    金属、塑料、树脂等的液态、粉材、丝材材料开发。    3D打印和CNC机械加工相结合在快速模具和小批量零件制造方面的服务。    3D打印在医疗行业技术服务：牙科矫正、手术导...','84','<div>&nbsp;&nbsp;&nbsp;&nbsp;金属、塑料、树脂等的液态、粉材、丝材材料开发。</div><div>&nbsp;&nbsp;&nbsp;&nbsp;3D打印和CNC机械加工相结合在快速模具和小批量零件制造方面的服务。</div><div>&nbsp;&nbsp;&nbsp;&nbsp;3D打印在医疗行业技术服务：牙科矫正、手术导航、人工内植物、生物活性 骨、手术参考模型。</div><div>&nbsp;&nbsp;&nbsp;&nbsp;CNC零配件机械加工，覆膜，精密铸造等服务。</div>','网络','','http://localhost:91/gongsijianjie/39.html','','1','1','10','','','1','','','');
INSERT INTO `hc_article` VALUES ('40','96','1','admin','管理员','三维反求技术','','1669018651','1669365261','三维,反求,技术','    大中小型外形测量与三维CAD建模、应力应变检测与设 计物理仿真。','80','<p>&nbsp;&nbsp;&nbsp;&nbsp;大中小型外形测量与三维CAD建模、应力应变检测与设 计物理仿真。</p>','网络','','http://localhost:91/gongsijianjie/40.html','','1','1','10','','','1','','','');

-- -----------------------------
-- Table structure for `hc_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `hc_attachment`;
CREATE TABLE `hc_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `module` char(15) NOT NULL DEFAULT '',
  `contentid` varchar(20) NOT NULL DEFAULT '',
  `originname` varchar(50) NOT NULL DEFAULT '',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filepath` char(200) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` char(10) NOT NULL DEFAULT '',
  `isimage` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `downloads` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `uploadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `uploadip` char(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `userid_index` (`userid`),
  KEY `contentid` (`contentid`)
) ENGINE=MyISAM AUTO_INCREMENT=223 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_attachment`
-- -----------------------------
INSERT INTO `hc_attachment` VALUES ('1','','admin','','page-title-1.jpg','221010044521715.jpg','/uploads/202210/10/','96473','jpg','1','','1','admin','1665391521','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('2','','admin','','1651549213.jpg','221011092029917.jpg','/uploads/202210/11/','62380','jpg','1','','1','admin','1665451229','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('3','','admin','','t01d74ddf8b7c58360a.jpg','221011092036595.jpg','/uploads/202210/11/','22251','jpg','1','','1','admin','1665451236','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('4','','admin','','微信图片_20221008174230.jpg','221011092036254.jpg','/uploads/202210/11/','115677','jpg','1','','1','admin','1665451236','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('5','','admin','','1536643408740_2.jpg','221011092037177.jpg','/uploads/202210/11/','172603','jpg','1','','1','admin','1665451237','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('6','','admin','','图片4.png','221011092037999.png','/uploads/202210/11/','38718','png','1','','1','admin','1665451237','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('7','','admin','','t01d74ddf8b7c58360a.jpg','221011014303722.jpg','/uploads/202210/11/','22251','jpg','1','','1','admin','1665466983','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('45','','link','','ch-8.png','221103044206470.png','/uploads/202211/03/','20775','png','1','','1','admin','1667464926','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('46','','link','','ch-10.png','221103044237435.png','/uploads/202211/03/','19682','png','1','','1','admin','1667464957','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('47','','link','','ch-10.png','221103044315534.png','/uploads/202211/03/','19682','png','1','','1','admin','1667464995','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('48','','link','','ch-11.png','221103044332828.png','/uploads/202211/03/','14190','png','1','','1','admin','1667465012','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('49','','link','','ch-12.png','221103044357147.png','/uploads/202211/03/','8858','png','1','','1','admin','1667465037','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('50','','link','','ch-13.png','221103044428983.png','/uploads/202211/03/','11571','png','1','','1','admin','1667465068','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('51','','link','','ch-14.png','221103044443543.png','/uploads/202211/03/','18371','png','1','','1','admin','1667465083','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('52','','link','','ch-15.png','221103044458850.png','/uploads/202211/03/','13565','png','1','','1','admin','1667465098','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('53','','link','','ch-16.png','221103044529746.png','/uploads/202211/03/','15818','png','1','','1','admin','1667465129','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('54','','link','','ch-17.png','221103044554341.png','/uploads/202211/03/','10916','png','1','','1','admin','1667465154','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('55','','link','','ch-18.png','221103044611784.png','/uploads/202211/03/','13721','png','1','','1','admin','1667465171','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('56','','link','','ch-19.png','221103044628360.png','/uploads/202211/03/','13275','png','1','','1','admin','1667465188','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('42','','link','','ch-5.png','221103044055115.png','/uploads/202211/03/','19480','png','1','','1','admin','1667464855','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('43','','link','','ch-6.png','221103044114462.png','/uploads/202211/03/','16405','png','1','','1','admin','1667464874','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('44','','link','','ch-7.png','221103044154742.png','/uploads/202211/03/','23952','png','1','','1','admin','1667464914','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('40','','link','','ch-3.png','221103043855595.png','/uploads/202211/03/','17501','png','1','','1','admin','1667464735','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('41','','link','','ch-4.png','221103044001206.png','/uploads/202211/03/','17524','png','1','','1','admin','1667464801','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('39','','link','','ch-2.png','221103043831124.png','/uploads/202211/03/','18609','png','1','','1','admin','1667464711','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('38','','link','','ch-1.png','221103043758147.png','/uploads/202211/03/','20744','png','1','','1','admin','1667464678','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('30','','banner','','97177a98-8c84-40eb-a644-82afdaa97873.png','221103101925452.png','/uploads/202211/03/','1593938','png','1','','1','admin','1667441965','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('31','','banner','','banner2.jpg','221103102024937.jpg','/uploads/202211/03/','1275891','jpg','1','','1','admin','1667442024','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('32','','banner','','banner3.jpg','221103102035448.jpg','/uploads/202211/03/','774204','jpg','1','','1','admin','1667442035','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('33','','banner','','gsjj.png','221103105331395.png','/uploads/202211/03/','658735','png','1','','1','admin','1667444011','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('34','','banner','','gsjj2.jpg','221103105400866.jpg','/uploads/202211/03/','348426','jpg','1','','1','admin','1667444039','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('35','','admin','','荣誉证书-英文.png','221103035857827.png','/uploads/202211/03/','92528','png','1','','1','admin','1667462337','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('36','','admin','','荣誉证书-中文.png','221103035913952.png','/uploads/202211/03/','81580','png','1','','1','admin','1667462353','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('37','','admin','','荣誉证书-英文.png','221103035939248.png','/uploads/202211/03/','92528','png','1','','1','admin','1667462379','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('57','','link','','ch-20.png','221103044644371.png','/uploads/202211/03/','21343','png','1','','1','admin','1667465204','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('58','','admin','','组织框架.png','221103051826611.png','/uploads/202211/03/','42618','png','1','','1','admin','1667467106','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('59','','admin','','6c4744cc863d48bba41750991f6022f3.jpeg','221103055935990.jpeg','/uploads/202211/03/','111141','jpeg','1','','1','admin','1667469575','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('60','','admin','','banner-产品列表.png','221107103122993.png','/uploads/202211/07/','694902','png','1','','1','admin','1667788282','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('61','','index','','fw01.jpg','1667806888186437.jpg','/uploads/ueditor/image/20221107/','777716','jpg','1','','1','admin','1667806888','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('62','','index','','fw01.jpg','1667806938117680.jpg','/uploads/ueditor/image/20221107/','777716','jpg','1','','1','admin','1667806938','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('63','','index','','fw01.jpg','1667809346138874.jpg','/uploads/ueditor/image/20221107/','777716','jpg','1','','1','admin','1667809346','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('64','','link','','-s-ch-21.jpg','221109035703566.jpg','/uploads/202211/09/','16545','jpg','1','','1','admin','1667980623','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('65','','link','','-s-ch-22.jpg','221109035728996.jpg','/uploads/202211/09/','14704','jpg','1','','1','admin','1667980648','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('66','','link','','-s-ch-23.jpg','221109035749253.jpg','/uploads/202211/09/','13026','jpg','1','','1','admin','1667980669','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('67','','link','','-s-ch-24.jpg','221109035807143.jpg','/uploads/202211/09/','13036','jpg','1','','1','admin','1667980687','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('68','','banner','','banner5.jpg','221109040752300.jpg','/uploads/202211/09/','1946849','jpg','1','','1','admin','1667981272','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('69','','admin','','生产工艺与方法.jpg','221109040838869.jpg','/uploads/202211/09/','794100','jpg','1','','1','admin','1667981318','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('70','','admin','','产品展示.jpg','221109041019614.jpg','/uploads/202211/09/','477736','jpg','1','','1','admin','1667981419','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('71','','admin','','服务专区.jpg','221109041053192.jpg','/uploads/202211/09/','671169','jpg','1','','1','admin','1667981453','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('72','','admin','','联系我们.jpg','221109041104330.jpg','/uploads/202211/09/','708207','jpg','1','','1','admin','1667981464','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('73','','admin','','logo.png','221110021316564.png','/uploads/202211/10/','5119','png','1','','1','admin','1668060796','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('74','','admin','','SLA光固化3D打印机1.png','221110032746776.png','/uploads/202211/10/','47152','png','1','','1','admin','1668065266','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('75','','admin','','金属3D打印机1.png','221110034553991.png','/uploads/202211/10/','244836','png','1','','1','admin','1668066353','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('76','','admin','','尼龙3D打印机df (2)1.png','221110041042965.png','/uploads/202211/10/','87693','png','1','','1','admin','1668067842','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('77','','admin','','尼龙3D打印机df1.png','221110041056583.png','/uploads/202211/10/','64045','png','1','','1','admin','1668067856','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('78','','admin','','尼龙打印机1.png','221110041102794.png','/uploads/202211/10/','78897','png','1','','1','admin','1668067862','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('79','','admin','','尼龙打印机1的副本.png','221110041107437.png','/uploads/202211/10/','144692','png','1','','1','admin','1668067867','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('80','','admin','','微信图片_202210221039021.png','221110041642573.png','/uploads/202211/10/','249396','png','1','','1','admin','1668068201','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('81','','admin','','立式加工中心 (2)1.png','221110044036463.png','/uploads/202211/10/','330623','png','1','','1','admin','1668069636','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('82','','admin','','立式加工中心1.png','221110044149118.png','/uploads/202211/10/','226560','png','1','','1','admin','1668069709','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('83','','admin','','数控车床1.png','221110044254131.png','/uploads/202211/10/','134894','png','1','','1','admin','1668069774','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('84','','admin','','数控车床2.png','221110044331585.png','/uploads/202211/10/','165756','png','1','','1','admin','1668069811','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('85','','admin','','五轴联动加工中心1.png','221110044420596.png','/uploads/202211/10/','108649','png','1','','1','admin','1668069860','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('86','','admin','','图片1.png','221110044602547.png','/uploads/202211/10/','329314','png','1','','1','admin','1668069962','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('87','','admin','','1.png','221110054021213.png','/uploads/202211/10/','128191','png','1','','1','admin','1668073221','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('88','','admin','','2.png','221110054224636.png','/uploads/202211/10/','122695','png','1','','1','admin','1668073344','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('89','','admin','','3-1变速箱.png','221110054300918.png','/uploads/202211/10/','108239','png','1','','1','admin','1668073380','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('90','','admin','','3变速箱.png','221110054313111.png','/uploads/202211/10/','126281','png','1','','1','admin','1668073393','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('91','','admin','','4-1底盘零部件.png','221110054342143.png','/uploads/202211/10/','116072','png','1','','1','admin','1668073422','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('92','','admin','','4-1底盘零部件.png','221110054347972.png','/uploads/202211/10/','116072','png','1','','1','admin','1668073427','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('93','','admin','','4-2底盘零部件.png','221110054407972.png','/uploads/202211/10/','110920','png','1','','1','admin','1668073447','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('94','','admin','','4-3底盘零部件.png','221110054412763.png','/uploads/202211/10/','93685','png','1','','1','admin','1668073452','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('95','','admin','','5机器人手臂.png','221110054449118.png','/uploads/202211/10/','128170','png','1','','1','admin','1668073489','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('96','','admin','','6减速机壳体.png','221110054517905.png','/uploads/202211/10/','90109','png','1','','1','admin','1668073517','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('97','','admin','','7汽车变速箱部件.png','221110054539675.png','/uploads/202211/10/','108005','png','1','','1','admin','1668073539','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('98','','admin','','8-1汽车零部件.png','221110054604637.png','/uploads/202211/10/','120415','png','1','','1','admin','1668073564','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('99','','admin','','8-2汽车零部件.png','221110054617856.png','/uploads/202211/10/','102930','png','1','','1','admin','1668073577','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('100','','admin','','8-3汽车零部件.png','221110054643541.png','/uploads/202211/10/','125403','png','1','','1','admin','1668073603','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('101','','admin','','8-4汽车零部件.png','221110054650809.png','/uploads/202211/10/','132189','png','1','','1','admin','1668073610','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('102','','admin','','9汽车转向零部.png','221110054710880.png','/uploads/202211/10/','100413','png','1','','1','admin','1668073630','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('103','','admin','','10.png','221110054736408.png','/uploads/202211/10/','115097','png','1','','1','admin','1668073656','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('104','','admin','','11.png','221110054800404.png','/uploads/202211/10/','132406','png','1','','1','admin','1668073680','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('105','','admin','','12羊角总成部件.png','221110054821295.png','/uploads/202211/10/','113126','png','1','','1','admin','1668073701','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('106','','admin','','13.png','221110054846301.png','/uploads/202211/10/','123628','png','1','','1','admin','1668073726','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('107','','admin','','14R系列转向机壳.png','221110054907456.png','/uploads/202211/10/','103809','png','1','','1','admin','1668073747','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('108','','admin','','407338837799882652.jpg','221110055910366.jpg','/uploads/202211/10/','58182','jpg','1','','1','admin','1668074350','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('109','','admin','','7b75508a15cd49dcb005181f66b573bc_th.JPG','221110060056607.jpg','/uploads/202211/10/','736879','jpg','1','','1','admin','1668074456','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('110','','admin','','2.5次元影像测量仪1.png','221110060636790.png','/uploads/202211/10/','56113','png','1','','1','admin','1668074796','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('111','','admin','','三坐标测量仪1.png','221110060656312.png','/uploads/202211/10/','270957','png','1','','1','admin','1668074816','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('112','','admin','','QQ截图20221111101314.png','221111101341959.png','/uploads/202211/11/','183935','png','1','','1','admin','1668132821','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('113','','admin','','QQ截图20221111101845.png','221111101903555.png','/uploads/202211/11/','283644','png','1','','1','admin','1668133143','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('114','','admin','','1.png','221111102342177.png','/uploads/202211/11/','91506','png','1','','1','admin','1668133422','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('115','','admin','','2.png','221111102403941.png','/uploads/202211/11/','135254','png','1','','1','admin','1668133443','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('116','','admin','','2.png','221111102524812.png','/uploads/202211/11/','135254','png','1','','1','admin','1668133524','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('117','','admin','','4.png','221111102623379.png','/uploads/202211/11/','109783','png','1','','1','admin','1668133583','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('118','','admin','','5.png','221111102643104.png','/uploads/202211/11/','49825','png','1','','1','admin','1668133603','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('119','','admin','','6.png','221111102710794.png','/uploads/202211/11/','88002','png','1','','1','admin','1668133630','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('120','','admin','','7.png','221111102726113.png','/uploads/202211/11/','62081','png','1','','1','admin','1668133646','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('121','','admin','','8.png','221111102746481.png','/uploads/202211/11/','99226','png','1','','1','admin','1668133666','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('122','','admin','','9.png','221111102805162.png','/uploads/202211/11/','116437','png','1','','1','admin','1668133685','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('123','','admin','','10底盘零部件.png','221111102824966.png','/uploads/202211/11/','95027','png','1','','1','admin','1668133704','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('124','','admin','','11.png','221111102858609.png','/uploads/202211/11/','136257','png','1','','1','admin','1668133738','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('125','','admin','','13.png','221111102913591.png','/uploads/202211/11/','76437','png','1','','1','admin','1668133753','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('127','','admin','','14.png','221111102952229.png','/uploads/202211/11/','133741','png','1','','1','admin','1668133792','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('128','','admin','','15.png','221111103012434.png','/uploads/202211/11/','46319','png','1','','1','admin','1668133812','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('129','','admin','','16.png','221111103027481.png','/uploads/202211/11/','27579','png','1','','1','admin','1668133827','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('130','','admin','','1.png','221111103105448.png','/uploads/202211/11/','129948','png','1','','1','admin','1668133865','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('131','','admin','','2.png','221111103119385.png','/uploads/202211/11/','71890','png','1','','1','admin','1668133879','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('132','','admin','','3.png','221111103130811.png','/uploads/202211/11/','74628','png','1','','1','admin','1668133890','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('133','','admin','','4.png','221111103740954.png','/uploads/202211/11/','59232','png','1','','1','admin','1668134260','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('134','','admin','','5.png','221111103757376.png','/uploads/202211/11/','127632','png','1','','1','admin','1668134277','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('135','','admin','','6.png','221111103813811.png','/uploads/202211/11/','119308','png','1','','1','admin','1668134293','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('136','','admin','','6.png','221111103900758.png','/uploads/202211/11/','119308','png','1','','1','admin','1668134340','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('137','','admin','','8.png','221111103917477.png','/uploads/202211/11/','82264','png','1','','1','admin','1668134357','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('138','','admin','','9.png','221111103934616.png','/uploads/202211/11/','75576','png','1','','1','admin','1668134374','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('139','','admin','','10.png','221111103950492.png','/uploads/202211/11/','83177','png','1','','1','admin','1668134390','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('140','','admin','','11.png','221111104006197.png','/uploads/202211/11/','103505','png','1','','1','admin','1668134406','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('141','','admin','','12.png','221111104023689.png','/uploads/202211/11/','118895','png','1','','1','admin','1668134423','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('142','','admin','','13.png','221111104051683.png','/uploads/202211/11/','109273','png','1','','1','admin','1668134451','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('143','','admin','','14.png','221111104106337.png','/uploads/202211/11/','119965','png','1','','1','admin','1668134466','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('144','','admin','','15.png','221111104123379.png','/uploads/202211/11/','127789','png','1','','1','admin','1668134483','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('145','','admin','','16.png','221111104138654.png','/uploads/202211/11/','131956','png','1','','1','admin','1668134498','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('146','','admin','','17.png','221111104152709.png','/uploads/202211/11/','128856','png','1','','1','admin','1668134512','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('147','','admin','','18.png','221111104206367.png','/uploads/202211/11/','85865','png','1','','1','admin','1668134526','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('148','','admin','','19.png','221111104222390.png','/uploads/202211/11/','112949','png','1','','1','admin','1668134542','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('149','','admin','','20.png','221111104237780.png','/uploads/202211/11/','62950','png','1','','1','admin','1668134557','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('150','','admin','','21.png','221111104300258.png','/uploads/202211/11/','48828','png','1','','1','admin','1668134580','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('151','','admin','','22.png','221111104351641.png','/uploads/202211/11/','80877','png','1','','1','admin','1668134631','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('152','','admin','','23.png','221111104407176.png','/uploads/202211/11/','128904','png','1','','1','admin','1668134647','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('153','','admin','','25.png','221111104423623.png','/uploads/202211/11/','127820','png','1','','1','admin','1668134663','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('154','','admin','','26.png','221111104438936.png','/uploads/202211/11/','98191','png','1','','1','admin','1668134678','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('155','','admin','','1.png','221111104521172.png','/uploads/202211/11/','93465','png','1','','1','admin','1668134721','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('156','','admin','','2.png','221111104548937.png','/uploads/202211/11/','90500','png','1','','1','admin','1668134748','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('157','','admin','','3.png','221111104602138.png','/uploads/202211/11/','28012','png','1','','1','admin','1668134762','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('158','','admin','','4.png','221111104619445.png','/uploads/202211/11/','30756','png','1','','1','admin','1668134779','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('159','','admin','','5.png','221111104637918.png','/uploads/202211/11/','108394','png','1','','1','admin','1668134797','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('160','','admin','','1.png','221111104708470.png','/uploads/202211/11/','97702','png','1','','1','admin','1668134828','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('161','','admin','','2.png','221111104744366.png','/uploads/202211/11/','88644','png','1','','1','admin','1668134864','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('162','','admin','','3.png','221111104817199.png','/uploads/202211/11/','81578','png','1','','1','admin','1668134897','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('163','','admin','','4.png','221111104838443.png','/uploads/202211/11/','75453','png','1','','1','admin','1668134918','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('164','','admin','','1.png','221111104910263.png','/uploads/202211/11/','128907','png','1','','1','admin','1668134950','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('165','','admin','','2.png','221111104926392.png','/uploads/202211/11/','120596','png','1','','1','admin','1668134966','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('166','','admin','','3.png','221111104944472.png','/uploads/202211/11/','76596','png','1','','1','admin','1668134984','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('167','','admin','','4.png','221111104957806.png','/uploads/202211/11/','86355','png','1','','1','admin','1668134997','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('168','','admin','','5.png','221111105012682.png','/uploads/202211/11/','83358','png','1','','1','admin','1668135012','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('169','','admin','','6.png','221111105026978.png','/uploads/202211/11/','123974','png','1','','1','admin','1668135026','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('170','','admin','','7.png','221111105039733.png','/uploads/202211/11/','111113','png','1','','1','admin','1668135039','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('171','','admin','','8.png','221111105055341.png','/uploads/202211/11/','133377','png','1','','1','admin','1668135055','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('172','','admin','','9.png','221111105115213.png','/uploads/202211/11/','104949','png','1','','1','admin','1668135075','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('173','','admin','','10.png','221111105131619.png','/uploads/202211/11/','104620','png','1','','1','admin','1668135091','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('174','','admin','','11.png','221111105142412.png','/uploads/202211/11/','110914','png','1','','1','admin','1668135102','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('175','','admin','','12.png','221111105153578.png','/uploads/202211/11/','122319','png','1','','1','admin','1668135113','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('176','','admin','','13.png','221111105208790.png','/uploads/202211/11/','97762','png','1','','1','admin','1668135128','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('177','','admin','','1png.png','221111105241714.png','/uploads/202211/11/','87253','png','1','','1','admin','1668135161','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('178','','admin','','2.png','221111105315755.png','/uploads/202211/11/','103067','png','1','','1','admin','1668135195','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('179','','admin','','3.png','221111105331815.png','/uploads/202211/11/','129516','png','1','','1','admin','1668135211','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('180','','admin','','4.png','221111105345189.png','/uploads/202211/11/','91660','png','1','','1','admin','1668135225','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('181','','admin','','5.png','221111105359631.png','/uploads/202211/11/','98724','png','1','','1','admin','1668135239','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('182','','admin','','6.png','221111105415739.png','/uploads/202211/11/','58016','png','1','','1','admin','1668135255','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('183','','admin','','7.png','221111105430636.png','/uploads/202211/11/','70538','png','1','','1','admin','1668135270','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('184','','admin','','图片1.png','221114104121954.png','/uploads/202211/14/','301433','png','1','','1','admin','1668393681','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('185','','admin','','1.jpg','221114110216785.jpg','/uploads/202211/14/','122793','jpg','1','','1','admin','1668394936','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('186','','admin','','2.jpg','221114110231758.jpg','/uploads/202211/14/','122505','jpg','1','','1','admin','1668394951','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('187','','admin','','3.jpg','221114110236141.jpg','/uploads/202211/14/','161492','jpg','1','','1','admin','1668394956','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('188','','admin','','4.jpg','221114110240123.jpg','/uploads/202211/14/','116620','jpg','1','','1','admin','1668394960','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('189','','admin','','5.jpg','221114110244331.jpg','/uploads/202211/14/','104681','jpg','1','','1','admin','1668394964','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('190','','index','','fw01.jpg','1668477007194446.jpg','/uploads/ueditor/image/20221115/','777716','jpg','1','','1','admin','1668477007','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('191','','index','','fw01.jpg','1668480752186789.jpg','/uploads/ueditor/image/20221115/','777716','jpg','1','','1','admin','1668480752','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('192','','index','','1.jpg','1668481344527104.jpg','/uploads/ueditor/image/20221115/','33722','jpg','1','','1','admin','1668481344','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('193','','index','','2.jpg','1668481349996564.jpg','/uploads/ueditor/image/20221115/','25478','jpg','1','','1','admin','1668481349','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('194','','index','','3.jpg','1668481398469959.jpg','/uploads/ueditor/image/20221115/','59776','jpg','1','','1','admin','1668481398','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('195','','index','','4.jpg','1668481438186859.jpg','/uploads/ueditor/image/20221115/','33893','jpg','1','','1','admin','1668481438','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('196','','index','','5.jpg','1668481444166475.jpg','/uploads/ueditor/image/20221115/','33549','jpg','1','','1','admin','1668481444','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('197','','index','','6.jpg','1668481487915573.jpg','/uploads/ueditor/image/20221115/','40439','jpg','1','','1','admin','1668481487','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('198','','index','','7.jpg','1668481493151761.jpg','/uploads/ueditor/image/20221115/','42946','jpg','1','','1','admin','1668481493','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('199','','index','','009.jpg','1668481525699223.jpg','/uploads/ueditor/image/20221115/','41584','jpg','1','','1','admin','1668481525','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('200','','index','','10.jpg','1668481548352942.jpg','/uploads/ueditor/image/20221115/','36342','jpg','1','','1','admin','1668481548','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('201','','banner','','91eb33c9-d7f4-4dfd-b32a-7504fa8042b4.jpg','221115025529425.jpg','/uploads/202211/15/','707890','jpg','1','','1','admin','1668495329','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('202','','banner','','221115025529425.jpg','221116094120634.jpg','/uploads/202211/16/','95806','jpg','1','','1','admin','1668562880','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('203','','banner','','221103102024937.jpg','221116094205532.jpg','/uploads/202211/16/','228311','jpg','1','','1','admin','1668562925','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('204','','banner','','221103102035448.jpg','221116094214301.jpg','/uploads/202211/16/','159513','jpg','1','','1','admin','1668562934','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('205','','banner','','221109040752300.jpg','221116095407380.jpg','/uploads/202211/16/','249232','jpg','1','','1','admin','1668563647','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('206','','banner','','221103105400866.jpg','221116095447380.jpg','/uploads/202211/16/','63360','jpg','1','','1','admin','1668563687','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('207','','banner','','221103105331395.jpg','221116095459187.jpg','/uploads/202211/16/','96083','jpg','1','','1','admin','1668563699','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('208','','admin','','221103035913952.png','221116095548250.png','/uploads/202211/16/','72343','png','1','','1','admin','1668563748','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('209','','admin','','221103035939248.png','221116095600970.png','/uploads/202211/16/','92528','png','1','','1','admin','1668563760','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('210','','admin','','221103051826611.png','221116095610174.png','/uploads/202211/16/','30692','png','1','','1','admin','1668563770','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('211','','admin','','221011014303722.jpg','221116100204274.jpg','/uploads/202211/16/','37027','jpg','1','','1','admin','1668564124','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('212','','admin','','221110055910366.jpg','221116100215445.jpg','/uploads/202211/16/','59451','jpg','1','','1','admin','1668564135','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('213','','admin','','221110060056607.jpg','221116100224272.jpg','/uploads/202211/16/','301263','jpg','1','','1','admin','1668564144','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('214','','admin','','221103055935990.jpeg','221116100234144.jpeg','/uploads/202211/16/','111141','jpeg','1','','1','admin','1668564154','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('215','','admin','','221107103122993.jpg','221116100407690.jpg','/uploads/202211/16/','57813','jpg','1','','1','admin','1668564247','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('216','','admin','','221109040838869-(1).jpg','221116100502429.jpg','/uploads/202211/16/','71048','jpg','1','','1','admin','1668564302','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('217','','admin','','221109041019614-(1).jpg','221116100545624.jpg','/uploads/202211/16/','53489','jpg','1','','1','admin','1668564345','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('218','','admin','','221109041104330.jpg','221116100606688.jpg','/uploads/202211/16/','59370','jpg','1','','1','admin','1668564366','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('219','','admin','','c7e85204-b4aa-49c7-8c06-070be662eec6.png','221123031833907.png','/uploads/202211/23/','33561','png','1','','1','admin','1669187913','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('220','','index','','221110044602547.png','1669259201152964.png','/uploads/ueditor/image/20221124/','329314','png','1','','1','admin','1669259201','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('221','','admin','','微信图片_20221124154957(1).jpg','221125021619238.jpg','/uploads/202211/25/','457047','jpg','1','','1','admin','1669356979','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('222','','admin','','微信图片_20221124155008(1).jpg','221125021632150.jpg','/uploads/202211/25/','457357','jpg','1','','1','admin','1669356992','127.0.0.1');

-- -----------------------------
-- Table structure for `hc_banner`
-- -----------------------------
DROP TABLE IF EXISTS `hc_banner`;
CREATE TABLE `hc_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `image` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1显示0隐藏',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `typeid` (`typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_banner`
-- -----------------------------
INSERT INTO `hc_banner` VALUES ('1','最专业的3d打印机,海创三维科技(苏州)有限公司','/uploads/202211/16/221116094120634.jpg','http://www.baodu.com','我们有最新进最优秀的服务技术和团队','1667394394','1','1','1');
INSERT INTO `hc_banner` VALUES ('2','工业级高精度,3D打印机','/uploads/202211/16/221116094205532.jpg','http://www.baidu.com','','1667394539','2','1','1');
INSERT INTO `hc_banner` VALUES ('3','更智慧的3D打印综合服务商','/uploads/202211/16/221116094214301.jpg','http://www.baidu.com','','1667394595','3','1','1');
INSERT INTO `hc_banner` VALUES ('4','公司简介','/uploads/202211/16/221116095459187.jpg','http://www.baidu.com','','1667444016','2','2','1');
INSERT INTO `hc_banner` VALUES ('5','首页公司简介轮播','/uploads/202211/16/221116095447380.jpg','http://www.baidu.com','','1667444052','1','2','1');
INSERT INTO `hc_banner` VALUES ('6','客户至上','/uploads/202211/16/221116095407380.jpg','http://www.baidu.com','','1667981282','4','1','1');

-- -----------------------------
-- Table structure for `hc_banner_type`
-- -----------------------------
DROP TABLE IF EXISTS `hc_banner_type`;
CREATE TABLE `hc_banner_type` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_banner_type`
-- -----------------------------
INSERT INTO `hc_banner_type` VALUES ('1','首页轮播');
INSERT INTO `hc_banner_type` VALUES ('2','首页公司简介轮播');

-- -----------------------------
-- Table structure for `hc_category`
-- -----------------------------
DROP TABLE IF EXISTS `hc_category`;
CREATE TABLE `hc_category` (
  `catid` smallint(5) NOT NULL AUTO_INCREMENT COMMENT '栏目ID',
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `catname` varchar(50) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `arrparentid` varchar(255) NOT NULL DEFAULT '' COMMENT '父级路径',
  `arrchildid` mediumtext NOT NULL COMMENT '子栏目id集合',
  `catdir` varchar(30) NOT NULL DEFAULT '' COMMENT '栏目目录',
  `catimg` varchar(150) NOT NULL DEFAULT '' COMMENT '栏目图片',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '栏目类型:0普通栏目1单页2外部链接',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目排序',
  `target` char(10) NOT NULL DEFAULT '' COMMENT '打开方式',
  `member_publish` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否会员投稿',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '在导航显示',
  `pclink` varchar(100) NOT NULL DEFAULT '' COMMENT '电脑版地址',
  `domain` varchar(100) NOT NULL DEFAULT '' COMMENT '绑定域名',
  `entitle` varchar(80) NOT NULL DEFAULT '' COMMENT '英文标题',
  `subtitle` varchar(60) NOT NULL DEFAULT '' COMMENT '副标题',
  `mobname` varchar(30) NOT NULL DEFAULT '' COMMENT '手机版名称',
  `category_template` varchar(30) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `list_template` varchar(30) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `show_template` varchar(30) NOT NULL DEFAULT '' COMMENT '内容页模板',
  `seo_title` varchar(100) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keywords` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `seo_description` varchar(250) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  PRIMARY KEY (`catid`),
  KEY `siteid` (`siteid`),
  KEY `modelid` (`modelid`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_category`
-- -----------------------------
INSERT INTO `hc_category` VALUES ('6','','产品中心','2','','','6,7,8,9,26,27,28,97','chanpinzhongxin','/uploads/202211/16/221116100407690.jpg','','3','_self','','1','http://localhost:91/chanpinzhongxin/','','','','产品中心','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('7','','汽车零部件','2','6','0,6','7','qichelingbujian','','','','_self','','1','http://localhost:91/qichelingbujian/','','','','汽车零部件','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('8','','航空航天精密零部件','2','6','0,6','8','hangkonghang','','','','_self','','1','http://localhost:91/hangkonghang/','','','','航空航天精密零部件','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('9','','军工产品精密零部件','2','6','0,6','9','jungong','','','','_self','','1','http://localhost:91/jungong/','','','','军工产品精密零部件','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('10','','设备介绍','2','','','10,11,12,13,47','shebei','/uploads/202211/16/221116100407690.jpg','','5','_self','','1','http://localhost:91/shebei/','','','','设备介绍','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('11','','打印设备','2','10','0,10','11','dayinshebei','','','','_self','','1','http://localhost:91/dayinshebei/','','','','打印设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('12','','机加工设备','2','10','0,10','12','jijiagongshebei','','','','_self','','1','http://localhost:91/jijiagongshebei/','','','','机加工设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('13','','检测设备','2','10','0,10','13','jianceshebei','','','','_self','','1','http://localhost:91/jianceshebei/','','','','检测设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('77','','SLA3D打印','','70','0,70','77','suliao3ddayin','','1','','_self','','1','http://localhost:91/suliao3ddayin/','','','','SLA3D打印','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('82','','服务专区','','','','82,83,85,86,87,88,89,90,91,92,93,94,95','fuwu2','/uploads/202211/16/221116100502429.jpg','1','6','_self','','1','http://localhost:91/fuwu2/','','','','服务专区','category_page_service_c','','','','','');
INSERT INTO `hc_category` VALUES ('83','','服务指南','','82','0,82','83,87,88,89,90,91,92,93,94,95','fuwuzhinan2','/uploads/202211/09/221109040838869.jpg','1','','_self','','1','http://localhost:91/fuwuzhinan2/','','','','服务指南','category_page_service_fw','','','','','');
INSERT INTO `hc_category` VALUES ('52','','公司荣誉','1','','','52','Companyhonor','','','','_self','','','http://localhost:91/Companyhonor/','','Company honor','','公司荣誉','category_article','list_article','show_article','','','');
INSERT INTO `hc_category` VALUES ('53','','新闻中心','1','','','53','xinwenzhongxin','/uploads/202211/07/221107103122993.png','','','_self','','','http://localhost:91/xinwenzhongxin/','','Company news','','新闻中心','category_article','list_article','show_article','','','');
INSERT INTO `hc_category` VALUES ('70','','生产工艺方法','','','','70,71,72,73,74,75,76,77','shengchangongyifangfa','/uploads/202211/16/221116100502429.jpg','1','','_self','','1','http://localhost:91/shengchangongyifangfa/','','','','生产工艺方法','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('71','','机械加工','','70','0,70','71','chunjixiejiagong','','1','','_self','','1','http://localhost:91/chunjixiejiagong/','','','','机械加工','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('72','','3D打印+铸造+机械加工','','70','0,70','72','yinjingmizhizaojixiejiagong','','1','','_self','','1','http://localhost:91/yinjingmizhizaojixiejiagong/','','','','3D打印+铸造+机械加工','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('26','','医疗产品零部件','2','6','0,6','26','yiliao','','','','_self','','1','http://localhost:91/yiliao/','','','','医疗产品零部件','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('27','','机构复杂零件','2','6','0,6','27','jigoufuza','','','','_self','','1','http://localhost:91/jigoufuza/','','','','机构复杂零件','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('28','','薄壁、摩擦焊接零部件','2','6','0,6','28','bobimocahan','','','','_self','','1','http://localhost:91/bobimocahan/','','','','薄壁、摩擦焊接零部件','category_product_cp','list_product_cp','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('87','','3D打印文件格式规范','','83','0,82,83','87','dayinwenjiangeshiguifan','','1','','_self','','1','http://localhost:91/dayinwenjiangeshiguifan/','','','','3D打印文件格式规范','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('85','','服务中心','','82','0,82','85','fuwuzhongxin2','','1','','_self','','1','http://localhost:91/fuwuzhongxin2/','','','','服务中心','category_page_service_sh1','','','','','');
INSERT INTO `hc_category` VALUES ('86','','售后服务','','82','0,82','86','shouhoufuwu2','','1','','_self','','1','http://localhost:91/shouhoufuwu2/','','','','售后服务','category_page_service_sh1','','','','','');
INSERT INTO `hc_category` VALUES ('69','','其他','2','41','0,41','69','qita','','','','_self','','1','http://localhost:91/qita/','','','','其他','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('89','','选择合适的材料','','83','0,82,83','89','xuanzeheshidecailiao','','1','','_self','','1','http://localhost:91/xuanzeheshidecailiao/','','','','选择合适的材料','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('90','','3D打印不同材料的最小壁厚要求','','83','0,82,83','90','xiaobihouyaoqiu','','1','','_self','','1','http://localhost:91/xiaobihouyaoqiu/','','','','3D打印不同材料的最小壁厚要求','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('88','','部分设计规范','','83','0,82,83','88','bufenshejiguifan','','1','','_self','','1','http://localhost:91/bufenshejiguifan/','','','','部分设计规范','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('74','','精密3D打印+复膜','','70','0,70','74','jingmi3ddayinfumo','','1','','_self','','1','http://localhost:91/jingmi3ddayinfumo/','','','','精密3D打印+复膜','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('41','','产品展示','2','','','41,42,43,44,45,46,68,69','chanpinzhanshi','/uploads/202211/16/221116100545624.jpg','','4','_self','','1','http://localhost:91/chanpinzhanshi/','','','','产品展示','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('42','','CNC加工','2','41','0,41','42','cndjiagong','','','','_self','','1','http://localhost:91/cndjiagong/','','','','CNC加工','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('43','','SLA光固化打印产品','2','41','0,41','43','slaguangguhuadayinchanpin','','','','_self','','1','http://localhost:91/slaguangguhuadayinchanpin/','','','','SLA光固化打印产品','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('44','','SLM金属打印产品','2','41','0,41','44','slajinshudayinchanpin','','','','_self','','1','http://localhost:91/slajinshudayinchanpin/','','','','SLM金属打印产品','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('45','','SLS尼龙打印产品','2','41','0,41','45','slanilongdayinchanpin','','','','_self','','1','http://localhost:91/slanilongdayinchanpin/','','','','SLS尼龙打印产品','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('46','','复膜产品','2','41','0,41','46','fumochanpin','','','','_self','','1','http://localhost:91/fumochanpin/','','','','复膜产品','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('68','','精密铸造产品','2','41','0,41','68','jingmizhuzaochanpin','','','','_self','','1','http://localhost:91/jingmizhuzaochanpin/','','','','精密铸造产品','category_product','list_product','show_product_other','','','');
INSERT INTO `hc_category` VALUES ('47','','其它设备','2','10','0,10','47','qitashebei','','','','_self','','1','http://localhost:91/qitashebei/','','','','其它设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('75','','金属3D打印','','70','0,70','75','jinshu3ddayin','','1','','_self','','1','http://localhost:91/jinshu3ddayin/','','','','金属3D打印','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('76','','尼龙3D打印','','70','0,70','76','nilong3ddayin','','1','','_self','','1','http://localhost:91/nilong3ddayin/','','','','尼龙3D打印','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('51','','联系我们','','','','51','lianxiwomen','/uploads/202211/16/221116100606688.jpg','1','7','_self','','1','http://localhost:91/lianxiwomen/','','','','联系我们','category_page','','','','','');
INSERT INTO `hc_category` VALUES ('73','','精密铸造+机械加工','','70','0,70','73','jingmizhizaojixiejiagong','','1','','_self','','1','http://localhost:91/jingmizhizaojixiejiagong/','','','','精密铸造+机械加工','category_page_service_gy','','','','','');
INSERT INTO `hc_category` VALUES ('91','','空心设计中逸出孔的大小要求','','83','0,82,83','91','hukongdedaxiaoyaoqiu','','1','','_self','','1','http://localhost:91/hukongdedaxiaoyaoqiu/','','','','空心设计中逸出孔的大小要求','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('92','','立柱的最小壁厚设计要求','','83','0,82,83','92','ushejiyaoqiu','','1','','_self','','1','http://localhost:91/ushejiyaoqiu/','','','','立柱的最小壁厚设计要求','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('93','','凸状和凹状的细节要求','','83','0,82,83','93','exijieyaoqiu','','1','','_self','','1','http://localhost:91/exijieyaoqiu/','','','','凸状和凹状的细节要求','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('94','','间隙设计要求','','83','0,82,83','94','jianxishejiyaoqiu','','1','','_self','','1','http://localhost:91/jianxishejiyaoqiu/','','','','间隙设计要求','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('95','','螺纹的设计要求','','83','0,82,83','95','luowendeshejiyaoqiu','','1','','_self','','1','http://localhost:91/luowendeshejiyaoqiu/','','','','螺纹的设计要求','category_page_service_d','','','','','');
INSERT INTO `hc_category` VALUES ('96','','公司简介','1','','','96','gongsijianjie','','','','_self','','','http://localhost:91/gongsijianjie/','','Company profile','','公司简介','category_article','list_article','show_article','','','');
INSERT INTO `hc_category` VALUES ('97','','测试','2','6','0,6','97','ceshi','','','','_self','','1','http://localhost:91/ceshi/','','','','测试','category_product','list_product','show_product copy','','','');

-- -----------------------------
-- Table structure for `hc_collection_content`
-- -----------------------------
DROP TABLE IF EXISTS `hc_collection_content`;
CREATE TABLE `hc_collection_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:未采集,1:已采集,2:已导入',
  `url` char(255) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nodeid` (`nodeid`),
  KEY `status` (`status`),
  KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_collection_node`
-- -----------------------------
DROP TABLE IF EXISTS `hc_collection_node`;
CREATE TABLE `hc_collection_node` (
  `nodeid` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '采集节点ID',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '节点名称',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后采集时间',
  `sourcecharset` varchar(8) NOT NULL DEFAULT '' COMMENT '采集点字符集',
  `sourcetype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '网址类型:1序列网址,2单页',
  `urlpage` text NOT NULL COMMENT '采集地址',
  `pagesize_start` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '页码开始',
  `pagesize_end` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '页码结束',
  `par_num` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '每次增加数',
  `url_contain` char(100) NOT NULL DEFAULT '' COMMENT '网址中必须包含',
  `url_except` char(100) NOT NULL DEFAULT '' COMMENT '网址中不能包含',
  `url_start` char(100) NOT NULL DEFAULT '' COMMENT '网址开始',
  `url_end` char(100) NOT NULL DEFAULT '' COMMENT '网址结束',
  `title_rule` char(100) NOT NULL DEFAULT '' COMMENT '标题采集规则',
  `title_html_rule` text NOT NULL COMMENT '标题过滤规则',
  `time_rule` char(100) NOT NULL DEFAULT '' COMMENT '时间采集规则',
  `time_html_rule` text COMMENT '时间过滤规则',
  `content_rule` char(100) NOT NULL DEFAULT '' COMMENT '内容采集规则',
  `content_html_rule` text COMMENT '内容过滤规则',
  `down_attachment` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否下载图片',
  `watermark` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '图片加水印',
  `coll_order` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '导入顺序',
  PRIMARY KEY (`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_comment`
-- -----------------------------
DROP TABLE IF EXISTS `hc_comment`;
CREATE TABLE `hc_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commentid` char(30) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `userpic` varchar(100) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评论状态{0:未审核,1:通过审核}',
  `reply` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '是否为回复',
  `commonname` varchar(30) DEFAULT NULL,
  `commonphone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `userid` (`userid`),
  KEY `commentid` (`commentid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_comment_data`
-- -----------------------------
DROP TABLE IF EXISTS `hc_comment_data`;
CREATE TABLE `hc_comment_data` (
  `commentid` char(30) NOT NULL DEFAULT '',
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` char(255) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `total` int(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`commentid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_config`
-- -----------------------------
DROP TABLE IF EXISTS `hc_config`;
CREATE TABLE `hc_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(60) NOT NULL DEFAULT '' COMMENT '配置说明',
  `value` text NOT NULL COMMENT '配置值',
  `fieldtype` varchar(20) NOT NULL DEFAULT '' COMMENT '字段类型',
  `setting` text COMMENT '字段设置',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_config`
-- -----------------------------
INSERT INTO `hc_config` VALUES ('1','site_name','','站点名称','海创三维科技（苏州）有限公司','','','1');
INSERT INTO `hc_config` VALUES ('2','site_url','','站点根网址','http://localhost:91/','','','1');
INSERT INTO `hc_config` VALUES ('3','site_keyword','','站点关键字','3D,专业3d打印服务,3D打印部件,3D打印服务,海创三维','','','1');
INSERT INTO `hc_config` VALUES ('4','site_description','','站点描述','海创三维科技,海创三维科技（苏州）有限公司,海创三维科技苏州有限公司,苏州海创三维科技有限公司','','','1');
INSERT INTO `hc_config` VALUES ('64','organization','99','组织架构','/uploads/202211/16/221116095610174.png','image','','1');
INSERT INTO `hc_config` VALUES ('5','site_copyright','','版权信息','© 2014-2022','','','1');
INSERT INTO `hc_config` VALUES ('71','pcdesc','99','产品中文列表描述','因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','textarea','','1');
INSERT INTO `hc_config` VALUES ('6','site_filing','','站点备案号','京ICP备666666号','','','1');
INSERT INTO `hc_config` VALUES ('7','site_code','','统计代码','','','','1');
INSERT INTO `hc_config` VALUES ('8','site_theme','','站点模板主题','company','','','1');
INSERT INTO `hc_config` VALUES ('9','site_logo','','站点logo','/uploads/202211/23/221123031833907.png','','','1');
INSERT INTO `hc_config` VALUES ('10','url_mode','','前台URL模式','1','','','1');
INSERT INTO `hc_config` VALUES ('11','is_words','','是否开启前端留言功能','1','','','1');
INSERT INTO `hc_config` VALUES ('12','upload_maxsize','','允许上传附件大小','921600','','','1');
INSERT INTO `hc_config` VALUES ('13','upload_types','','允许上传附件类型','zip|rar|mp3|mp4','','','1');
INSERT INTO `hc_config` VALUES ('14','ishtml5','','选择上传附件插件类型','1','','','1');
INSERT INTO `hc_config` VALUES ('15','watermark_enable','','是否开启图片水印','','','','1');
INSERT INTO `hc_config` VALUES ('16','watermark_name','','水印图片名称','mark.png','','','1');
INSERT INTO `hc_config` VALUES ('17','watermark_position','','水印的位置','9','','','1');
INSERT INTO `hc_config` VALUES ('18','mail_server','1','SMTP服务器','ssl://smtp.qq.com','','','1');
INSERT INTO `hc_config` VALUES ('19','mail_port','1','SMTP服务器端口','25','','','1');
INSERT INTO `hc_config` VALUES ('20','mail_from','1','SMTP服务器的用户邮箱','','','','1');
INSERT INTO `hc_config` VALUES ('21','mail_auth','1','AUTH LOGIN验证','1','','','1');
INSERT INTO `hc_config` VALUES ('22','mail_user','1','SMTP服务器的用户帐号','','','','1');
INSERT INTO `hc_config` VALUES ('23','mail_pass','1','SMTP服务器的用户密码','','','','1');
INSERT INTO `hc_config` VALUES ('24','mail_inbox','1','收件邮箱地址','','','','1');
INSERT INTO `hc_config` VALUES ('25','admin_log','2','启用后台管理操作日志','','','','1');
INSERT INTO `hc_config` VALUES ('26','admin_prohibit_ip','2','禁止登录后台的IP','','','','1');
INSERT INTO `hc_config` VALUES ('27','prohibit_words','2','屏蔽词','她妈|它妈|他妈|你妈|去死|贱人','','','1');
INSERT INTO `hc_config` VALUES ('28','comment_check','2','是否开启评论审核','','','','1');
INSERT INTO `hc_config` VALUES ('29','comment_tourist','2','是否允许游客评论','1','','','1');
INSERT INTO `hc_config` VALUES ('30','is_link','2','允许用户申请友情链接','','','','1');
INSERT INTO `hc_config` VALUES ('31','member_register','3','是否开启会员注册','','','','1');
INSERT INTO `hc_config` VALUES ('32','member_email','3','新会员注册是否需要邮件验证','','','','1');
INSERT INTO `hc_config` VALUES ('33','member_check','3','新会员注册是否需要管理员审核','','','','1');
INSERT INTO `hc_config` VALUES ('34','member_point','3','新会员默认积分','','','','1');
INSERT INTO `hc_config` VALUES ('35','member_yzm','3','是否开启会员登录验证码','1','','','1');
INSERT INTO `hc_config` VALUES ('36','rmb_point_rate','3','1元人民币购买积分数量','10','','','1');
INSERT INTO `hc_config` VALUES ('37','login_point','3','每日登录奖励积分','1','','','1');
INSERT INTO `hc_config` VALUES ('38','comment_point','3','发布评论奖励积分','1','','','1');
INSERT INTO `hc_config` VALUES ('39','publish_point','3','投稿奖励积分','3','','','1');
INSERT INTO `hc_config` VALUES ('40','qq_app_id','3','QQ App ID','','','','1');
INSERT INTO `hc_config` VALUES ('41','qq_app_key','3','QQ App key','','','','1');
INSERT INTO `hc_config` VALUES ('42','weibo_key','4','微博登录App Key','','','','1');
INSERT INTO `hc_config` VALUES ('43','weibo_secret','4','微博登录App Secret','','','','1');
INSERT INTO `hc_config` VALUES ('44','wx_appid','4','微信开发者ID','','','','1');
INSERT INTO `hc_config` VALUES ('45','wx_secret','4','微信开发者密码','','','','1');
INSERT INTO `hc_config` VALUES ('46','wx_token','4','微信Token签名','','','','1');
INSERT INTO `hc_config` VALUES ('47','wx_encodingaeskey','4','微信EncodingAESKey','','','','1');
INSERT INTO `hc_config` VALUES ('48','wx_relation_model','4','微信关联模型','article','','','1');
INSERT INTO `hc_config` VALUES ('49','baidu_push_token','','百度推送token','','','','1');
INSERT INTO `hc_config` VALUES ('50','thumb_width','2','缩略图默认宽度','500','','','1');
INSERT INTO `hc_config` VALUES ('51','thumb_height','2','缩略图默认高度','300','','','1');
INSERT INTO `hc_config` VALUES ('52','site_seo_division','','站点标题分隔符','_','','','1');
INSERT INTO `hc_config` VALUES ('53','keyword_link','2','是否启用关键字替换','','','','1');
INSERT INTO `hc_config` VALUES ('54','keyword_replacenum','2','关键字替换次数','1','','','1');
INSERT INTO `hc_config` VALUES ('55','error_log_save','2','是否保存系统错误日志','1','','','1');
INSERT INTO `hc_config` VALUES ('56','comment_code','2','是否开启评论验证码','','','','1');
INSERT INTO `hc_config` VALUES ('57','site_wap_open','','是否启用手机站点','1','','','1');
INSERT INTO `hc_config` VALUES ('58','site_wap_theme','','WAP端模板风格','default','','','1');
INSERT INTO `hc_config` VALUES ('59','member_theme','3','会员中心模板风格','default','','','1');
INSERT INTO `hc_config` VALUES ('60','att_relation_content','1','是否开启内容附件关联','','','','1');
INSERT INTO `hc_config` VALUES ('61','site_seo_suffix','','站点SEO后缀','','','','1');
INSERT INTO `hc_config` VALUES ('62','is_words_chinese','3','前端留言须包含为中文内容','','','','1');
INSERT INTO `hc_config` VALUES ('65','comanydesc','99','公司简介','位于苏州工业园区，引进西安交通大学、国家增材制造创新中心院士团队的核心技术，致力于新产品的快速制造和先进制造行业应用的技术公司；主要面向长三角地区内外资企业提供先进的制造技术装备、服务以及技术咨询，从事与快速制造相关的工业设计、快速成型、快速模具、金属加工、精密模具和精密制造等方面的应用技术研究和工程应用服务。\r\n为工厂，企业，科研院校等提供技术服务，设备和应用的定制开发，新工艺新材料的应用；产品研发试制及小批量产品制造应用，为客户在新产品的开发阶段提供更好的解决方案。应用领域包括：航空航天、辅助医疗器、通讯电子、仪器仪表、汽车零部件、金属加工、 汽车新车开发试制、教学模型、建筑设计、文化创意等。','textarea','','1');
INSERT INTO `hc_config` VALUES ('72','ensite','99','英文网站地址','http://175.27.213.230:81/','textarea','','1');
INSERT INTO `hc_config` VALUES ('66','rongyuc','99','荣誉证书中文','/uploads/202211/16/221116095548250.png','image','','1');
INSERT INTO `hc_config` VALUES ('67','rongyue','99','荣誉证书英文','/uploads/202211/16/221116095600970.png','image','','1');
INSERT INTO `hc_config` VALUES ('68','phone','99','联系电话','15250018006','textarea','','1');
INSERT INTO `hc_config` VALUES ('69','address','99','地址','苏州工业园区东旺路8号','textarea','','1');
INSERT INTO `hc_config` VALUES ('70','email','99','邮箱','qhyft@163.com','textarea','','1');

-- -----------------------------
-- Table structure for `hc_download`
-- -----------------------------
DROP TABLE IF EXISTS `hc_download`;
CREATE TABLE `hc_download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(180) NOT NULL DEFAULT '',
  `color` char(9) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `copyfrom` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `flag` varchar(12) NOT NULL DEFAULT '' COMMENT '1置顶,2头条,3特荐,4推荐,5热点,6幻灯,7跳转',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groupids_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '收费类型',
  `is_push` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否百度推送',
  `down_url` varchar(200) NOT NULL DEFAULT '' COMMENT '下载地址',
  `copytype` varchar(30) NOT NULL DEFAULT '' COMMENT '授权形式',
  `systems` varchar(100) NOT NULL DEFAULT '' COMMENT '平台',
  `language` varchar(30) NOT NULL DEFAULT '' COMMENT '语言',
  `version` varchar(30) NOT NULL DEFAULT '' COMMENT '版本',
  `filesize` varchar(10) NOT NULL DEFAULT '' COMMENT '文件大小',
  `classtype` varchar(30) NOT NULL DEFAULT '' COMMENT '软件类型',
  `stars` varchar(10) NOT NULL DEFAULT '' COMMENT '评分等级',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`),
  KEY `catid` (`catid`,`status`),
  KEY `userid` (`userid`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_favorite`
-- -----------------------------
DROP TABLE IF EXISTS `hc_favorite`;
CREATE TABLE `hc_favorite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` char(100) NOT NULL DEFAULT '',
  `url` char(100) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_guestbook`
-- -----------------------------
DROP TABLE IF EXISTS `hc_guestbook`;
CREATE TABLE `hc_guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '' COMMENT '主题',
  `booktime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '名字',
  `email` varchar(40) NOT NULL DEFAULT '' COMMENT '留言人电子邮箱',
  `phone` varchar(11) NOT NULL DEFAULT '' COMMENT '留言人电话',
  `qq` varchar(11) NOT NULL DEFAULT '' COMMENT '留言人qq',
  `address` varchar(100) NOT NULL DEFAULT '' COMMENT '留言人地址',
  `bookmsg` text NOT NULL COMMENT '内容',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `ischeck` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否审核',
  `isread` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否读过',
  `ispc` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1电脑,0手机',
  `replyid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复的id',
  PRIMARY KEY (`id`),
  KEY `index_booktime` (`booktime`),
  KEY `index_replyid` (`replyid`),
  KEY `index_ischeck` (`siteid`,`ischeck`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_guestbook`
-- -----------------------------
INSERT INTO `hc_guestbook` VALUES ('1','','111','1665973736','111','111@123.com','111','111','111','111','127.0.0.1','1','1','1','');
INSERT INTO `hc_guestbook` VALUES ('2','','dsa','1665973910','dsa','a11523518@126.com','das','dsa','das','dsadas','127.0.0.1','1','1','1','');
INSERT INTO `hc_guestbook` VALUES ('3','','title','1665974718','admin','a11523518@126.com','','','','dsasd','127.0.0.1','1','1','1','');
INSERT INTO `hc_guestbook` VALUES ('4','','title','1668043119','11111','a11523518@126.com','','','','111111111111111','127.0.0.1','','1','1','');

-- -----------------------------
-- Table structure for `hc_keyword_link`
-- -----------------------------
DROP TABLE IF EXISTS `hc_keyword_link`;
CREATE TABLE `hc_keyword_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(36) NOT NULL DEFAULT '' COMMENT '关键字',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_link`
-- -----------------------------
DROP TABLE IF EXISTS `hc_link`;
CREATE TABLE `hc_link` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1首页,2列表页,3内容页',
  `linktype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:文字链接,1:logo链接',
  `name` varchar(50) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `msg` text NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(40) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未通过,1正常,2未审核',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_link`
-- -----------------------------
INSERT INTO `hc_link` VALUES ('36','','1','1','12','http://www.baidu13.com','/uploads/202211/03/221103044428983.png','','','','13','1','1667465070');
INSERT INTO `hc_link` VALUES ('35','','1','1','12','http://www.baidu12.com','/uploads/202211/03/221103044357147.png','','','','12','1','1667465040');
INSERT INTO `hc_link` VALUES ('34','','1','1','11','http://www.baidu11.com','/uploads/202211/03/221103044332828.png','','','','11','1','1667465015');
INSERT INTO `hc_link` VALUES ('33','','1','1','10','http://www.baidu10.com','/uploads/202211/03/221103044315534.png','','','','10','1','1667464999');
INSERT INTO `hc_link` VALUES ('24','','1','1','1','http://www.baidu.com','/uploads/202211/03/221103043758147.png','','','','1','1','1667464692');
INSERT INTO `hc_link` VALUES ('25','','1','1','2','http://www.baidu2.com','/uploads/202211/03/221103043831124.png','','','','2','1','1667464719');
INSERT INTO `hc_link` VALUES ('26','','1','1','3','http://www.baidu33.com','/uploads/202211/03/221103043855595.png','','','','3','1','1667464738');
INSERT INTO `hc_link` VALUES ('27','','1','1','4','http://www.baidu4.com','/uploads/202211/03/221103044001206.png','','','','4','1','1667464804');
INSERT INTO `hc_link` VALUES ('28','','1','1','5','http://www.baidu5.com','/uploads/202211/03/221103044055115.png','','','','5','1','1667464858');
INSERT INTO `hc_link` VALUES ('29','','1','1','6','http://www.baidu6.com','/uploads/202211/03/221103044114462.png','','','','6','1','1667464880');
INSERT INTO `hc_link` VALUES ('30','','1','1','7','http://www.baidu7.com','/uploads/202211/03/221103044154742.png','','','','7','1','1667464918');
INSERT INTO `hc_link` VALUES ('31','','1','1','8','http://www.baidu8.com','/uploads/202211/03/221103044206470.png','','','','8','1','1667464941');
INSERT INTO `hc_link` VALUES ('32','','1','1','9','http://www.baidu9.com','/uploads/202211/03/221103044237435.png','','','','9','1','1667464966');
INSERT INTO `hc_link` VALUES ('42','','1','1','19','http://www.baidu19.com','/uploads/202211/03/221103044628360.png','','','','19','1','1667465190');
INSERT INTO `hc_link` VALUES ('41','','1','1','18','http://www.baidu18.com','/uploads/202211/03/221103044611784.png','','','','18','1','1667465173');
INSERT INTO `hc_link` VALUES ('40','','1','1','17','http://www.baidu17.com','/uploads/202211/03/221103044554341.png','','','','17','1','1667465156');
INSERT INTO `hc_link` VALUES ('39','','1','1','16','http://www.baidu16.com','/uploads/202211/03/221103044529746.png','','','','16','1','1667465131');
INSERT INTO `hc_link` VALUES ('38','','1','1','15','http://www.baidu15.com','/uploads/202211/03/221103044458850.png','','','','15','1','1667465103');
INSERT INTO `hc_link` VALUES ('37','','1','1','14','http://www.baidu14.com','/uploads/202211/03/221103044443543.png','','','','14','1','1667465086');
INSERT INTO `hc_link` VALUES ('43','','1','1','20','http://www.baidu20.com','/uploads/202211/03/221103044644371.png','','','','20','1','1667465209');
INSERT INTO `hc_link` VALUES ('44','','1','1','dasdas','http://www.baidu21.com','/uploads/202211/09/221109035703566.jpg','','','','21','1','1667980636');
INSERT INTO `hc_link` VALUES ('45','','1','1','222','http://www.baidu22.com','/uploads/202211/09/221109035728996.jpg','','','','22','1','1667980654');
INSERT INTO `hc_link` VALUES ('46','','1','1','23','http://www.baidu23.com','/uploads/202211/09/221109035749253.jpg','','','','23','1','1667980675');
INSERT INTO `hc_link` VALUES ('47','','1','1','24','http://www.baidu24.com','/uploads/202211/09/221109035807143.jpg','','','','24','1','1667980692');

-- -----------------------------
-- Table structure for `hc_member`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member`;
CREATE TABLE `hc_member` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL DEFAULT '',
  `lastip` char(15) NOT NULL DEFAULT '',
  `loginnum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `email` char(32) NOT NULL DEFAULT '',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '金钱',
  `experience` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '经验',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0待审核,1正常,2锁定,3拒绝',
  `vip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `overduedate` int(10) unsigned NOT NULL DEFAULT '0',
  `email_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `problem` varchar(39) NOT NULL DEFAULT '' COMMENT '安全问题',
  `answer` varchar(30) NOT NULL DEFAULT '' COMMENT '答案',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_authorization`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_authorization`;
CREATE TABLE `hc_member_authorization` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `authname` varchar(10) NOT NULL DEFAULT '',
  `token` varchar(60) NOT NULL DEFAULT '',
  `userinfo` varchar(255) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `authindex` (`authname`,`token`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_detail`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_detail`;
CREATE TABLE `hc_member_detail` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sex` varchar(6) NOT NULL DEFAULT '',
  `realname` varchar(30) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `nickname` char(20) NOT NULL DEFAULT '',
  `qq` char(11) NOT NULL DEFAULT '',
  `mobile` char(11) NOT NULL DEFAULT '',
  `phone` char(10) NOT NULL DEFAULT '',
  `userpic` varchar(100) NOT NULL DEFAULT '',
  `birthday` char(10) NOT NULL DEFAULT '' COMMENT '生日',
  `industry` varchar(60) NOT NULL DEFAULT '' COMMENT '行业',
  `area` varchar(60) NOT NULL DEFAULT '',
  `motto` varchar(210) NOT NULL DEFAULT '' COMMENT '个性签名',
  `introduce` text COMMENT '个人简介',
  `guest` int(10) unsigned NOT NULL DEFAULT '0',
  `fans` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '粉丝数',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_follow`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_follow`;
CREATE TABLE `hc_member_follow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `followid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '被关注者id',
  `followname` varchar(30) NOT NULL DEFAULT '' COMMENT '被关注者用户名',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_group`;
CREATE TABLE `hc_member_group` (
  `groupid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(21) NOT NULL DEFAULT '',
  `experience` smallint(6) unsigned NOT NULL DEFAULT '0',
  `icon` char(30) NOT NULL DEFAULT '' COMMENT '图标',
  `authority` char(12) NOT NULL DEFAULT '' COMMENT '1短消息,2发表评论,3发表内容',
  `max_amount` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '每日最大投稿量',
  `description` char(100) NOT NULL DEFAULT '',
  `is_system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统内置',
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_member_group`
-- -----------------------------
INSERT INTO `hc_member_group` VALUES ('1','初来乍到','50','icon1.png','1,2','1','初来乍到组','1');
INSERT INTO `hc_member_group` VALUES ('2','新手上路','100','icon2.png','1,2','2','新手上路组','1');
INSERT INTO `hc_member_group` VALUES ('3','中级会员','200','icon3.png','1,2,3','3','中级会员组','1');
INSERT INTO `hc_member_group` VALUES ('4','高级会员','300','icon4.png','1,2,3','4','高级会员组','1');
INSERT INTO `hc_member_group` VALUES ('5','金牌会员','500','icon5.png','1,2,3,4','5','金牌会员组','1');

-- -----------------------------
-- Table structure for `hc_member_guest`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_guest`;
CREATE TABLE `hc_member_guest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `space_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guest_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guest_name` varchar(30) NOT NULL DEFAULT '',
  `guest_pic` varchar(100) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `space_id` (`space_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_menu`
-- -----------------------------
DROP TABLE IF EXISTS `hc_menu`;
CREATE TABLE `hc_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL DEFAULT '',
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL DEFAULT '',
  `c` char(20) NOT NULL DEFAULT '',
  `a` char(30) NOT NULL DEFAULT '',
  `data` char(100) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `parentid` (`parentid`),
  KEY `module` (`m`,`c`,`a`)
) ENGINE=MyISAM AUTO_INCREMENT=314 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_menu`
-- -----------------------------
INSERT INTO `hc_menu` VALUES ('1','内容管理','','admin','content','top','yzm-iconneirong','1','1');
INSERT INTO `hc_menu` VALUES ('2','会员管理','','member','member','top','yzm-iconyonghu','2','1');
INSERT INTO `hc_menu` VALUES ('3','模块管理','','admin','module','top','yzm-icondaohang','3','1');
INSERT INTO `hc_menu` VALUES ('4','管理员管理','','admin','admin_manage','top','yzm-iconguanliyuan','4','1');
INSERT INTO `hc_menu` VALUES ('5','个人信息','','admin','admin_manage','top','yzm-iconrizhi','5','');
INSERT INTO `hc_menu` VALUES ('6','系统管理','','admin','system_manage','top','yzm-iconshezhi','6','1');
INSERT INTO `hc_menu` VALUES ('7','数据管理','','admin','database','top','yzm-iconshujuku','7','1');
INSERT INTO `hc_menu` VALUES ('8','稿件管理','1','admin','admin_content','init','','13','1');
INSERT INTO `hc_menu` VALUES ('9','稿件浏览','8','admin','admin_content','public_preview','','','');
INSERT INTO `hc_menu` VALUES ('10','稿件删除','8','admin','admin_content','del','','','');
INSERT INTO `hc_menu` VALUES ('11','通过审核','8','admin','admin_content','adopt','','','');
INSERT INTO `hc_menu` VALUES ('12','退稿','8','admin','admin_content','rejection','','','');
INSERT INTO `hc_menu` VALUES ('13','后台操作日志','6','admin','admin_log','init','','66','1');
INSERT INTO `hc_menu` VALUES ('14','操作日志删除','13','admin','admin_log','del_log','','','');
INSERT INTO `hc_menu` VALUES ('15','操作日志搜索','13','admin','admin_log','search_log','','','');
INSERT INTO `hc_menu` VALUES ('16','后台登录日志','6','admin','admin_log','admin_login_log_list','','67','1');
INSERT INTO `hc_menu` VALUES ('17','登录日志删除','16','admin','admin_log','del_login_log','','','');
INSERT INTO `hc_menu` VALUES ('18','管理员管理','4','admin','admin_manage','init','','','1');
INSERT INTO `hc_menu` VALUES ('19','删除管理员','18','admin','admin_manage','delete','','','');
INSERT INTO `hc_menu` VALUES ('20','添加管理员','18','admin','admin_manage','add','','','');
INSERT INTO `hc_menu` VALUES ('21','编辑管理员','18','admin','admin_manage','edit','','','');
INSERT INTO `hc_menu` VALUES ('22','修改资料','18','admin','admin_manage','public_edit_info','','','1');
INSERT INTO `hc_menu` VALUES ('23','修改密码','18','admin','admin_manage','public_edit_pwd','','','1');
INSERT INTO `hc_menu` VALUES ('24','栏目管理','1','admin','category','init','','11','1');
INSERT INTO `hc_menu` VALUES ('25','排序栏目','24','admin','category','order','','','');
INSERT INTO `hc_menu` VALUES ('26','删除栏目','24','admin','category','delete','','','');
INSERT INTO `hc_menu` VALUES ('27','添加栏目','24','admin','category','add','','','');
INSERT INTO `hc_menu` VALUES ('28','编辑栏目','24','admin','category','edit','','','');
INSERT INTO `hc_menu` VALUES ('29','编辑单页内容','24','admin','category','page_content','','','');
INSERT INTO `hc_menu` VALUES ('30','内容管理','1','admin','content','init','','10','1');
INSERT INTO `hc_menu` VALUES ('31','内容搜索','30','admin','content','search','','','');
INSERT INTO `hc_menu` VALUES ('32','添加内容','30','admin','content','add','','','');
INSERT INTO `hc_menu` VALUES ('33','修改内容','30','admin','content','edit','','','');
INSERT INTO `hc_menu` VALUES ('34','删除内容','30','admin','content','del','','','');
INSERT INTO `hc_menu` VALUES ('35','数据备份','7','admin','database','init','','70','1');
INSERT INTO `hc_menu` VALUES ('36','数据还原','7','admin','database','databack_list','','71','1');
INSERT INTO `hc_menu` VALUES ('37','优化表','35','admin','database','public_optimize','','','');
INSERT INTO `hc_menu` VALUES ('38','修复表','35','admin','database','public_repair','','','');
INSERT INTO `hc_menu` VALUES ('39','备份文件删除','36','admin','database','databack_del','','','');
INSERT INTO `hc_menu` VALUES ('40','备份文件下载','36','admin','database','databack_down','','','');
INSERT INTO `hc_menu` VALUES ('41','数据导入','36','admin','database','import','','','');
INSERT INTO `hc_menu` VALUES ('42','字段管理','54','admin','model_field','init','','','1');
INSERT INTO `hc_menu` VALUES ('43','添加字段','42','admin','model_field','add','','','');
INSERT INTO `hc_menu` VALUES ('44','修改字段','42','admin','model_field','edit','','','');
INSERT INTO `hc_menu` VALUES ('45','删除字段','42','admin','model_field','delete','','','');
INSERT INTO `hc_menu` VALUES ('46','排序字段','42','admin','model_field','order','','','');
INSERT INTO `hc_menu` VALUES ('47','模块管理','3','admin','module','init','','','1');
INSERT INTO `hc_menu` VALUES ('48','模块安装','47','admin','module','install','','','');
INSERT INTO `hc_menu` VALUES ('49','模块卸载','47','admin','module','uninstall','','','');
INSERT INTO `hc_menu` VALUES ('50','角色管理','4','admin','role','init','','','1');
INSERT INTO `hc_menu` VALUES ('51','删除角色','50','admin','role','delete','','','');
INSERT INTO `hc_menu` VALUES ('52','添加角色','50','admin','role','add','','','');
INSERT INTO `hc_menu` VALUES ('53','编辑角色','50','admin','role','edit','','','');
INSERT INTO `hc_menu` VALUES ('54','模型管理','1','admin','sitemodel','init','','15','1');
INSERT INTO `hc_menu` VALUES ('55','删除模型','54','admin','sitemodel','delete','','','');
INSERT INTO `hc_menu` VALUES ('56','添加模型','54','admin','sitemodel','add','','','');
INSERT INTO `hc_menu` VALUES ('57','编辑模型','54','admin','sitemodel','edit','','','');
INSERT INTO `hc_menu` VALUES ('58','系统设置','6','admin','system_manage','init','','60','1');
INSERT INTO `hc_menu` VALUES ('59','会员中心设置','2','admin','system_manage','member_set','','26','1');
INSERT INTO `hc_menu` VALUES ('60','屏蔽词管理','6','admin','system_manage','prohibit_words','','63','1');
INSERT INTO `hc_menu` VALUES ('61','自定义配置','6','admin','system_manage','user_config_list','','62','1');
INSERT INTO `hc_menu` VALUES ('62','添加配置','61','admin','system_manage','user_config_add','','','');
INSERT INTO `hc_menu` VALUES ('63','配置编辑','61','admin','system_manage','user_config_edit','','','');
INSERT INTO `hc_menu` VALUES ('64','配置删除','61','admin','system_manage','user_config_del','','','');
INSERT INTO `hc_menu` VALUES ('65','TAG管理','1','admin','tag','init','','16','1');
INSERT INTO `hc_menu` VALUES ('66','添加TAG','65','admin','tag','add','','','');
INSERT INTO `hc_menu` VALUES ('67','编辑TAG','65','admin','tag','edit','','','');
INSERT INTO `hc_menu` VALUES ('68','删除TAG','65','admin','tag','del','','','');
INSERT INTO `hc_menu` VALUES ('69','批量更新URL','1','admin','update_urls','init','','17','1');
INSERT INTO `hc_menu` VALUES ('70','附件管理','1','attachment','index','init','','14','1');
INSERT INTO `hc_menu` VALUES ('71','附件搜索','70','attachment','index','search_list','','','');
INSERT INTO `hc_menu` VALUES ('72','附件浏览','70','attachment','index','public_att_view','','','');
INSERT INTO `hc_menu` VALUES ('73','删除单个附件','70','attachment','index','del_one','','','');
INSERT INTO `hc_menu` VALUES ('74','删除多个附件','70','attachment','index','del','','','');
INSERT INTO `hc_menu` VALUES ('75','评论管理','1','comment','comment','init','','12','1');
INSERT INTO `hc_menu` VALUES ('76','评论搜索','75','comment','comment','search','','','');
INSERT INTO `hc_menu` VALUES ('77','删除评论','75','comment','comment','del','','','');
INSERT INTO `hc_menu` VALUES ('78','评论审核','75','comment','comment','adopt','','','');
INSERT INTO `hc_menu` VALUES ('79','留言管理','3','guestbook','guestbook','init','','1','1');
INSERT INTO `hc_menu` VALUES ('80','查看及回复留言','79','guestbook','guestbook','read','','','');
INSERT INTO `hc_menu` VALUES ('81','留言审核','79','guestbook','guestbook','toggle','','','');
INSERT INTO `hc_menu` VALUES ('82','删除留言','79','guestbook','guestbook','del','','','');
INSERT INTO `hc_menu` VALUES ('88','会员管理','2','member','member','init','','20','1');
INSERT INTO `hc_menu` VALUES ('89','会员搜索','88','member','member','search','','','');
INSERT INTO `hc_menu` VALUES ('90','添加会员','88','member','member','add','','','');
INSERT INTO `hc_menu` VALUES ('91','修改会员信息','88','member','member','edit','','','');
INSERT INTO `hc_menu` VALUES ('92','修改会员密码','88','member','member','password','','','');
INSERT INTO `hc_menu` VALUES ('93','删除会员','88','member','member','del','','','');
INSERT INTO `hc_menu` VALUES ('94','审核会员','2','member','member','check','','21','1');
INSERT INTO `hc_menu` VALUES ('95','通过审核','94','member','member','adopt','','','');
INSERT INTO `hc_menu` VALUES ('96','锁定用户','88','member','member','lock','','','');
INSERT INTO `hc_menu` VALUES ('97','解锁用户','88','member','member','unlock','','','');
INSERT INTO `hc_menu` VALUES ('98','账单管理','2','member','member','pay','','22','1');
INSERT INTO `hc_menu` VALUES ('99','入账记录搜索','98','member','member','pay_search','','','');
INSERT INTO `hc_menu` VALUES ('100','入账记录删除','98','member','member','pay_del','','','');
INSERT INTO `hc_menu` VALUES ('101','消费记录','98','member','member','pay_spend','','','');
INSERT INTO `hc_menu` VALUES ('102','消费记录搜索','98','member','member','pay_spend_search','','','');
INSERT INTO `hc_menu` VALUES ('103','消费记录删除','98','member','member','pay_spend_del','','','');
INSERT INTO `hc_menu` VALUES ('104','会员组管理','2','member','member_group','init','','25','1');
INSERT INTO `hc_menu` VALUES ('105','添加组别','104','member','member_group','add','','','');
INSERT INTO `hc_menu` VALUES ('106','修改组别','104','member','member_group','edit','','','');
INSERT INTO `hc_menu` VALUES ('107','删除组别','104','member','member_group','del','','','');
INSERT INTO `hc_menu` VALUES ('108','消息管理','2','member','member_message','init','','23','1');
INSERT INTO `hc_menu` VALUES ('109','消息搜索','108','member','member_message','search','','','');
INSERT INTO `hc_menu` VALUES ('110','删除消息','108','member','member_message','del','','','');
INSERT INTO `hc_menu` VALUES ('111','发送单个消息','108','member','member_message','add','','','');
INSERT INTO `hc_menu` VALUES ('112','群发消息','2','member','member_message','messages_list','','23','1');
INSERT INTO `hc_menu` VALUES ('113','新建群发','112','member','member_message','add_messages','','','');
INSERT INTO `hc_menu` VALUES ('114','删除群发消息','112','member','member_message','del_messages','','','');
INSERT INTO `hc_menu` VALUES ('115','权限管理','50','admin','role','role_priv','','','');
INSERT INTO `hc_menu` VALUES ('116','后台菜单管理','6','admin','menu','init','','64','1');
INSERT INTO `hc_menu` VALUES ('117','删除菜单','116','admin','menu','delete','','','');
INSERT INTO `hc_menu` VALUES ('118','添加菜单','116','admin','menu','add','','','');
INSERT INTO `hc_menu` VALUES ('119','编辑菜单','116','admin','menu','edit','','','');
INSERT INTO `hc_menu` VALUES ('120','菜单排序','116','admin','menu','order','','','');
INSERT INTO `hc_menu` VALUES ('121','邮箱配置','6','admin','system_manage','init','tab=3','61','1');
INSERT INTO `hc_menu` VALUES ('122','修改资料','5','admin','admin_manage','public_edit_info','','51','1');
INSERT INTO `hc_menu` VALUES ('123','修改密码','5','admin','admin_manage','public_edit_pwd','','52','1');
INSERT INTO `hc_menu` VALUES ('134','友情链接管理','3','link','link','init','','6','1');
INSERT INTO `hc_menu` VALUES ('135','添加友情链接','134','link','link','add','','','');
INSERT INTO `hc_menu` VALUES ('136','修改友情链接','134','link','link','edit','','','');
INSERT INTO `hc_menu` VALUES ('137','删除单个友情链接','134','link','link','del_one','','','');
INSERT INTO `hc_menu` VALUES ('138','删除多个友情链接','134','link','link','del','','','');
INSERT INTO `hc_menu` VALUES ('139','URL规则管理','6','admin','urlrule','init','','65','1');
INSERT INTO `hc_menu` VALUES ('140','添加URL规则','139','admin','urlrule','add','','','');
INSERT INTO `hc_menu` VALUES ('141','删除URL规则','139','admin','urlrule','del','','','');
INSERT INTO `hc_menu` VALUES ('142','编辑URL规则','139','admin','urlrule','edit','','','');
INSERT INTO `hc_menu` VALUES ('143','批量移动','30','admin','content','remove','','','');
INSERT INTO `hc_menu` VALUES ('144','SQL命令行','6','admin','sql','init','','63','1');
INSERT INTO `hc_menu` VALUES ('145','提交SQL命令','144','admin','sql','do_sql','','','');
INSERT INTO `hc_menu` VALUES ('156','轮播图管理','3','banner','banner','init','','1','1');
INSERT INTO `hc_menu` VALUES ('157','添加轮播','156','banner','banner','add','','','');
INSERT INTO `hc_menu` VALUES ('158','修改轮播','156','banner','banner','edit','','','');
INSERT INTO `hc_menu` VALUES ('159','删除轮播','156','banner','banner','del','','','');
INSERT INTO `hc_menu` VALUES ('160','添加轮播分类','156','banner','banner','cat_add','','','');
INSERT INTO `hc_menu` VALUES ('161','管理轮播分类','156','banner','banner','cat_manage','','','');
INSERT INTO `hc_menu` VALUES ('162','会员统计','2','member','member','member_count','','24','1');
INSERT INTO `hc_menu` VALUES ('165','采集管理','3','collection','collection_content','init','','','1');
INSERT INTO `hc_menu` VALUES ('166','添加采集节点','165','collection','collection_content','add','','','');
INSERT INTO `hc_menu` VALUES ('167','编辑采集节点','165','collection','collection_content','edit','','','');
INSERT INTO `hc_menu` VALUES ('168','删除采集节点','165','collection','collection_content','del','','','');
INSERT INTO `hc_menu` VALUES ('169','采集测试','165','collection','collection_content','collection_test','','','');
INSERT INTO `hc_menu` VALUES ('170','采集网址','165','collection','collection_content','collection_list_url','','','');
INSERT INTO `hc_menu` VALUES ('171','采集内容','165','collection','collection_content','collection_article_content','','','');
INSERT INTO `hc_menu` VALUES ('172','内容导入','165','collection','collection_content','collection_content_import','','','');
INSERT INTO `hc_menu` VALUES ('173','新建内容发布方案','165','collection','collection_content','create_programme','','','');
INSERT INTO `hc_menu` VALUES ('174','采集列表','165','collection','collection_content','collection_list','','','');
INSERT INTO `hc_menu` VALUES ('175','删除采集列表','165','collection','collection_content','collection_list_del','','','');
INSERT INTO `hc_menu` VALUES ('200','微信管理','','wechat','wechat','top','yzm-iconweixin','3','1');
INSERT INTO `hc_menu` VALUES ('201','微信配置','200','wechat','config','init','','','1');
INSERT INTO `hc_menu` VALUES ('202','保存配置','201','wechat','config','save','','','');
INSERT INTO `hc_menu` VALUES ('203','微信用户','200','wechat','user','init','','','1');
INSERT INTO `hc_menu` VALUES ('204','关注者搜索','203','wechat','user','search','','','');
INSERT INTO `hc_menu` VALUES ('205','获取分组名称','203','wechat','user','get_groupname','','','');
INSERT INTO `hc_menu` VALUES ('206','同步微信服务器用户','203','wechat','user','synchronization','','','');
INSERT INTO `hc_menu` VALUES ('207','批量移动用户分组','203','wechat','user','move_user_group','','','');
INSERT INTO `hc_menu` VALUES ('208','设置用户备注','203','wechat','user','set_userremark','','','');
INSERT INTO `hc_menu` VALUES ('209','查询用户所在组','203','wechat','user','select_user_group','','','');
INSERT INTO `hc_menu` VALUES ('210','分组管理','200','wechat','group','init','','','1');
INSERT INTO `hc_menu` VALUES ('211','创建分组','210','wechat','group','add','','','');
INSERT INTO `hc_menu` VALUES ('212','修改分组','210','wechat','group','edit','','','');
INSERT INTO `hc_menu` VALUES ('213','删除分组','210','wechat','group','delete','','','');
INSERT INTO `hc_menu` VALUES ('214','查询所有分组','210','wechat','group','select_group','','','');
INSERT INTO `hc_menu` VALUES ('215','微信菜单','200','wechat','menu','init','','','1');
INSERT INTO `hc_menu` VALUES ('216','添加菜单','215','wechat','menu','add','','','');
INSERT INTO `hc_menu` VALUES ('217','编辑菜单','215','wechat','menu','edit','','','');
INSERT INTO `hc_menu` VALUES ('218','删除菜单','215','wechat','menu','delete','','','');
INSERT INTO `hc_menu` VALUES ('219','菜单排序','215','wechat','menu','order','','','');
INSERT INTO `hc_menu` VALUES ('220','创建菜单提交微信','215','wechat','menu','create_menu','','','');
INSERT INTO `hc_menu` VALUES ('221','查询远程菜单','215','wechat','menu','select_menu','','','');
INSERT INTO `hc_menu` VALUES ('222','删除所有菜单提交微信','215','wechat','menu','delete_menu','','','');
INSERT INTO `hc_menu` VALUES ('223','消息回复','200','wechat','reply','init','','','1');
INSERT INTO `hc_menu` VALUES ('224','自动回复/关注回复','223','wechat','reply','reply_list','','','');
INSERT INTO `hc_menu` VALUES ('225','添加关键字回复','223','wechat','reply','add','','','');
INSERT INTO `hc_menu` VALUES ('226','修改关键字回复','223','wechat','reply','edit','','','');
INSERT INTO `hc_menu` VALUES ('227','删除关键字回复','223','wechat','reply','del','','','');
INSERT INTO `hc_menu` VALUES ('228','选择文章','223','wechat','reply','select_article','','','');
INSERT INTO `hc_menu` VALUES ('229','消息管理','200','wechat','message','init','','','1');
INSERT INTO `hc_menu` VALUES ('230','用户发送信息','229','wechat','message','send_message','','','');
INSERT INTO `hc_menu` VALUES ('231','标识已读','229','wechat','message','read','','','');
INSERT INTO `hc_menu` VALUES ('232','删除消息','229','wechat','message','del','','','');
INSERT INTO `hc_menu` VALUES ('233','微信场景','200','wechat','scan','init','','','1');
INSERT INTO `hc_menu` VALUES ('234','添加场景','233','wechat','scan','add','','','');
INSERT INTO `hc_menu` VALUES ('235','编辑场景','233','wechat','scan','edit','','','');
INSERT INTO `hc_menu` VALUES ('236','删除场景','233','wechat','scan','del','','','');
INSERT INTO `hc_menu` VALUES ('237','素材管理','200','wechat','material','init','','','1');
INSERT INTO `hc_menu` VALUES ('238','素材搜索','237','wechat','material','search','','','');
INSERT INTO `hc_menu` VALUES ('239','添加素材','237','wechat','material','add','','','');
INSERT INTO `hc_menu` VALUES ('240','添加图文素材','237','wechat','material','add_news','','','');
INSERT INTO `hc_menu` VALUES ('241','删除素材','237','wechat','material','delete','','','');
INSERT INTO `hc_menu` VALUES ('242','选择缩略图','237','wechat','material','select_thumb','','','');
INSERT INTO `hc_menu` VALUES ('243','获取永久素材列表','237','wechat','material','get_material_list','','','');
INSERT INTO `hc_menu` VALUES ('244','高级群发','200','wechat','mass','init','','','1');
INSERT INTO `hc_menu` VALUES ('245','新建群发','244','wechat','mass','add','','','');
INSERT INTO `hc_menu` VALUES ('246','查询群发状态','244','wechat','mass','select_status','','','');
INSERT INTO `hc_menu` VALUES ('247','删除群发','244','wechat','mass','del','','','');
INSERT INTO `hc_menu` VALUES ('248','选择素材','244','wechat','mass','select_material','','','');
INSERT INTO `hc_menu` VALUES ('249','选择用户','244','wechat','mass','select_user','','','');
INSERT INTO `hc_menu` VALUES ('250','自定义表单','3','diyform','diyform','init','','2','1');
INSERT INTO `hc_menu` VALUES ('251','添加表单','250','diyform','diyform','add','','','');
INSERT INTO `hc_menu` VALUES ('252','编辑表单','250','diyform','diyform','edit','','','');
INSERT INTO `hc_menu` VALUES ('253','删除表单','250','diyform','diyform','del','','','');
INSERT INTO `hc_menu` VALUES ('254','字段列表','250','diyform','diyform_field','init','','','');
INSERT INTO `hc_menu` VALUES ('255','添加字段','254','diyform','diyform_field','add','','','');
INSERT INTO `hc_menu` VALUES ('256','修改字段','254','diyform','diyform_field','edit','','','');
INSERT INTO `hc_menu` VALUES ('257','删除字段','254','diyform','diyform_field','delete','','','');
INSERT INTO `hc_menu` VALUES ('258','排序排序','254','diyform','diyform_field','order','','','');
INSERT INTO `hc_menu` VALUES ('259','表单信息列表','250','diyform','diyform_info','init','','','');
INSERT INTO `hc_menu` VALUES ('260','查看表单信息','259','diyform','diyform_info','view','','','');
INSERT INTO `hc_menu` VALUES ('261','删除表单信息','259','diyform','diyform_info','del','','','');
INSERT INTO `hc_menu` VALUES ('262','广告管理','3','adver','adver','init','','','1');
INSERT INTO `hc_menu` VALUES ('263','添加广告','262','adver','adver','add','','','');
INSERT INTO `hc_menu` VALUES ('264','修改广告','262','adver','adver','edit','','','');
INSERT INTO `hc_menu` VALUES ('265','删除广告','262','adver','adver','del','','','');
INSERT INTO `hc_menu` VALUES ('266','网站地图','1','admin','sitemap','init','','16','1');
INSERT INTO `hc_menu` VALUES ('267','生成地图','266','admin','sitemap','make_sitemap','','','');
INSERT INTO `hc_menu` VALUES ('268','导出模型','54','admin','sitemodel','import','','','');
INSERT INTO `hc_menu` VALUES ('269','导入模型','54','admin','sitemodel','export','','','');
INSERT INTO `hc_menu` VALUES ('270','导出配置','61','admin','system_manage','user_config_export','','','');
INSERT INTO `hc_menu` VALUES ('271','导入配置','61','admin','system_manage','user_config_import','','','');
INSERT INTO `hc_menu` VALUES ('283','支付模块','3','pay','pay','init','','','1');
INSERT INTO `hc_menu` VALUES ('284','支付配置','283','pay','pay','edit','','','');
INSERT INTO `hc_menu` VALUES ('285','订单管理','2','member','order','init','','22','1');
INSERT INTO `hc_menu` VALUES ('286','订单搜索','285','member','order','order_search','','','');
INSERT INTO `hc_menu` VALUES ('287','订单改价','285','member','order','change_price','','','');
INSERT INTO `hc_menu` VALUES ('288','订单删除','285','member','order','del','','','');
INSERT INTO `hc_menu` VALUES ('289','订单详情','285','member','order','order_details','','','');
INSERT INTO `hc_menu` VALUES ('290','推送至百度','30','admin','content','baidu_push','','','');
INSERT INTO `hc_menu` VALUES ('291','增加/删除内容属性','30','admin','content','attribute_operation','','','');
INSERT INTO `hc_menu` VALUES ('292','更改model','69','admin','update_urls','change_model','','','');
INSERT INTO `hc_menu` VALUES ('293','更新栏目URL','69','admin','update_urls','update_category_url','','','');
INSERT INTO `hc_menu` VALUES ('294','更新内容页URL','69','admin','update_urls','update_content_url','','','');
INSERT INTO `hc_menu` VALUES ('295','留言搜索','79','guestbook','guestbook','search','','','');
INSERT INTO `hc_menu` VALUES ('296','内容关键字','3','admin','keyword_link','init','','1','1');
INSERT INTO `hc_menu` VALUES ('297','添加关键字','296','admin','keyword_link','add','','','');
INSERT INTO `hc_menu` VALUES ('298','编辑关键字','296','admin','keyword_link','edit','','','');
INSERT INTO `hc_menu` VALUES ('299','删除关键字','296','admin','keyword_link','del','','','');
INSERT INTO `hc_menu` VALUES ('300','应用商店','3','admin','store','init','','','1');
INSERT INTO `hc_menu` VALUES ('301','批量添加栏目','24','admin','category','adds','','','');
INSERT INTO `hc_menu` VALUES ('302','内容复制','30','admin','content','copy','','','');
INSERT INTO `hc_menu` VALUES ('303','内容管理','65','admin','tag','content','','','');
INSERT INTO `hc_menu` VALUES ('304','加入/移除Tag','65','admin','tag','content_oper','','','');
INSERT INTO `hc_menu` VALUES ('305','删除地图','266','admin','sitemap','delete','','','');
INSERT INTO `hc_menu` VALUES ('306','保存配置','58','admin','system_manage','save','','','');
INSERT INTO `hc_menu` VALUES ('307','立即备份','35','admin','database','export_list','','','');
INSERT INTO `hc_menu` VALUES ('308','管理非自己发布的内容','30','admin','content','all_content','','','');
INSERT INTO `hc_menu` VALUES ('309','在线充值','88','member','member','recharge','','','');
INSERT INTO `hc_menu` VALUES ('310','登录到任意会员中心','88','member','member','login_user','','','');
INSERT INTO `hc_menu` VALUES ('311','友情链接排序','134','link','link','order','','','');
INSERT INTO `hc_menu` VALUES ('312','友情链接审核','134','link','link','adopt','','','');
INSERT INTO `hc_menu` VALUES ('313','标识已读','79','guestbook','guestbook','set_read','','','');

-- -----------------------------
-- Table structure for `hc_message`
-- -----------------------------
DROP TABLE IF EXISTS `hc_message`;
CREATE TABLE `hc_message` (
  `messageid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_from` varchar(30) NOT NULL DEFAULT '' COMMENT '发件人',
  `send_to` varchar(30) NOT NULL DEFAULT '' COMMENT '收件人',
  `message_time` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` char(80) NOT NULL DEFAULT '' COMMENT '主题',
  `content` text NOT NULL,
  `replyid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复的id',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '1正常0隐藏',
  `isread` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否读过',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统信息',
  PRIMARY KEY (`messageid`),
  KEY `replyid` (`replyid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_message_data`
-- -----------------------------
DROP TABLE IF EXISTS `hc_message_data`;
CREATE TABLE `hc_message_data` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `group_message_id` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '读过的信息ID',
  PRIMARY KEY (`id`),
  KEY `message` (`userid`,`group_message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_message_group`
-- -----------------------------
DROP TABLE IF EXISTS `hc_message_group`;
CREATE TABLE `hc_message_group` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组id',
  `subject` char(80) NOT NULL DEFAULT '',
  `content` text NOT NULL COMMENT '内容',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_model`
-- -----------------------------
DROP TABLE IF EXISTS `hc_model`;
CREATE TABLE `hc_model` (
  `modelid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` char(30) NOT NULL DEFAULT '',
  `tablename` char(20) NOT NULL DEFAULT '',
  `alias` varchar(30) NOT NULL DEFAULT '',
  `description` varchar(100) NOT NULL DEFAULT '',
  `setting` text,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `items` smallint(5) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isdefault` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`modelid`),
  KEY `siteid` (`siteid`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_model`
-- -----------------------------
INSERT INTO `hc_model` VALUES ('1','','文章模型','article','article','文章模型','','1466393786','','','','','1','1');
INSERT INTO `hc_model` VALUES ('2','','产品模型','product','product','产品模型','','1466393786','','','','','1','');
INSERT INTO `hc_model` VALUES ('3','','下载模型','download','download','下载模型','','1466393786','','','','','1','');

-- -----------------------------
-- Table structure for `hc_model_field`
-- -----------------------------
DROP TABLE IF EXISTS `hc_model_field`;
CREATE TABLE `hc_model_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(100) NOT NULL DEFAULT '',
  `css` varchar(30) NOT NULL DEFAULT '',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `errortips` varchar(100) NOT NULL DEFAULT '',
  `fieldtype` varchar(20) NOT NULL DEFAULT '',
  `defaultvalue` varchar(30) NOT NULL DEFAULT '',
  `setting` text,
  `isrequired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isunique` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isadd` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`fieldid`),
  KEY `modelid` (`modelid`,`disabled`),
  KEY `field` (`field`,`modelid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_model_field`
-- -----------------------------
INSERT INTO `hc_model_field` VALUES ('1','','title','标题','','','1','100','请输入标题','input','','','1','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('2','','catid','栏目','','','1','10','请选择栏目','select','','','1','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('3','','thumb','缩略图','','','','100','','image','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('4','','keywords','关键词','','','','50','','input','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('5','','description','摘要','','','','255','','textarea','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('6','','inputtime','发布时间','','','1','10','','datetime','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('7','','updatetime','更新时间','','','1','10','','datetime','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('8','','copyfrom','来源','','','','30','','input','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('9','','url','URL','','','1','100','','input','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('10','','userid','用户ID','','','1','10','','input','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('11','','username','用户名','','','1','30','','input','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('12','','nickname','昵称','','','','30','','input','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('13','','template','模板','','','1','50','','select','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('14','','content','内容','','','1','999999','','editor','','','1','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('15','','click','点击数','','','1','10','','input','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('16','','tag','TAG','','','','50','','checkbox','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('17','','readpoint','阅读收费','','','1','5','','input','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('18','','groupids_view','阅读权限','','','1','10','','checkbox','1','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('19','','status','状态','','','1','2','','checkbox','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('20','','flag','属性','','','1','16','','checkbox','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('21','','listorder','排序','','','1','5','','input','1','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('25','2','pictures','产品图集','','','','1000','','images','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('29','3','down_url','下载地址','','','1','100','下载地址不能为空','attachment','','','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('30','3','copytype','授权形式','','','','20','','select','','{\"0\":\"免费版\",\"1\":\"正式版\",\"2\":\"共享版\",\"3\":\"试用版\",\"4\":\"演示版\",\"5\":\"注册版\",\"6\":\"破解版\"}','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('31','3','systems','平台','','','1','30','','select','','{\"0\":\"Windows\",\"1\":\"Linux\",\"2\":\"MacOS\"}','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('32','3','language','语言','','','','20','','select','','{\"0\":\"简体中文\",\"1\":\"繁体中文\",\"2\":\"英文\",\"3\":\"多国语言\",\"4\":\"其他语言\"}','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('33','3','version','版本','','','1','15','版本号不能为空','input','','','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('34','3','filesize','文件大小','单位为字节','','','10','','input','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('35','3','classtype','软件类型','','','1','30','','radio','','{\"0\":\"国产软件\",\"1\":\"国外软件\",\"2\":\"汉化补丁\",\"3\":\"程序源码\",\"4\":\"其他\"}','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('36','3','stars','评分等级','','','','20','','radio','','{\"0\":\"1星\",\"1\":\"2星\",\"2\":\"3星\",\"3\":\"4星\",\"4\":\"5星\"}','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('38','1','rong_id','公司荣誉排序','','','','100','','input','','','','','','','1','','','1');
INSERT INTO `hc_model_field` VALUES ('48','1','article_order','文章顺序','数字越小文章越靠前','','','100','','number','','','','','','','1','','','1');
INSERT INTO `hc_model_field` VALUES ('51','2','shebei','设备参数','','','','100','','editor','','','','','','','1','','','1');

-- -----------------------------
-- Table structure for `hc_module`
-- -----------------------------
DROP TABLE IF EXISTS `hc_module`;
CREATE TABLE `hc_module` (
  `module` varchar(15) NOT NULL DEFAULT '',
  `name` varchar(20) NOT NULL DEFAULT '',
  `iscore` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `version` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `setting` text,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `installdate` date NOT NULL DEFAULT '2016-01-01',
  `updatedate` date NOT NULL DEFAULT '2016-01-01',
  PRIMARY KEY (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_module`
-- -----------------------------
INSERT INTO `hc_module` VALUES ('admin','后台模块','1','1.0','后台模块','','','','2016-08-27','2016-08-27');
INSERT INTO `hc_module` VALUES ('index','前台模块','1','1.0','前台模块','','','','2016-09-21','2016-09-21');
INSERT INTO `hc_module` VALUES ('api','接口模块','1','1.0','为整个系统提供接口','','','','2016-08-28','2016-08-28');
INSERT INTO `hc_module` VALUES ('install','安装模块','1','1.0','CMS安装模块','','','','2016-10-28','2016-10-28');
INSERT INTO `hc_module` VALUES ('attachment','附件模块','1','1.0','附件模块','','','','2016-10-10','2016-10-10');
INSERT INTO `hc_module` VALUES ('member','会员模块','1','1.0','会员模块','','','','2016-09-21','2016-09-21');
INSERT INTO `hc_module` VALUES ('guestbook','留言模块','1','1.0','留言板模块','','','','2016-10-25','2016-10-25');
INSERT INTO `hc_module` VALUES ('search','搜索模块','1','1.0','搜索模块','','','','2016-11-21','2016-11-21');
INSERT INTO `hc_module` VALUES ('link','友情链接','','1.0','友情链接模块','','','','2016-12-11','2016-09-28');
INSERT INTO `hc_module` VALUES ('comment','评论模块','1','1.0','全站评论','','','','2017-01-05','2017-01-05');
INSERT INTO `hc_module` VALUES ('mobile','手机模块','1','1.0','手机模块','','','','2017-04-05','2017-04-05');
INSERT INTO `hc_module` VALUES ('banner','轮播图管理','','2.0','轮播图管理模块','','','','2017-05-12','2020-05-17');
INSERT INTO `hc_module` VALUES ('collection','采集模块','1','1.0','采集模块','','','','2017-08-16','2017-08-16');
INSERT INTO `hc_module` VALUES ('wechat','微信模块','1','1.0','微信模块','','','','2017-11-03','2017-11-03');
INSERT INTO `hc_module` VALUES ('diyform','自定义表单模块','1','1.0','自定义表单模块','','','','2018-01-15','2018-01-15');
INSERT INTO `hc_module` VALUES ('adver','广告管理','','1.0','广告管理模块','','','','2018-01-18','2018-01-18');
INSERT INTO `hc_module` VALUES ('pay','支付模块','1','1.0','支付模块','','','','2018-07-03','2018-07-03');

-- -----------------------------
-- Table structure for `hc_order`
-- -----------------------------
DROP TABLE IF EXISTS `hc_order`;
CREATE TABLE `hc_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '订单状态0未付款1已付款',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '支付方式1支付宝2微信',
  `transaction` varchar(32) NOT NULL DEFAULT '' COMMENT '第三方交易单号',
  `money` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `quantity` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '数量',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1积分,2金钱',
  `ip` char(15) NOT NULL DEFAULT '',
  `desc` varchar(250) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `userid` (`userid`),
  KEY `order_sn` (`order_sn`),
  KEY `status` (`status`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单表';


-- -----------------------------
-- Table structure for `hc_page`
-- -----------------------------
DROP TABLE IF EXISTS `hc_page`;
CREATE TABLE `hc_page` (
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(160) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_page`
-- -----------------------------
INSERT INTO `hc_page` VALUES ('70','生产工艺方法','','','1668409684');
INSERT INTO `hc_page` VALUES ('71','纯机械加工','','<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;机械加工工艺主要有车、铣、磨、钳、钻、镗、刨、冲、锯，还有包括电镀、热处理、线切割、锻造等方法。①车：车床，主要通过车刀对旋转的工件进行直线或曲线平移运动加工，车削能使工件达到应有的外形，适合加工轴类和回转零件；②铣：铣床，主要通过旋转的刀具对固定在工件台的工件进行加工，适合加工平面、沟槽、各种曲面或齿轮；③磨：磨床，主要通过高速旋转的砂轮对工件进行平面、外圆、内孔、工具磨削，加工的工件表面粗糙度特别高；④钳：钳工工作台，是精密测量，检查零件尺寸精度及形位误差，以及作精密划线，是机械制造中的基本工具及操作；⑤钻：通过用钻头等工具对工件进行打孔作业；⑥镗：使用镗刀或刀片对孔的加工，适用于精度较高、直径较大工件的孔；⑦刨：通过刨刀加工平面或者曲面，适用于工件加工外形直线面，但加工表面粗糙度并没有铣床高；⑧冲：冲床，通过冲床冲压成型，例如冲圆或冲孔；⑨锯：锯床，适用于下料后的切断加工。通过以上的方式，便能使工件的外形尺寸达到设计图纸的要求。纯机械加工优点是精度高，一般零件生产效率高，一致性好，质量控制有保障；缺点是在复杂腔体零件和薄壁件的生产制造比较困难，部分复杂内腔的零件无法整体制造，拆解制造后组装焊接比较困难在零配件的密封性特别是强度稳定性和一致性比较难保证（后来的搅拌摩擦焊接只能解决部分焊接问题）；面对复杂特殊零件要求高的纯机械加工工艺无法实现。</p><p>&nbsp;</p><p><br/></p>','1668475506');
INSERT INTO `hc_page` VALUES ('72','精密3D打印+精密制造+机械加工','','<p>&nbsp;&nbsp;&nbsp;&nbsp;1，型模制作：用软件把型模处理成空心结构：大大减少树脂原料的消耗，节省大量成本；基本消除了树脂在后期处理过程中的膨胀问题；大大减少了除去型模步骤残留的灰烬量。流干树脂：零件的壁厚大于1.5mm，热膨胀就会涨坏型壳。所以必须把零件空心结构内部的树脂流干净。清洗：尽量不要让溶剂流入零件内部，否则可能导致零件失去强度。推荐溶剂：1. 优选：用TPM （三丙二醇甲醚）清洗，用IPA（异丙醇）最后漂洗。2. 工业酒精。后固化：把零件置入紫外灯箱中30分钟左右，不仅可以把零件表面未固化的树 脂固化，让零件不再粘手，而且可以使零件更结实，尺寸更稳定。打磨：成型方式导致倾斜的面会有细小的台阶痕, 一般需要打磨。由于用于铸造的型模是空心结构，壁很薄，打磨时要小心。打磨后可以得到非常光滑的表面质量。检査气密性：用轻微抽真空的方式来 负压检查气密性，不容 易损坏型模。装上通风孔：（必要步骤，是下面步骤成功的关键）用铸造蜡制做约6mm直径、50mm长的蜡棒, 粘接到型模上。普通铸造用蜡：SL型模可以直接用蜡“焊接”在浇道 上面，和正常的蜡型一样装配考虑到去除SL型模的方式。浇口的 设计可以比蜡型的大些，这样有助于空气进入帮助燃烧型模。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;2，制壳：挂第一层浆料前，清洗蜡树的时候，注意观察是否有气泡出现。如果有，说明型模密封性不好。蜡树浸入浆液时避免浮力对蜡树造成破坏。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;3，脱蜡：脱蜡前准备穿通型模上用蜡 棒制作的通风口；移除蜡棒顶端的壳；露出做通风孔的蜡烧烫铁丝；烫穿蜡和里面的型壳的皮脱蜡有很多方法。方法和所需设备如下：1、热水除蜡-带收集蜡功能水槽2、蒸汽除蜡-电热一体脱蜡釜3、焙烧炉里除蜡-带收集蜡装置的炉子不同的方法所用设备不同，最简单的是热水除蜡，只用一个热水槽即可，完全人工操作。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;如果处理不当，型壳可能会在脱蜡环节出现胀壳。可以采用3D打印的方式打印出蜡树和浇口，组树后的整 体部件不含有蜡料，这样就可以跳过脱蜡这个步骤。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;4，去除型模：型模不能像蜡一样熔化！必 须通入充足的空气在高温下烧干净！请确保给炉子里通入充足的空气，如图示，能大大增加成功率。各种炉子都可以，推荐使用电能炉子。去除型模温度保持在800度-1100度两个小时。根据零件大小，适当延长时间。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;5，清除灰烬：模型冷却到室温后可以用以下的办法除去壳里的灰烬：简单的办法：用压缩空气吹可靠的办法：用水洗如果用水洗，需要事先用石磨棒或者蜡把通气孔塞起来。倒入1/3容积的水，晃动然后倒出。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;6，预热与浇注铸造：预热前用陶瓷棒、耐火泥等材料堵上通风孔。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;7，对精密铸造毛坯机械加工且加工工艺主要有车、铣、磨、钳、钻、镗、刨，还有包括表面处理、热处理、线切割、等方法使工件的外形尺寸达到设计图纸的要求。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;<br/></p>','1668411526');
INSERT INTO `hc_page` VALUES ('73','精密制造+机械加工','','<p>1，制造精密简易模具，通常有传统的机械加工来制造金属模具或是用3D打印直接制金属造模具。（通常用于小批量制造）</p><p>2，预热与浇注铸造：预热前用陶瓷棒、耐火泥等材料堵上通风孔。</p><p>3，对精密铸造毛坯机械加工且加工工艺主要有车、铣、磨、钳、钻、镗、刨，还有包括表面处理、热处理、线切割、等方法使工件的外形尺寸达到设计图纸的要求。</p>','1668411585');
INSERT INTO `hc_page` VALUES ('74','精密3D打印+复膜','','<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;精密3D打印+覆膜是小批量生产手板一个重要的方法，手板复模过程中需要用到3D打印工艺用来开模具。开模具方式有包模、刷模（分片模、立体模、平面模）、灌注模，这是根据产品的大小来决定的。灌注模是把搅拌均匀的硅胶和固化剂倒入围好模种的容器中，抽真空固化成型。有的不能直接取出模种的还须开刀脱模，以便生产顺利。而模种就是采用3D打印来制作的。3D打印手板原型复模是需要用3D打印做一个原型件，即是母模出来，然后通过复模的工艺复制出一套模具，最后通过这个模具复制这个产品。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;采用这种工艺能够进行产品的小批量生产手板复模与CNC手板加工的区别：</p><p>1、加工方式的区别：采用的是车床加工需要一个一个手板的进行锣，而真空复膜则是做一个原版后，再根据原版做出一个硅胶模具后进行复制。</p><p>2、材料区别：制作的手板一般的常见的ABS、PP、亚克力等材料，而真空复膜做出来确是妨ABS、PP、亚克力材料。</p><p>3、加工时间的区别：真空复膜只要做出硅胶模具后就可复制，一般一个硅胶模具可出8-15个产品，时间上要比CNC加工快很多。</p><p>4、精度区别：CNC加工的精度会比真空复膜出来的精度要高很多。</p><p>5、表面处理的区别：手板模型表面处理比如喷油，一般CNC制作出来的手板可以喷完油后放入烤箱烤干，而真空复膜出来的却只能自然风干。</p>','1668562772');
INSERT INTO `hc_page` VALUES ('75','金属3D打印','','<p>一、前处理工序</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1、清理成型缸粉末将缸内粉末用刷子扫入收粉箱。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2、更换刮刀条：为了避免因刮刀条磨损影响打印件的质量，所以每次打印完都要检查刮刀条。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3、调节基板:打印前需要调节基板四个角的螺丝，使基板处于水平状态，否则也会影响打印件的质量。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4、筛粉:收粉箱里的粉需要过筛处理才能回收利用，筛粉可以去除打印产生的杂质，保证打印质量。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5、置换空气为了防止金属粉末被氧化，必须要充入氮气作为保护气，置换过程大约需要一个半小时。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;由于金属打印使用的材料是金属粉末，所以很多人或许会误以为金属打印是不需要加支撑的。数据处理金属打印产品数据，支撑是需要的，而且很多时候还是必要的。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;金属3D打印支撑的主要作用有：</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;（1）与打印平台连接，抵抗应力，防止翘边；</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;（2）抵抗刮刀作用力，保持零件形状；</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;（3）传导热量。这是零件加好支撑时的状态，由于支撑也是金属，比较难去除，所以操作员都会反复调整角度，尽量减少支撑。准备工作完成后，将加好支撑的打印件导入机器，开始打印。</p><p>二 、后处理工序打印结束，</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1，冷却：需要静置一段时间，待完全冷却后将打印件连同基板一起取出。这个时候打印件是烧结在基板上的,</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2，热处理:在切下来之前需要先进行热处理去应力，特别是一些大平面的盒状薄壳体，应力很强，直接切非常容易变形,</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3，线切割:热处理完成后，再进行线切割，将打印件从基板上分离。这是刚切下来时的状态，可以看到有些件上还是有很多支撑的,</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4，去支撑:金属打印不同于树脂打印的很大一方面在于支撑，树脂件的支撑用酒精泡软以后比较容易去除，而金属件的支撑非常硬，几乎相当于是焊接在打印件上的，所以去支撑也是金属打印最大的难点。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5，打磨:打磨是为了将支撑点磨平，并且让打印件的表面更光滑,</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6，喷砂:打磨完成后需要喷砂，喷砂可以让打印件的表面更干净，效果更美观。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7，抛光：抛光可以使工件表面粗糙度降低，获得光亮、平整的表面。</p>','1668411750');
INSERT INTO `hc_page` VALUES ('76','尼龙3D打印','','<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;材料性能：尼龙（PA），也称为聚酰胺，尼龙材料种类繁多，常见的尼龙材料有：PA66、PA6、PA12等，是注塑行业不可或缺的材料。同样的，尼龙是3D打印重要材料之一。尼龙是一种合成聚合物，耐磨，韧性高，强度大和耐热性好。这些特性使尼龙成为各种3D打印应用的理想选择。3D打印尼龙材料有哪些优势？适用于原型和功能验证部件，如齿轮和工具，尼龙可以用碳纤维或玻璃纤维增强，从而使轻质部件具有出色的机械性能。尼龙具有很高的刚性和柔韧性。当您打印的产品比较薄时，您的部件将是柔性的，而当打印较厚的墙壁时，您的部件将是刚性的。这非常适合生产具有刚性部件和柔性接头的活动铰链等部件。尼龙印刷的部件带有一些颗粒感，无支撑，几乎不需要后处理。尼龙3D打印可用于制作移动和互锁部件。这消除了组装单独印刷部件的需要，并且使得能够更快地生产高度复杂的物体。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;生产工艺：尼龙和聚酰胺基复合材料最适用于粉末床3D打印技术，激光烧结（SLS）和多喷射融合（MJF），市场上有许多不同类型。也有FDM工艺使用尼龙材料的，SLS选择性激光烧结:60%以上的3D打印尼龙粉末材料都被使用SLS工艺打印，尼龙11（PA11）和尼龙12（PA12）是两种最常用的尼龙材料。PA11具有的抗紫外线和抗冲击性能比较好，而PA12的强度和刚度更高。还有各种增强复合材料，如玻璃纤维，碳纤维增强的尼龙材料，它们机械性能会更好，就像塑料材料的改性。MJF多喷射熔融:对于SLS和MJF 3D打印，您的尼龙部件的壁厚至少需要1 mm。在设计活动铰链时，确保SLS和MJF的最小壁厚分别为0.8 mm。在粉末床工艺中使用尼龙时，强烈建议不要设计大而扁平的部件，因为翘曲的可能性很大。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;由于尼龙允许创建移动和互锁部件，因此确保打印在一起的部件之间的间距至少0.6-0.8mm以上。建议拆除零件内部的尼龙粉末，特别是对于壁厚超过20毫米的零件。为了节省材料并避免变形，请确保设计中至少考虑两个排气孔，以便在打印后轻松去除粉末。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应用:</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1,汽车行业以生产定制的工具，夹具和固定装置，重复卡扣，车床导轨、活动铰链和齿轮以及用于内饰板，低热进气部件和天线盖的原型。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2,航空航天中也有尼龙零件的身影，例如，美国公MetroAerospace最近推出了3D打印的玻璃填充尼龙微型叶片，旨在减少阻力。通过这种3D打印流程，Metro Aerospace能够确保其飞行级组件的一致性，从而更容易获得FAA批准。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3,医疗领域尼龙可用于原型制作和创建 教育解剖模型，以及生产医疗最终用途部件。巴斯夫的Ultramid聚酰胺最近被用于生产定制的3D打印假肢插座。用碳纤维增强的聚酰胺确保假体保持坚固和轻盈。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4,消费品行业迅速增加3D打印的使用，也正在充分利用尼龙。从手机壳到可定制的眼镜， 尼龙在各种应用中提供灵活的选择。最近的案例是香奈儿的3D打印睫毛膏刷，采用SLS技术，采用聚酰胺粉末制成。</p><p><br/></p>','1668411855');
INSERT INTO `hc_page` VALUES ('77','塑料3D打印','','<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SLA3D打印技术的成型原理：盛满液态光敏树脂，氦－镉激光器或氩离子激光器发出的紫外激光束在控制系统的控制下按零件的各分层截面信息在光敏树脂表面进行逐点扫描，使被扫描区域的树脂薄层产生光聚合反应而固化，形成零件的一个薄层。一层固化完毕后，工作台下移一个层厚的距离，以使在原先固化好的树脂表面再敷上一层新的液态树脂，刮板将粘度较大的树脂液面刮平，然后进行下一层的扫描加工，新固化的一层牢固地粘结在前一层上，如此重复直至整个零件制造完毕，得到一个三维实体原型。SLA3d打印技术的工艺过程：光固化快速原型的制作一般可以分为前处理、原型制作和后处理三个阶段。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;前处理阶段主要是通过CAD设计出三维实体模型，对原型进行数据转换、摆放方位确定、施加支撑和利用离散程序将模型进行切片处理，设计扫描路径，产生的数据将精确控制激光扫描器和升降台的运动，实际上就是为原型的制作准备数据；原型制作就是在专用的光固化快速成型设备系统上进行光固化成型。在原型制作前，需要提前启动光固化快速成型设备系统，使得树脂材料的温度达到预设的合理温度，激光器点燃后也需要一定的稳定时间。设备运转正常后，启动原型制作控制软件，读入前处理生成的层片数据文件就可以启动叠层制作了。整个叠层的光固化过程都是在软件系统的控制下自动完成的，所有叠层制作完毕后，系统自动停止。后处理，在快速成型系统中原型叠层制作完毕后，需要进行剥离等后续处理工作，以便去除废料和支撑结构等。</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SLA3d打印工艺的优势、劣势：SLA 技术的优势1.光固化成型法是最早出现的快速原型制造工艺，成熟度高，经过时间的检验。2.由CAD数字模型直接制成原型，加工速度快，产品生产周期短，无需切削工具与模具。3.可以加工结构外形复杂或使用传统手段难于成型的原型和模具。4.使CAD数字模型直观化，降低错误修复的成本。5.为实验提供试样，可以对计算机仿真计算的结果进行验证与校核。6.可联机操作，可远程控制，利于生产的自动化。SLA 技术的缺陷1.SLA系统造价高昂，使用和维护成本过高。2.SLA系统是要对液体进行操作的精密设备，对工作环境要求苛刻。3.成型件多为树脂类，强度，刚度，耐热性有限，不利于长时间保存。4.预处理软件与驱动软件运算量大，与加工效果关联性太高。5.软件系统操作复杂，入门困难；使用的文件格式不为广大设计人员熟悉。SLA 的发展趋势与前景SLA技术主要用于制造多种模具、模型等；还可以在原料中通过加入其它成分，用SLA原型模代替熔模精密铸造中的蜡模。SLA技术成形速度较快，精度较高，但由于树脂固化过程中产生收缩，不可避免地会产生应力或引起形变。因此开发收缩小、固化快、强度高的光敏材料是其发展趋势。立体光固化成型法的的发展趋势是高速化，节能环保与微型化。不断提高的加工精度使之有最先可能在生物，医药，微电子等领域大有作为。<a href=\"https://www.sohu.com/?strategyid=00001&spm=smpc.content.content.2.1666664869875YREhMXy\" title=\"点击进入搜狐首页\"></a></p><p><br/></p>','1668412064');
INSERT INTO `hc_page` VALUES ('51','联系我们','','','1665971015');
INSERT INTO `hc_page` VALUES ('82','服务2','','','1668478511');
INSERT INTO `hc_page` VALUES ('83','服务指南','','','1668478537');
INSERT INTO `hc_page` VALUES ('85','服务中心','','<div class=\"sub-title\" style=\"box-sizing: border-box; margin: 50px 0px 0px; padding: 0px; font-size: 22px; color: rgb(183, 32, 36); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal;\">交货周期</div><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; color: rgb(105, 105, 105); white-space: normal;\">为保证准确交货，用户须注意：本公司为客户在与我们沟通时，提供三维设计图，我们第一时间提供报价与周期，一般模型2个工作日发货，特殊模型发货时间与客服沟通。&nbsp;</p><div class=\"sub-title\" style=\"box-sizing: border-box; margin: 50px 0px 0px; padding: 0px; font-size: 22px; color: rgb(183, 32, 36); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal;\">发票说明</div><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; color: rgb(105, 105, 105); white-space: normal;\">发票内容：<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>1.发票将与货物一并邮寄，特殊情况我们客服会与您沟通，敬请大家了解并注；<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>2.开具发票的金额以实际支付的金额为准（具体需与客服沟通）；<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>3.正常情况我们将以收货地址作为发票的邮寄地址，以便及时与您联系，如有特殊情况请与客服联系；<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>4.提供的发票发票资质信息。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>—单位名称（必须是您公司营业执照上的全称）<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>—纳税人识别号（必须是您公司《税务登记证》的编号<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>—注册地址（必须是您公司营业执照上的注册地址）<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>—电话（请提供能与您公司保持联系的有效电话）<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>—开户银行（必须是您公司银行开户许可证上的开户银行）<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>—银行账号（必须是您公司开户许可证上的银行账号）<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/></p><div class=\"sub-title\" style=\"box-sizing: border-box; margin: 50px 0px 0px; padding: 0px; font-size: 22px; color: rgb(183, 32, 36); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal;\">配送/支付</div><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; color: rgb(105, 105, 105); white-space: normal;\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: bolder;\">配送方式</span><br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>为了保障交货速度，公司目前仅支持顺丰速递。不在顺丰配送范围内的订单，将由顺丰公司安排转寄。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: bolder;\">支付方式</span><br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>目前提供支付宝、微信支付、银行转账、对公转账四种支付方式，需要转账的请与客服沟通。</p><p><br/></p>','1668481135');
INSERT INTO `hc_page` VALUES ('86','售后服务','','<div class=\"sub-title\" style=\"box-sizing: border-box; margin: 50px 0px 0px; padding: 0px; font-size: 22px; color: rgb(183, 32, 36); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal;\">签收/验货</div><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; color: rgb(105, 105, 105); white-space: normal;\">为保障您的权益，请您在收货时注意以下环节：<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>1.签收时在付款前与配送人员当面核对：产品名称、应付金额、产品数量及发货清单、发票（如有）等<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>2.如存在产品破损、产品错误、产品短缺、产品质量问题等影响签收的因素，请您拨打15250018006或13771921540沟通解决<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>3.为了保护您的权益，建议您尽量不要委托他人代为签收；如由他人代为签收产品，而没有在配送人员在场的情况下验收，出现的一切问题，均后果自负<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>如果您在收到产品3日内，您发现产品有质量问题，请联系客服处理。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/></p><div class=\"sub-title\" style=\"box-sizing: border-box; margin: 50px 0px 0px; padding: 0px; font-size: 22px; color: rgb(183, 32, 36); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal;\">返工/退换货</div><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; color: rgb(105, 105, 105); white-space: normal;\">如果您在收到产品3日内，您发现产品有质量问题，请联系客服处理。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>客服电话：13771921540；15250018006 Email：qhyft@163.com<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>海创三维科技（苏州）有限公司同意退换货的情况<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>1.本公司生产的产品严格遵照中华人民共和国的质量标准执行；当发生质量问题经过核实为本公司原因的，我们会为您办理退货或者重新生产<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>2.对于需要办理退货或者重新生产的，自产品交货日（以实际收货日期为准）起3日内可以办理本公司不予办理退换货的情况非本公司原因造成的产品质量不良，包括：<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>1.产品签收后产生的受潮、变色等<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>2.退回产品数量不足<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>3.其他由于用户原因造成的<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>退款说明<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>1.退款规则：本公司同意退款后，该退款将退回原支付银行账户/支付宝<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>2.退款周期：退款将在20个工作日内向您提供的银行账户汇出<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/></p><div class=\"sub-title\" style=\"box-sizing: border-box; margin: 50px 0px 0px; padding: 0px; font-size: 22px; color: rgb(183, 32, 36); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal;\">投诉建议</div><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; color: rgb(105, 105, 105); white-space: normal;\">本公司极为重视顾客对于产品和服务的反馈，建立了全方位客户沟通渠道。我们的客户服务团队由一支充满活力的工程师团队构成，他们拥有专业的技术知识和良好的职业素养，为您提供产品咨询、信息反馈、投诉和建议等优质服务。如果您对我们的体验或者服务有任何不满或建议，您可以通过电话或者Email直接和我们沟通，我们会在24小时内处理完毕，并给您回复。全国客户服务热线：15250018006 13771921540 工作时间：8:30-17:00 Email：qhyft@163.com&nbsp;</p><p><br/></p>','1668481162');
INSERT INTO `hc_page` VALUES ('87','3D打印文件格式规范','','<p><span style=\"color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\">以下是使用不同软件，导出STL格式文件的具体方法：</span></p><p><span style=\"color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668480752186789.jpg\" title=\"3D打印文件格式规范\" alt=\"3D打印文件格式规范\"/></span></p>','1668480755');
INSERT INTO `hc_page` VALUES ('88','部分设计规范','','<p>为了确保您的设计能够顺利打印，请您依次操作以下步骤：</p><div><p>1) 根据实际使用要求，选择材料。查看材料参数<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>2) 检查您的设计的壁厚，务必满足最小壁厚要求。查看不同材料的壁厚设计要求<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>3) 如果您的设计是空心的，务必设计足够大的逸出孔。查看逸出孔设计要求<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>4) 如果您的设计中存在独立柱子，务必满足最小壁厚要求。查看独立柱子的壁厚设计要求<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>5) 如果您的设计中存在凸状或凹状细节（如凸字或凹字等），务必满足最小的宽度和高度要求。查看凸状/凹状设计要求<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>6) 如果您的设计中存在尖锐部分，该部分的角度需要满足最小要求。查看尖锐部分设计要求<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>7) 如果您的设计中包含多个零件，务必满足零件之间最小的间隙要求。查看零件间隙设计要求<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>8) 如果您的设计中存在螺纹，牙型角度和螺距务必达到最小要求。查看螺纹设计要求 9) 如果您的设计中存在孔洞，其内径和深度必须满足最小的孔洞要求。查看孔洞设计要求 10) 如果您的设计较为复杂，工场可能会判定为异形件，按照特殊规格报价。查看异形件示例 如果您的设计遵守以上设计规范，将极大提高您的订单审核通过率。</p></div><p><br/></p>','1668481261');
INSERT INTO `hc_page` VALUES ('89','选择合适的材料','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105);\">您可以根据您的实际需要选择合适的材料，下面是各种材料的重要信息。</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">特点</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">应用领域</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">技术工艺</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">热变形温度（0.46MPa）</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">8000树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">表面光滑、适合普通装配</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">汽车、消费电子、机电、艺术品</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">SLA</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">46℃</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">8500高韧性树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">韧性高、深蓝色</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">汽车、消费电子、机电、艺术品</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">SLA</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">62℃</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">透明光敏树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">表面光滑、防水、稳定性好</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">包装、翻模、流体分析</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">MJP/Objet</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">45℃</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">灰色类ABS</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">韧表面光滑、硬度高、韧性好</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">消费电子、家用电器</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">SLA</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">55℃</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">白色尼龙</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">表面有颗粒感、硬度高、韧性好</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">汽车配件、家用电器、机电设备</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">SLS</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">140℃</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">表面有颗粒感、硬度高、韧性好</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">汽车配件、家用电器、机电设备</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">SLS</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">160℃</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">AlSi10Mg</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">打印产品的强度高</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">零配件制造</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">SLM</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\"><br/></td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">7075铝合金</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">机械性能好、抗腐蚀、抗氧化</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">零配件制造</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">CNC</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\"><br/></td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">6061铝合金</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">焊接性能好，强度高</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">零配件制造</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">CNC</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><br/></td></tr></tbody></table></div><p><br/></p>','1668481299');
INSERT INTO `hc_page` VALUES ('90','3D打印不同材料的最小壁厚要求','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">在您的3D设计文件中，模型的内、外表面闭合形成薄壁，其中：<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>至少有两个面与其他薄壁相连的，称为支撑性薄壁，如下图：</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668481344527104.jpg\" title=\"3D打印不同材料的最小壁厚要求\" alt=\"3D打印不同材料的最小壁厚要求\"/><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">只有一个面与其他薄壁相连的，称为非支撑型薄壁，如下图：</p><img src=\"/uploads/ueditor/image/20221115/1668481349996564.jpg\" title=\"3D打印不同材料的最小壁厚要求\" alt=\"3D打印不同材料的最小壁厚要求\"/><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">薄壁的厚度我们称为壁厚，相应的可分为支撑型壁厚和非支撑型壁厚。</p><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">壁厚直接决定了打印物品的强度也关系着模型能否打印。</p><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">模型打印出来后还需要经过去除支撑、打磨、喷砂等处理，这些工序决定了不同材料的最小壁厚。只有当壁厚达到最小壁厚要求模型才是可打印的。</p><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">如果您的设计中存在较薄的支撑型薄壁区域，需要根据该区域的大小调整壁厚，具体如下（如选择8000树脂材料，薄壁区域大小在5*5mm以内，其最小壁厚为0.6，其他同理）：</p><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">5*5mm</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">10*10mm</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">50*50mm</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">100*100mm</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">200*200mm</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">8000树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.6mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.5mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">8500高韧性树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">2mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">透明光敏树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.3mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">白色尼龙</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">灰色高韧性类ABS树脂</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td></tr></tbody></table><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">如果您的设计中存在非支撑型薄壁，则最小壁厚要求如下</p><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8000树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8500高韧性树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">白色尼龙</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色高韧性类ABS</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">AlSi10Mg铝合金</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">壁厚</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td></tr></tbody></table></div><p><br/></p>','1668481363');
INSERT INTO `hc_page` VALUES ('91','空心设计中逸出孔的大小要求','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">如果您的设计是空心的，需要在适当的部位设计逸出孔，用于移除打印完毕后的产品中未被使用的材料，具体如下：</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668481398469959.jpg\" title=\"空心设计中逸出孔的大小要求\" alt=\"空心设计中逸出孔的大小要求\"/><div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105);\">您需要确保空心部分包含足够大的逸出孔，其孔径大于2mm，使得空心部分能够清理干净。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>如果逸出孔达不到最低要求，建议您增加现有逸出孔的大小、增加逸出孔的数量或者将空心部分填实。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>特别的，当只有一个逸出孔时，并不能保证未被使用的材料完全逸出。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>我们推荐使用多个逸出孔。</div></div><p><br/></p>','1668481399');
INSERT INTO `hc_page` VALUES ('92','立柱的最小壁厚设计要求','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">模型中如果某个凸出部分的特征其长度超过宽度2倍我们称之为立柱（长度小于宽度2倍的称为凸状细节）,其中两端都和薄壁相连的称为支撑型立柱如下图：</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668481438186859.jpg\" title=\"立柱的最小壁厚设计要求\" alt=\"立柱的最小壁厚设计要求\"/><div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105);\">只有一端和薄壁相连的，称为非支撑型立柱，如下图：</div><img src=\"/uploads/ueditor/image/20221115/1668481444166475.jpg\" title=\"立柱的最小壁厚设计要求\" alt=\"立柱的最小壁厚设计要求\"/><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">去除支撑、打磨、喷砂等工序决定了最小立柱壁厚要求不同材料立柱最小壁厚要求如下：</p><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8000树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8500高韧性树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">白色尼龙</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">AlSi10Mg铝合金</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">支撑型立柱</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">非支撑型立柱</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td></tr></tbody></table></div><p><br/></p>','1668481454');
INSERT INTO `hc_page` VALUES ('93','凸状和凹状的细节要求','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">模型中如果某个凸起部分的特征其高度小于宽度的2倍（若高度大于宽度的2倍我们称为独立柱子）我们称之为凸状细节，如下图：</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668481487915573.jpg\" title=\"凸状和凹状的细节要求\" alt=\"凸状和凹状的细节要求\"/><div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105);\">最小凸状细节通常是由打印机的精度决定的。不同材料的凸状细节的最小高度/宽度要求如下（例如8000树脂材料的凸字细节其高度和宽度必须大于1.2mm才能打印清楚）：</div><img src=\"/uploads/ueditor/image/20221115/1668481493151761.jpg\" title=\"凸状和凹状的细节要求\" alt=\"凸状和凹状的细节要求\"/><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">去除支撑、打磨、喷砂等工序决定了最小立柱壁厚要求不同材料立柱最小壁厚要求如下：<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/></p><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8000树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8500高韧性树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">白色尼龙</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色类ABS</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">AlSi10Mg铝合金</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">高度宽度</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td></tr></tbody></table><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">最小凹状细节通常是由打印机的精度决定的。不同材料的凹状细节的最小深度/宽度要求如下（例如，8000树脂材料的凹字细节其深度和宽度必须大于1mm才能打印清楚）：</p><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8000树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8500高韧性树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">白色尼龙</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色类ABS</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">AlSi10Mg铝合金</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">深度宽度</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td></tr></tbody></table><p class=\"desc\" style=\"box-sizing: border-box; margin-top: 20px; margin-bottom: 20px; padding: 0px; transition: all 0.3s ease-out 0s; font-size: 14px; color: rgb(105, 105, 105);\">当凹状细节的深度或宽度小于最小凹状细节要求时，将无法准确地打印，无法进行打磨、喷洒等后处理。此时建议您增加深度/宽度、去除该部分或者选择其他合适的材料。</p></div><p><br/></p>','1668481494');
INSERT INTO `hc_page` VALUES ('94','间隙设计要求','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">间隙是指任何两个零件薄壁或者立柱之间的距离如下图：</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668481525699223.jpg\" title=\"间隙设计要求\" alt=\"间隙设计要求\"/><div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105);\">您的设计中，两个部分的间隙需要大于最小间距要求，才能够正确打印，不同材料的最小间隙要求如下：</div><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8000树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">8500高韧性树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色类ABS</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色玻璃纤维</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">灰色类ABS</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">间隙要求</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">2mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">1mm</td></tr></tbody></table></div><p><br/></p>','1668481526');
INSERT INTO `hc_page` VALUES ('95','螺纹的设计要求','','<div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">螺距是指螺纹上相邻两牙对应点之间的轴向距离如下图：</div><div class=\"service-r-desc\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; color: rgb(33, 37, 41); font-family: &quot;Microsoft Yahei&quot;, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><img src=\"/uploads/ueditor/image/20221115/1668481548352942.jpg\" title=\"螺纹的设计要求\" alt=\"螺纹的设计要求\"/><div class=\"desc\" style=\"box-sizing: border-box; margin: 20px 0px; padding: 0px; font-size: 14px; color: rgb(105, 105, 105);\">牙型角度是指螺纹牙型两侧边的夹角。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>打印机的精度会影响到螺距和牙型角度。<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/>根据不同的材料选择，您的设计需要满足最小螺距和最小牙型角度要求，如下：<br style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"/></div><table class=\"table table-bordered\" width=\"783\"><thead style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\" class=\"firstRow\"><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">材料</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">100微米白色光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">100微米透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">16微米半透明光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">100微米灰色类ABS</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">100微米白色尼龙</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">100微米灰色玻璃纤维</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">33微米淡蓝色光敏树脂</th><th scope=\"col\" style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; text-align: -webkit-match-parent; vertical-align: bottom; border-bottom-width: 2px; border-color: rgb(222, 226, 230);\">25微米金属色钴铬合金</th></tr></thead><tbody style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">螺距</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.6mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.8mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.6mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.6mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.6mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">0.5mm</td></tr><tr style=\"box-sizing: border-box; margin: 0px; padding: 0px;\"><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">牙型角度</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td><td style=\"box-sizing: border-box; margin: 0px; padding: 0.75rem; vertical-align: top; border-color: rgb(222, 226, 230);\">20°</td></tr></tbody></table></div><p><br/></p>','1668481549');

-- -----------------------------
-- Table structure for `hc_pay`
-- -----------------------------
DROP TABLE IF EXISTS `hc_pay`;
CREATE TABLE `hc_pay` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `trade_sn` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `money` char(8) NOT NULL DEFAULT '' COMMENT '金钱或积分的量',
  `creat_time` int(10) unsigned NOT NULL DEFAULT '0',
  `msg` varchar(30) NOT NULL DEFAULT '' COMMENT '类型说明',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1积分,2金钱',
  `ip` char(15) NOT NULL DEFAULT '',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1成功,0失败',
  `remarks` varchar(250) NOT NULL DEFAULT '' COMMENT '备注说明',
  `adminnote` char(20) NOT NULL DEFAULT '' COMMENT '如是后台操作,管理员姓名',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `trade_sn` (`trade_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_pay_mode`
-- -----------------------------
DROP TABLE IF EXISTS `hc_pay_mode`;
CREATE TABLE `hc_pay_mode` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `logo` varchar(100) NOT NULL DEFAULT '',
  `desc` varchar(250) NOT NULL DEFAULT '',
  `config` text,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `author` varchar(60) NOT NULL DEFAULT '',
  `version` varchar(10) NOT NULL DEFAULT '',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '支付调用方法',
  `template` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_pay_mode`
-- -----------------------------
INSERT INTO `hc_pay_mode` VALUES ('1','支付宝','alipay.png','支付宝新版在线支付插件，要求PHP版本>=5.5','{\"app_id\":\"\",\"merchant_private_key\":\"\",\"alipay_public_key\":\"\"}','1','袁志蒙','1.0','alipay','alipay');
INSERT INTO `hc_pay_mode` VALUES ('2','微信','wechat.png','微信支付提供公众号支付、APP支付、扫码支付、刷卡支付等支付方式。','{\\\"app_id\\\":\\\"\\\",\\\"app_secret\\\":\\\"\\\",\\\"mch_id\\\":\\\"\\\",\\\"key\\\":\\\"\\\"}','','袁志蒙','1.0','wechat','wechat');

-- -----------------------------
-- Table structure for `hc_pay_spend`
-- -----------------------------
DROP TABLE IF EXISTS `hc_pay_spend`;
CREATE TABLE `hc_pay_spend` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `trade_sn` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `money` char(8) NOT NULL DEFAULT '' COMMENT '金钱或积分的量',
  `creat_time` int(10) unsigned NOT NULL DEFAULT '0',
  `msg` varchar(30) NOT NULL DEFAULT '' COMMENT '类型说明',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1积分,2金钱',
  `ip` char(15) NOT NULL DEFAULT '',
  `remarks` varchar(250) NOT NULL DEFAULT '' COMMENT '备注说明',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `trade_sn` (`trade_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_product`
-- -----------------------------
DROP TABLE IF EXISTS `hc_product`;
CREATE TABLE `hc_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(180) NOT NULL DEFAULT '',
  `color` char(9) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `copyfrom` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `flag` varchar(12) NOT NULL DEFAULT '' COMMENT '1置顶,2头条,3特荐,4推荐,5热点,6幻灯,7跳转',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groupids_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '收费类型',
  `is_push` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否百度推送',
  `pictures` text COMMENT '产品图集',
  `shebei` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`),
  KEY `catid` (`catid`,`status`),
  KEY `userid` (`userid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_product`
-- -----------------------------
INSERT INTO `hc_product` VALUES ('1','24','1','admin','管理员','3D打印样式测试','','1665392990','1667802434','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','94','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/chunjixiejiagong/1.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','');
INSERT INTO `hc_product` VALUES ('27','25','1','admin','管理员','3D打印样式测试','','1665392990','1667802418','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','74','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/jingmi3ddayin/27.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','');
INSERT INTO `hc_product` VALUES ('28','25','1','admin','管理员','3D打印样式测试','','1665392990','1667802409','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','84','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/jingmi3ddayin/28.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','');
INSERT INTO `hc_product` VALUES ('29','7','1','admin','管理员','转向总成部件(成熟工艺案例)','','1665392990','1668413028','3D,打印,样式,测试','因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','120','<p>因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','/uploads/202211/10/221110054539675.png','http://localhost:91/qichelingbujian/29.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','');
INSERT INTO `hc_product` VALUES ('30','7','1','admin','管理员','羊角总成部件(成熟工艺案例)','','1665392990','1668413018','3D,打印,样式,测试','因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','199','<p>因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/qichelingbujian/30.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','');
INSERT INTO `hc_product` VALUES ('31','42','1','admin','管理员','变速箱','','1665392990','1668073398','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','74','<p>变速箱</p>','网络','/uploads/202211/10/221110054300918.png','http://localhost:91/cndjiagong/31.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054300918.png\",\"alt\":\"变速箱-1\"},\"1\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054313111.png\",\"alt\":\"变速箱-1\"}}','');
INSERT INTO `hc_product` VALUES ('42','42','1','admin','管理员','底盘零部件','','1668073405','1668073456','底盘,零部件','底盘零部件','45','<p>底盘零部件</p>','网络','/uploads/202211/10/221110054342143.png','http://localhost:91/cndjiagong/42.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054347972.png\",\"alt\":\"底盘零部件-1\"},\"1\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054407972.png\",\"alt\":\"底盘零部件-1\"},\"2\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054412763.png\",\"alt\":\"底盘零部件-1\"}}','');
INSERT INTO `hc_product` VALUES ('32','47','1','admin','管理员','复膜设备','','1665392990','1669356995','复膜,设备','复膜设备','175','<p>复膜设备</p>','网络','/uploads/202211/25/221125021619238.jpg','http://localhost:91/qitashebei/32.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/25\\/221125021619238.jpg\",\"alt\":\"复膜设备-1\"},\"1\":{\"url\":\"\\/uploads\\/202211\\/25\\/221125021632150.jpg\",\"alt\":\"复膜设备-1\"}}','');
INSERT INTO `hc_product` VALUES ('35','12','1','admin','管理员','加工中心TL-1160VMC-L','','1668069551','1668069672','TL-1160VMC-L,加工中心','TL-1160VMC-L ','79','<p>TL-1160VMC-L <br/></p>','网络','/uploads/202211/10/221110044036463.png','http://localhost:91/jijiagongshebei/35.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110044036463.png\",\"alt\":\"加工中心TL-1160VMC-L-1\"}}','');
INSERT INTO `hc_product` VALUES ('33','11','1','admin','管理员','惠普4200尼龙打印机','','1665392990','1668067951','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','90','<p>打印机技术参数&nbsp;</p><p>有效的构建体积 380 x 284 x 380毫米 （15 x 11.2 x 15英寸）</p><p>构建速度22 高达4115立方厘米/小时 （251立方英寸/小时）</p><p>&nbsp;层厚 0.08毫米（0.003英寸）</p><p>作业处理 分辨率 (x, y) 600 dpi</p><p>打印分辨率 (x, y) 1200 dp</p><p><br/></p>','网络','/uploads/202211/10/221110041042965.png','http://localhost:91/dayinshebei/33.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110041042965.png\",\"alt\":\"惠普4200尼龙打印机-1\"},\"1\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110041056583.png\",\"alt\":\"惠普4200尼龙打印机-1\"},\"2\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110041102794.png\",\"alt\":\"惠普4200尼龙打印机-1\"},\"3\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110041107437.png\",\"alt\":\"惠普4200尼龙打印机-1\"}}','');
INSERT INTO `hc_product` VALUES ('34','11','1','admin','管理员','iSLM420DN 规格','','1665392990','1669194450','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','170','<h4>优质的功能部件</h4><p>非常适合功能部件原型设计和短期生产。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>出色的各向同性助您在可预控的打印时间内获得预期的部件质量。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>设备经过精心优化，可根据机械/功能/美学特性、精度和速度要求选择合适的打印模式。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>出众的生产效率图标，由全速转动的速度计表示</p><p><br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/></p><h4>提高生产效率</h4><p>支持连续打印，可提高部件日产出量。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>材料在封闭空间进行自动混合，可简化生产流程，打造洁净的生产环境。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>借助惠普出色的 HP Jet Fusion 3D 解决方案服务，大幅提升正常运行时间和生产力。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>成本优势图标，由内嵌美元符号的向下箭头表示</p><p><br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/></p><h4>降低生产成本</h4><p>降低运营成本，缩短生产周期。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>我们的 3D 打印解决方案定价竞争力强，能够以非常低的单部件成本进行生产。<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>使用兼具出色可重用性与经济效益的材料，优化打印成本和部件质量。</p><p><br style=\"white-space: normal;\"/></p><p><br style=\"white-space: normal;\"/></p><p><br/></p>','网络','/uploads/202211/10/221110034553991.png','http://localhost:91/dayinshebei/34.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110034553991.png\",\"alt\":\"iSLM420DN 规格-1\"}}','<table><tbody><tr class=\"firstRow\"><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all;\">极光系统</td><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all;\">激光类型光纤激光器 × 2,&nbsp; 波长1064nm,&nbsp; 激光器功率500W × 2</td></tr><tr><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all;\">重涂系统</td><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all;\">涂铺方式刮刀双向铺粉,&nbsp; 供粉方式上落粉、粉循环系统自动送粉,&nbsp; 正常层厚0.05mm,&nbsp; 快速制作层厚0.05~0.15mm,&nbsp; 精密制作层厚0.02~0.05mm</td></tr><tr><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all;\">光学扫描系统</td><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all;\">光斑(直径@1/e²)0.06~0.20mm,&nbsp; 扫描振镜高速扫描振镜 × 2,&nbsp; 零件扫描速度1.0~4.0m/s（推荐）,&nbsp; 零件跳跨速度10.0~20.0m/s（推荐）,&nbsp; 参考制作速度15~5</td></tr><tr><td width=\"831\" valign=\"top\" style=\"word-break: break-all;\">保护系统</td><td width=\"831\" valign=\"top\" style=\"word-break: break-all;\"><p>保护气体氮气、氩气（活泼金属材料必须使用氩气保护）,&nbsp;</p><p>流量控制0~3 L/min 智能调节,&nbsp;&nbsp;</p><p>除尘控制高效保护气体循环系统</p></td></tr><tr><td width=\"831\" valign=\"top\" style=\"word-break: break-all;\">制作缸</td><td width=\"831\" valign=\"top\" style=\"word-break: break-all;\"><p>标准容积约 80L,&nbsp; XY制作平台420mm(X) × 420mm(Y) （未计螺孔圆角等）,&nbsp;</p><p>&nbsp;Z轴500mm （含基板厚度）,&nbsp; 最大制件重量150kg,&nbsp; 加热类型精密电阻丝加热,&nbsp; 成型材料</p></td></tr></tbody></table><p><br/></p>');
INSERT INTO `hc_product` VALUES ('26','11','1','admin','管理员','iSLA1300D 规格','','1665392990','1669194720','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','121','<p>高稳定性<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>自动标定<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>变光斑<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>可换树脂槽<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>分体式设计<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>进口光学器件<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>自动闭环控制系统<br style=\"box-sizing: border-box; animation-fill-mode: both; font-family: 微软雅黑; padding: 0px; margin: 0px; color: rgb(153, 153, 153); font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);\"/>一键启动&nbsp;<br/></p>','网络','/uploads/202211/10/221110032746776.png','http://localhost:91/dayinshebei/26.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110032746776.png\",\"alt\":\"iSLA1300D 规格-1\"}}','<table width=\"1689\"><tbody><tr class=\"firstRow\"><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"153\">极光系统</td><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"1535\"><br/>激光器数量双激光器,激光类型二极管泵浦固体激光器Nd:YVO₄,激波长354.7nm,激光器功率1000/2000/3000mW</td></tr><tr><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"153\">重涂系统</td><td valign=\"top\" colspan=\"1\" rowspan=\"1\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"1535\">涂铺方式智能定位-真空吸附涂铺,正常层厚0.1mm, 快速制作层厚0.1~0.15mm,精密制作层厚0.05~0.1mm</td></tr><tr><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"153\">光学扫描系统</td><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"1535\">光斑(直径@1/e²),&nbsp; 0.10~0.16mm（Normal） 0.10~0.50mm（动态变焦）,&nbsp; 扫描振镜高速扫描振镜（双振镜）, 零件扫描速度6.0~20.0m/s（推荐）,&nbsp; 零件跳跨速</td></tr><tr><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"153\">升降系统</td><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"1535\">重复定位精度±0.01mm,&nbsp; 升降电机高精度伺服电机,&nbsp; 基准平台大理石基准平台</td></tr><tr><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"153\">树脂槽</td><td valign=\"top\" style=\"word-break: break-all; border-color: rgb(221, 221, 221);\" width=\"1535\">重复定位精度±0.01mm,&nbsp; 升降电机高精度伺服电机,&nbsp; 基准平台大理石基准平台</td></tr></tbody></table><p><br/></p>');
INSERT INTO `hc_product` VALUES ('36','12','1','admin','管理员','加工中心TL-850VMC-L','','1668069682','1668069718','加工中心,TL-1160VMC-L','TL-850VMC-L','97','<p>TL-850VMC-L</p>','网络','/uploads/202211/10/221110044149118.png','http://localhost:91/jijiagongshebei/36.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110044149118.png\",\"alt\":\"加工中心TL-850VMC-L-1\"}}','');
INSERT INTO `hc_product` VALUES ('37','12','1','admin','管理员','CK6160数控车床','','1668069752','1668069786','CK6160,数控车床','CK6160','47','<p>CK6160</p>','网络','/uploads/202211/10/221110044254131.png','http://localhost:91/jijiagongshebei/37.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110044254131.png\",\"alt\":\"CK6160数控车床-1\"}}','');
INSERT INTO `hc_product` VALUES ('38','12','1','admin','管理员','数控车床2SK5OP','','1668069788','1668069818','数控车床,2SK5OP','数控车床2SK5OP','98','<p>数控车床2SK5OP</p>','网络','/uploads/202211/10/221110044331585.png','http://localhost:91/jijiagongshebei/38.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110044331585.png\",\"alt\":\"数控车床2SK5OP-1\"}}','');
INSERT INTO `hc_product` VALUES ('39','12','1','admin','管理员','五轴联动加工中心','','1668069840','1669259202','五轴,联动,加工中心','五轴联动加工中心','32','<p>五轴联动加工中心</p>','网络','/uploads/202211/10/221110044420596.png','http://localhost:91/jijiagongshebei/39.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110044420596.png\",\"alt\":\"五轴联动加工中心-1\"}}','<p><img src=\"/uploads/ueditor/image/20221124/1669259201152964.png\" title=\"五轴联动加工中心\" alt=\"五轴联动加工中心\"/></p>');
INSERT INTO `hc_product` VALUES ('40','42','1','admin','管理员','CNC加工1','','1668073197','1668392536','CNC,加工','CNC加工1','25','<p>CNC加工1</p>','网络','/uploads/202211/10/221110054021213.png','http://localhost:91/cndjiagong/40.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('41','42','1','admin','管理员','CNC加工2','','1668073335','1668392526','CNC,加工','CNC加工2','87','<p>CNC加工2</p>','网络','/uploads/202211/10/221110054224636.png','http://localhost:91/cndjiagong/41.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('43','42','1','admin','管理员','机器人手臂','','1668073477','1668073500','机器人,手臂','机器人手臂','42','<p>机器人手臂</p>','网络','/uploads/202211/10/221110054449118.png','http://localhost:91/cndjiagong/43.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054449118.png\",\"alt\":\"机器人手臂-1\"}}','');
INSERT INTO `hc_product` VALUES ('44','42','1','admin','管理员','减速机壳体','','1668073504','1668073525','减速,机壳','减速机壳体','61','<p>减速机壳体</p>','网络','/uploads/202211/10/221110054517905.png','http://localhost:91/cndjiagong/44.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054517905.png\",\"alt\":\"减速机壳体-1\"}}','');
INSERT INTO `hc_product` VALUES ('45','42','1','admin','管理员','汽车变速箱部件','','1668073527','1668073545','汽车,变速箱,部件','汽车变速箱部件','35','<p>汽车变速箱部件</p>','网络','/uploads/202211/10/221110054539675.png','http://localhost:91/cndjiagong/45.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054539675.png\",\"alt\":\"汽车变速箱部件-1\"}}','');
INSERT INTO `hc_product` VALUES ('46','42','1','admin','管理员','三项机电壳体','','1668073547','1668393336','','三项机电壳体','84','<p>三项机电壳体</p>','网络','/uploads/202211/10/221110054604637.png','http://localhost:91/cndjiagong/46.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054604637.png\",\"alt\":\"汽车零部件-1\"},\"1\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054617856.png\",\"alt\":\"汽车零部件-1\"},\"2\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054643541.png\",\"alt\":\"汽车零部件-1\"},\"3\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054650809.png\",\"alt\":\"汽车零部件-1\"}}','');
INSERT INTO `hc_product` VALUES ('47','42','1','admin','管理员','汽车转向零部','','1668073618','1668073636','汽车,转向,零部','汽车转向零部','79','<p>汽车转向零部</p>','网络','/uploads/202211/10/221110054710880.png','http://localhost:91/cndjiagong/47.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('48','42','1','admin','管理员','CNC加工10','','1668073638','1668392516','CNC,加工','CNC加工10','30','<p>CNC加工10</p>','网络','/uploads/202211/10/221110054736408.png','http://localhost:91/cndjiagong/48.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('49','42','1','admin','管理员','CNC加工11','','1668073666','1668392506','CNC,加工','CNC加工11','80','<p>CNC加工11</p>','网络','/uploads/202211/10/221110054800404.png','http://localhost:91/cndjiagong/49.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('50','42','1','admin','管理员','羊角总成部件','','1668073691','1668073708','羊角,总成,部件','羊角总成部件','20','<p>羊角总成部件</p>','网络','/uploads/202211/10/221110054821295.png','http://localhost:91/cndjiagong/50.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('51','42','1','admin','管理员','CNC加工13','','1668073710','1668392496','CNC,加工','CNC加工13','64','<p>CNC加工13</p>','网络','/uploads/202211/10/221110054846301.png','http://localhost:91/cndjiagong/51.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054846301.png\",\"alt\":\"CND加工13-1\"}}','');
INSERT INTO `hc_product` VALUES ('52','42','1','admin','管理员','R系列转向机壳','','1668073735','1668132491','系列,转向,机壳','R系列转向机壳','41','<p>R系列转向机壳</p>','网络','/uploads/202211/10/221110054907456.png','http://localhost:91/cndjiagong/52.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110054907456.png\",\"alt\":\"R系列转向机壳-1\"}}','');
INSERT INTO `hc_product` VALUES ('53','13','1','admin','管理员','2.5次元影像测量仪','','1668074772','1668074805','次元,影像,测量仪','2.5次元影像测量仪','89','<p>2.5次元影像测量仪</p>','网络','/uploads/202211/10/221110060636790.png','http://localhost:91/jianceshebei/53.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110060636790.png\",\"alt\":\"2.5次元影像测量仪1-1\"}}','');
INSERT INTO `hc_product` VALUES ('54','13','1','admin','管理员','三坐标测量仪','','1668074807','1668074933','坐标,测量仪','三坐标测量仪','66','<p>三坐标测量仪</p>','网络','/uploads/202211/10/221110060656312.png','http://localhost:91/jianceshebei/54.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/10\\/221110060656312.png\",\"alt\":\"三坐标测量仪-1\"}}','');
INSERT INTO `hc_product` VALUES ('130','7','1','admin','管理员','发动机部件(成熟工艺案例)','','1668412526','1668413011','发动机,部件,成熟,工艺,案例','因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','28','<p>因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/qichelingbujian/130.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('131','7','1','admin','管理员','变速箱部件(成熟工艺案例)','','1668412537','1668413004','变速箱,部件,成熟,工艺,案例','因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','83','<p>因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/qichelingbujian/131.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('132','7','1','admin','管理员','底盘零部件(成熟工艺案例)','','1668412548','1668412996','底盘,零部件,成熟,工艺,案例','因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','88','<p>因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/qichelingbujian/132.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('133','7','1','admin','管理员','底盘零部件(成熟工艺案例)','','1668412558','1668412989','底盘,零部件,成熟,工艺,案例','因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','37','<p>因相关内容有敏感信息需要保密所l以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/qichelingbujian/133.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('134','8','1','admin','管理员','水冷产品零部件(成熟工艺案例)','','1668413386','1668413400','零部件,成熟,工艺,案例,产品,薄壁','因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','54','<p>因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/hangkonghang/134.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('135','8','1','admin','管理员','通讯产品零部件(成熟工艺案例)','','1668413423','1668413443','零部件,成熟,工艺,案例,产品,薄壁','因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','52','<p>因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/hangkonghang/135.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('55','8','1','admin','管理员','薄壁产品零部件(成熟工艺案例)','','1668132803','1668413384','航天航空','　　3D打印在航空航天方面的应用已经趋于成熟，并且占比越来越大，成为3D打印应用的主要市场之一。比如，美国宇航局NASA在外太空探索计划中，大量采用了3D打印技术，从火箭部...','28','<p>因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','/uploads/202211/11/221111101341959.png','http://localhost:91/hangkonghang/55.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111101341959.png\",\"alt\":\"航天航空1-1\"}}','');
INSERT INTO `hc_product` VALUES ('136','9','1','admin','管理员','薄壁产品零部件(成熟工艺案例)','','1668413459','1668413467','薄壁,产品,零部件,成熟,工艺,案例','因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','57','<p>因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/jungong/136.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('137','9','1','admin','管理员','水冷产品零部件(成熟工艺案例) ','','1668413471','1668413484','','因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','49','<p>因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','','http://localhost:91/jungong/137.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('56','9','1','admin','管理员','通讯产品零部件(成熟工艺案例)','','1668132916','1668413581','通讯产品,零部件,成熟,工艺,案例','因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)','51','<p>因相关内容有敏感信息需要保密所以不做展示，如有需求可以通过超链接在线联系对应部门。谢谢谅解!(仅介绍案例名称)</p>','网络','/uploads/202211/11/221111101341959.png','http://localhost:91/jungong/56.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111101341959.png\",\"alt\":\"QQ截图20221111101314.png\"}}','');
INSERT INTO `hc_product` VALUES ('57','26','1','admin','管理员','医疗','','1668133108','1668133160','医疗','　　中国医疗产品需求增长高于全球平均，巨大的人口基数以及逐年快速递增的老龄化人口和人们不断增强的健康意识、国家政策、医疗信息化及技术革命的推动，中国医疗产品市场需...','61','<div>　　中国医疗产品需求增长高于全球平均，巨大的人口基数以及逐年快速递增的老龄化人口和人们不断增强的健康意识、国家政策、医疗信息化及技术革命的推动，中国医疗产品市场需求持续快速增长。而3D打印技术正被越来越普遍地应用于医疗领域，尤其是小型医疗辅助设备及配件，比如准确的验证零件的尺寸规格是小型医疗器械工件设计和产品改进的一个关键环节，尤其是微创介入类产品，除了尺寸小，而且材料比较柔软或者结构比较复杂，非常需要高精度、非接触式的三维扫描测量检测和3D打印设备的协助。</div><div>&nbsp;</div><div>　　3D打印技术在医疗拓展领域中的应用主要在以下几个方面：</div><div>　　（1）快速制造模具原型：减少开钢模和石膏模具的时间与费用成本，免去了复杂的过程，还可以快速地一次成型；</div><div>　　（2）医疗设备设计创新：3D打印可以克服一些传统制造上无法达成的设计，制作出更复杂的结构，更好地实现医疗方面的特殊需要；</div><div>　　（3）医疗辅助设备的制造：用于制作科研和临床的个性化术前模型、手术导板、外固定支具等批量小、品类多的医疗器械产品，很好地满足了客户在成本、效率和品质方面的要求，缩减交付周期；</div><div>　　（4）临床辅助与演示：重构符合人体生理特征的3D模型，为医生精确找寻疾病原因和治疗靶点提供有力参考，同时也能够更直观向医科学生进行临床培训；</div><div>　　（5）临床前设备测试：确保手术安全、高效和微创的优化手术方案，提供准确决策和精确干预，能够提高医疗技术水平，有效的降低医疗事故发生率。</div><div>&nbsp;</div><div>　　创毅的系列光固化(SLA)3D打印机可以打印制作患者需要动手术的骨骼和器官等成型模具，帮助医生在SLA成型模型上进行模拟手术，准确对准患处，以次来减少正常组织的损伤，来提高手术成功率。</div><div>&nbsp;</div><div>　　另一方面，创毅的系列光固化(SLA)3D打印机还可以制作个性化定制助听器外壳或助听器模型，有效提高客户制造商实现规模化和按需生产，使快速的原型制造和批量生产成为可能。</div><p><br/></p>','网络','/uploads/202211/11/221111101903555.png','http://localhost:91/yiliao/57.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111101903555.png\",\"alt\":\"医疗-1\"}}','');
INSERT INTO `hc_product` VALUES ('58','27','1','admin','管理员','机构复杂零件1','','1668133108','1668133226','医疗','　　中国医疗产品需求增长高于全球平均，巨大的人口基数以及逐年快速递增的老龄化人口和人们不断增强的健康意识、国家政策、医疗信息化及技术革命的推动，中国医疗产品市场需...','62','<div>　　中国医疗产品需求增长高于全球平均，巨大的人口基数以及逐年快速递增的老龄化人口和人们不断增强的健康意识、国家政策、医疗信息化及技术革命的推动，中国医疗产品市场需求持续快速增长。而3D打印技术正被越来越普遍地应用于医疗领域，尤其是小型医疗辅助设备及配件，比如准确的验证零件的尺寸规格是小型医疗器械工件设计和产品改进的一个关键环节，尤其是微创介入类产品，除了尺寸小，而且材料比较柔软或者结构比较复杂，非常需要高精度、非接触式的三维扫描测量检测和3D打印设备的协助。</div><div>&nbsp;</div><div>　　3D打印技术在医疗拓展领域中的应用主要在以下几个方面：</div><div>　　（1）快速制造模具原型：减少开钢模和石膏模具的时间与费用成本，免去了复杂的过程，还可以快速地一次成型；</div><div>　　（2）医疗设备设计创新：3D打印可以克服一些传统制造上无法达成的设计，制作出更复杂的结构，更好地实现医疗方面的特殊需要；</div><div>　　（3）医疗辅助设备的制造：用于制作科研和临床的个性化术前模型、手术导板、外固定支具等批量小、品类多的医疗器械产品，很好地满足了客户在成本、效率和品质方面的要求，缩减交付周期；</div><div>　　（4）临床辅助与演示：重构符合人体生理特征的3D模型，为医生精确找寻疾病原因和治疗靶点提供有力参考，同时也能够更直观向医科学生进行临床培训；</div><div>　　（5）临床前设备测试：确保手术安全、高效和微创的优化手术方案，提供准确决策和精确干预，能够提高医疗技术水平，有效的降低医疗事故发生率。</div><div>&nbsp;</div><div>　　创毅的系列光固化(SLA)3D打印机可以打印制作患者需要动手术的骨骼和器官等成型模具，帮助医生在SLA成型模型上进行模拟手术，准确对准患处，以次来减少正常组织的损伤，来提高手术成功率。</div><div>&nbsp;</div><div>　　另一方面，创毅的系列光固化(SLA)3D打印机还可以制作个性化定制助听器外壳或助听器模型，有效提高客户制造商实现规模化和按需生产，使快速的原型制造和批量生产成为可能。</div><p><br/></p>','网络','/uploads/202211/11/221111101903555.png','http://localhost:91/jigoufuza/58.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111101903555.png\",\"alt\":\"医疗-1\"}}','');
INSERT INTO `hc_product` VALUES ('59','28','1','admin','管理员','摩擦焊接零件1','','1668133108','1668133251','医疗','　　中国医疗产品需求增长高于全球平均，巨大的人口基数以及逐年快速递增的老龄化人口和人们不断增强的健康意识、国家政策、医疗信息化及技术革命的推动，中国医疗产品市场需...','66','<div>　　中国医疗产品需求增长高于全球平均，巨大的人口基数以及逐年快速递增的老龄化人口和人们不断增强的健康意识、国家政策、医疗信息化及技术革命的推动，中国医疗产品市场需求持续快速增长。而3D打印技术正被越来越普遍地应用于医疗领域，尤其是小型医疗辅助设备及配件，比如准确的验证零件的尺寸规格是小型医疗器械工件设计和产品改进的一个关键环节，尤其是微创介入类产品，除了尺寸小，而且材料比较柔软或者结构比较复杂，非常需要高精度、非接触式的三维扫描测量检测和3D打印设备的协助。</div><div>&nbsp;</div><div>　　3D打印技术在医疗拓展领域中的应用主要在以下几个方面：</div><div>　　（1）快速制造模具原型：减少开钢模和石膏模具的时间与费用成本，免去了复杂的过程，还可以快速地一次成型；</div><div>　　（2）医疗设备设计创新：3D打印可以克服一些传统制造上无法达成的设计，制作出更复杂的结构，更好地实现医疗方面的特殊需要；</div><div>　　（3）医疗辅助设备的制造：用于制作科研和临床的个性化术前模型、手术导板、外固定支具等批量小、品类多的医疗器械产品，很好地满足了客户在成本、效率和品质方面的要求，缩减交付周期；</div><div>　　（4）临床辅助与演示：重构符合人体生理特征的3D模型，为医生精确找寻疾病原因和治疗靶点提供有力参考，同时也能够更直观向医科学生进行临床培训；</div><div>　　（5）临床前设备测试：确保手术安全、高效和微创的优化手术方案，提供准确决策和精确干预，能够提高医疗技术水平，有效的降低医疗事故发生率。</div><div>&nbsp;</div><div>　　创毅的系列光固化(SLA)3D打印机可以打印制作患者需要动手术的骨骼和器官等成型模具，帮助医生在SLA成型模型上进行模拟手术，准确对准患处，以次来减少正常组织的损伤，来提高手术成功率。</div><div>&nbsp;</div><div>　　另一方面，创毅的系列光固化(SLA)3D打印机还可以制作个性化定制助听器外壳或助听器模型，有效提高客户制造商实现规模化和按需生产，使快速的原型制造和批量生产成为可能。</div><p><br/></p>','网络','/uploads/202211/11/221111101903555.png','http://localhost:91/bobimocahan/59.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111101903555.png\",\"alt\":\"医疗-1\"}}','');
INSERT INTO `hc_product` VALUES ('60','43','1','admin','管理员','1','','1668133375','1668133475','1','1','96','<p>1</p>','网络','/uploads/202211/11/221111102342177.png','http://localhost:91/slaguangguhuadayinchanpin/60.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102342177.png\",\"alt\":\"1-1\"}}','');
INSERT INTO `hc_product` VALUES ('61','43','1','admin','管理员','2','','1668133519','1668133562','2','2','33','<p>2</p>','网络','/uploads/202211/11/221111102524812.png','http://localhost:91/slaguangguhuadayinchanpin/61.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102524812.png\",\"alt\":\"2-1\"}}','');
INSERT INTO `hc_product` VALUES ('62','43','1','admin','管理员','3','','1668133574','1668133593','3','4','25','<p>4</p>','网络','/uploads/202211/11/221111102623379.png','http://localhost:91/slaguangguhuadayinchanpin/62.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102623379.png\",\"alt\":\"3-1\"}}','');
INSERT INTO `hc_product` VALUES ('63','43','1','admin','管理员','5','','1668133596','1668133615','5','5','55','<p>5</p>','网络','/uploads/202211/11/221111102643104.png','http://localhost:91/slaguangguhuadayinchanpin/63.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102643104.png\",\"alt\":\"5-1\"}}','');
INSERT INTO `hc_product` VALUES ('64','43','1','admin','管理员','6','','1668133618','1668133638','6','6','24','<p>6</p>','网络','/uploads/202211/11/221111102710794.png','http://localhost:91/slaguangguhuadayinchanpin/64.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102710794.png\",\"alt\":\"6-1\"}}','');
INSERT INTO `hc_product` VALUES ('65','43','1','admin','管理员','7','','1668133640','1668133653','7','7','13','<p>7</p>','网络','/uploads/202211/11/221111102726113.png','http://localhost:91/slaguangguhuadayinchanpin/65.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102726113.png\",\"alt\":\"7-1\"}}','');
INSERT INTO `hc_product` VALUES ('66','43','1','admin','管理员','8','','1668133660','1668133674','8','8','16','<p>8</p>','网络','/uploads/202211/11/221111102746481.png','http://localhost:91/slaguangguhuadayinchanpin/66.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102746481.png\",\"alt\":\"8-1\"}}','');
INSERT INTO `hc_product` VALUES ('67','43','1','admin','管理员','9','','1668133676','1668133694','9','9','22','<p>9</p>','网络','/uploads/202211/11/221111102805162.png','http://localhost:91/slaguangguhuadayinchanpin/67.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102805162.png\",\"alt\":\"9-1\"}}','');
INSERT INTO `hc_product` VALUES ('68','43','1','admin','管理员','17','','1668133697','1668392409','10','底盘零部件1','53','<p>17</p>','网络','/uploads/202211/11/221111102824966.png','http://localhost:91/slaguangguhuadayinchanpin/68.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102824966.png\",\"alt\":\"底盘零部件-1\"}}','');
INSERT INTO `hc_product` VALUES ('69','43','1','admin','管理员','11','','1668133733','1668133743','11','11','10','<p>11</p>','网络','/uploads/202211/11/221111102858609.png','http://localhost:91/slaguangguhuadayinchanpin/69.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102858609.png\",\"alt\":\"11-1\"}}','');
INSERT INTO `hc_product` VALUES ('71','43','1','admin','管理员','14','','1668133761','1668133798','13','14','15','<p>14</p>','网络','/uploads/202211/11/221111102952229.png','http://localhost:91/slaguangguhuadayinchanpin/71.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102952229.png\",\"alt\":\"14-1\"}}','');
INSERT INTO `hc_product` VALUES ('73','43','1','admin','管理员','16','','1668133820','1668133833','16','16','50','<p>16</p>','网络','/uploads/202211/11/221111103027481.png','http://localhost:91/slaguangguhuadayinchanpin/73.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103027481.png\",\"alt\":\"16-1\"}}','');
INSERT INTO `hc_product` VALUES ('74','44','1','admin','管理员','17','','1668133848','1668482142','1','1','74','<p>17</p>','网络','/uploads/202211/11/221111103105448.png','http://localhost:91/slajinshudayinchanpin/74.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('75','44','1','admin','管理员','18','','1668133874','1668482150','2','2','97','<p>18</p>','网络','/uploads/202211/11/221111103119385.png','http://localhost:91/slajinshudayinchanpin/75.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('76','44','1','admin','管理员','19','','1668133883','1668482157','3','3','77','<p>19</p>','网络','/uploads/202211/11/221111103130811.png','http://localhost:91/slajinshudayinchanpin/76.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('77','44','1','admin','管理员','20','','1668134255','1668482166','4','4','26','<p>20</p>','网络','/uploads/202211/11/221111103740954.png','http://localhost:91/slajinshudayinchanpin/77.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103740954.png\",\"alt\":\"4-1\"}}','');
INSERT INTO `hc_product` VALUES ('78','44','1','admin','管理员','21','','1668134271','1668482173','5','5','75','<p>21</p>','网络','/uploads/202211/11/221111103757376.png','http://localhost:91/slajinshudayinchanpin/78.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103757376.png\",\"alt\":\"5-1\"}}','');
INSERT INTO `hc_product` VALUES ('80','44','1','admin','管理员','22','','1668134331','1668482182','7','7','44','<p>22</p>','网络','/uploads/202211/11/221111103900758.png','http://localhost:91/slajinshudayinchanpin/80.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103900758.png\",\"alt\":\"7-1\"}}','');
INSERT INTO `hc_product` VALUES ('81','44','1','admin','管理员','23','','1668134351','1668482215','8','8','38','<p>23</p>','网络','/uploads/202211/11/221111103917477.png','http://localhost:91/slajinshudayinchanpin/81.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103917477.png\",\"alt\":\"8-1\"}}','');
INSERT INTO `hc_product` VALUES ('82','44','1','admin','管理员','24','','1668134368','1668482223','9','9','17','<p>24</p>','网络','/uploads/202211/11/221111103934616.png','http://localhost:91/slajinshudayinchanpin/82.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103934616.png\",\"alt\":\"9-1\"}}','');
INSERT INTO `hc_product` VALUES ('83','44','1','admin','管理员','25','','1668134384','1668482232','25','10','95','<p>25</p>','网络','/uploads/202211/11/221111103950492.png','http://localhost:91/slajinshudayinchanpin/83.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103950492.png\",\"alt\":\"10-1\"}}','');
INSERT INTO `hc_product` VALUES ('84','44','1','admin','管理员','26','','1668134400','1668482242','11','11','74','<p>26</p>','网络','/uploads/202211/11/221111104006197.png','http://localhost:91/slajinshudayinchanpin/84.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104006197.png\",\"alt\":\"11-1\"}}','');
INSERT INTO `hc_product` VALUES ('85','44','1','admin','管理员','27','','1668134414','1668482252','12','12','53','<p>27</p>','网络','/uploads/202211/11/221111104023689.png','http://localhost:91/slajinshudayinchanpin/85.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104023689.png\",\"alt\":\"12-1\"}}','');
INSERT INTO `hc_product` VALUES ('86','44','1','admin','管理员','28','','1668134442','1668482260','13','13','75','<p>28</p>','网络','/uploads/202211/11/221111104051683.png','http://localhost:91/slajinshudayinchanpin/86.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104051683.png\",\"alt\":\"13-1\"}}','');
INSERT INTO `hc_product` VALUES ('87','44','1','admin','管理员','29','','1668134460','1668482269','14','14','85','<p>29</p>','网络','/uploads/202211/11/221111104106337.png','http://localhost:91/slajinshudayinchanpin/87.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104106337.png\",\"alt\":\"14-1\"}}','');
INSERT INTO `hc_product` VALUES ('88','44','1','admin','管理员','30','','1668134476','1668482279','15','15','81','<p>30</p>','网络','/uploads/202211/11/221111104123379.png','http://localhost:91/slajinshudayinchanpin/88.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104123379.png\",\"alt\":\"15-1\"}}','');
INSERT INTO `hc_product` VALUES ('89','44','1','admin','管理员','31','','1668134491','1668482287','16','16','48','<p>31</p>','网络','/uploads/202211/11/221111104138654.png','http://localhost:91/slajinshudayinchanpin/89.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104138654.png\",\"alt\":\"16-1\"}}','');
INSERT INTO `hc_product` VALUES ('90','44','1','admin','管理员','32','','1668134507','1668482295','17','17','87','<p>32</p>','网络','/uploads/202211/11/221111104152709.png','http://localhost:91/slajinshudayinchanpin/90.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104152709.png\",\"alt\":\"17-1\"}}','');
INSERT INTO `hc_product` VALUES ('91','44','1','admin','管理员','33','','1668134521','1668482302','18','18','11','<p>33</p>','网络','/uploads/202211/11/221111104206367.png','http://localhost:91/slajinshudayinchanpin/91.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104206367.png\",\"alt\":\"18-1\"}}','');
INSERT INTO `hc_product` VALUES ('92','44','1','admin','管理员','34','','1668134535','1668482310','19','19','33','<p>34</p>','网络','/uploads/202211/11/221111104222390.png','http://localhost:91/slajinshudayinchanpin/92.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104222390.png\",\"alt\":\"19-1\"}}','');
INSERT INTO `hc_product` VALUES ('93','44','1','admin','管理员','35','','1668134550','1668482323','20','20','42','<p>35</p>','网络','/uploads/202211/11/221111104237780.png','http://localhost:91/slajinshudayinchanpin/93.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104237780.png\",\"alt\":\"20-1\"}}','');
INSERT INTO `hc_product` VALUES ('94','44','1','admin','管理员','36','','1668134571','1668482332','21','21','95','<p>36</p>','网络','/uploads/202211/11/221111104300258.png','http://localhost:91/slajinshudayinchanpin/94.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104300258.png\",\"alt\":\"21-1\"}}','');
INSERT INTO `hc_product` VALUES ('95','44','1','admin','管理员','37','','1668134626','1668482341','22','22','53','<p>37</p>','网络','/uploads/202211/11/221111104351641.png','http://localhost:91/slajinshudayinchanpin/95.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104351641.png\",\"alt\":\"22-1\"}}','');
INSERT INTO `hc_product` VALUES ('96','44','1','admin','管理员','38','','1668134639','1668482350','23','23','75','<p>38</p>','网络','/uploads/202211/11/221111104407176.png','http://localhost:91/slajinshudayinchanpin/96.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104407176.png\",\"alt\":\"23-1\"}}','');
INSERT INTO `hc_product` VALUES ('97','44','1','admin','管理员','39','','1668134655','1668482359','24','25','77','<p>39</p>','网络','/uploads/202211/11/221111104423623.png','http://localhost:91/slajinshudayinchanpin/97.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104423623.png\",\"alt\":\"24-1\"}}','');
INSERT INTO `hc_product` VALUES ('98','44','1','admin','管理员','40','','1668134672','1668482367','26','26','91','<p>40</p>','网络','/uploads/202211/11/221111104438936.png','http://localhost:91/slajinshudayinchanpin/98.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104438936.png\",\"alt\":\"26-1\"}}','');
INSERT INTO `hc_product` VALUES ('99','45','1','admin','管理员','41','','1668134704','1668482392','5','1','25','<p>41</p>','网络','/uploads/202211/11/221111104521172.png','http://localhost:91/slanilongdayinchanpin/99.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104521172.png\",\"alt\":\"1-1\"}}','');
INSERT INTO `hc_product` VALUES ('100','45','1','admin','管理员','42','','1668134742','1668482399','2','2','69','<p>42</p>','网络','/uploads/202211/11/221111104548937.png','http://localhost:91/slanilongdayinchanpin/100.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104548937.png\",\"alt\":\"2-1\"}}','');
INSERT INTO `hc_product` VALUES ('101','45','1','admin','管理员','43','','1668134757','1668482406','3','3','69','<p>43</p>','网络','/uploads/202211/11/221111104602138.png','http://localhost:91/slanilongdayinchanpin/101.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104602138.png\",\"alt\":\"3-1\"}}','');
INSERT INTO `hc_product` VALUES ('102','45','1','admin','管理员','44','','1668134772','1668482415','4','4','59','<p>44</p>','网络','/uploads/202211/11/221111104619445.png','http://localhost:91/slanilongdayinchanpin/102.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104619445.png\",\"alt\":\"4-1\"}}','');
INSERT INTO `hc_product` VALUES ('103','45','1','admin','管理员','45','','1668134787','1668482424','5','5','56','<p>45</p>','网络','/uploads/202211/11/221111104637918.png','http://localhost:91/slanilongdayinchanpin/103.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104637918.png\",\"alt\":\"5-1\"}}','');
INSERT INTO `hc_product` VALUES ('104','46','1','admin','管理员','48','','1668134820','1668482491','1','1','90','<p>48</p>','网络','/uploads/202211/11/221111104708470.png','http://localhost:91/fumochanpin/104.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104708470.png\",\"alt\":\"1-1\"}}','');
INSERT INTO `hc_product` VALUES ('105','46','1','admin','管理员','49','','1668134857','1668482499','2','2','83','<p>49</p>','网络','/uploads/202211/11/221111104744366.png','http://localhost:91/fumochanpin/105.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104744366.png\",\"alt\":\"2-1\"}}','');
INSERT INTO `hc_product` VALUES ('106','46','1','admin','管理员','50','','1668134892','1668482506','3','3','28','<p>50</p>','网络','/uploads/202211/11/221111104817199.png','http://localhost:91/fumochanpin/106.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104817199.png\",\"alt\":\"3-1\"}}','');
INSERT INTO `hc_product` VALUES ('107','46','1','admin','管理员','51','','1668134911','1668482513','4','4','74','<p>51</p>','网络','/uploads/202211/11/221111104838443.png','http://localhost:91/fumochanpin/107.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104838443.png\",\"alt\":\"4-1\"}}','');
INSERT INTO `hc_product` VALUES ('108','68','1','admin','管理员','52','','1668134938','1668482584','1','1','89','<p>52</p>','网络','/uploads/202211/11/221111104910263.png','http://localhost:91/jingmizhuzaochanpin/108.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104910263.png\",\"alt\":\"1-1\"}}','');
INSERT INTO `hc_product` VALUES ('109','68','1','admin','管理员','53','','1668134958','1668482591','2','2','15','<p>53</p>','网络','/uploads/202211/11/221111104926392.png','http://localhost:91/jingmizhuzaochanpin/109.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104926392.png\",\"alt\":\"2-1\"}}','');
INSERT INTO `hc_product` VALUES ('110','68','1','admin','管理员','54','','1668134978','1668482600','3','3','22','<p>54</p>','网络','/uploads/202211/11/221111104944472.png','http://localhost:91/jingmizhuzaochanpin/110.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104944472.png\",\"alt\":\"3-1\"}}','');
INSERT INTO `hc_product` VALUES ('111','68','1','admin','管理员','55','','1668134991','1668482608','4','4','44','<p>55</p>','网络','/uploads/202211/11/221111104957806.png','http://localhost:91/jingmizhuzaochanpin/111.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111104957806.png\",\"alt\":\"4-1\"}}','');
INSERT INTO `hc_product` VALUES ('112','68','1','admin','管理员','56','','1668135006','1668482617','5','5','20','<p>56</p>','网络','/uploads/202211/11/221111105012682.png','http://localhost:91/jingmizhuzaochanpin/112.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105012682.png\",\"alt\":\"5-1\"}}','');
INSERT INTO `hc_product` VALUES ('113','68','1','admin','管理员','57','','1668135020','1668482654','6','6','69','<p>57</p>','网络','/uploads/202211/11/221111105026978.png','http://localhost:91/jingmizhuzaochanpin/113.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105026978.png\",\"alt\":\"6-1\"}}','');
INSERT INTO `hc_product` VALUES ('114','68','1','admin','管理员','58','','1668135034','1668482662','7','7','67','<p>58</p>','网络','/uploads/202211/11/221111105039733.png','http://localhost:91/jingmizhuzaochanpin/114.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105039733.png\",\"alt\":\"7-1\"}}','');
INSERT INTO `hc_product` VALUES ('115','68','1','admin','管理员','59','','1668135048','1668482672','8','8','29','<p>59</p>','网络','/uploads/202211/11/221111105055341.png','http://localhost:91/jingmizhuzaochanpin/115.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105055341.png\",\"alt\":\"8-1\"}}','');
INSERT INTO `hc_product` VALUES ('116','68','1','admin','管理员','60','','1668135064','1668482681','9','9','34','<p>60</p>','网络','/uploads/202211/11/221111105115213.png','http://localhost:91/jingmizhuzaochanpin/116.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105115213.png\",\"alt\":\"9-1\"}}','');
INSERT INTO `hc_product` VALUES ('117','68','1','admin','管理员','61','','1668135083','1668482690','10','10','55','<p>61</p>','网络','/uploads/202211/11/221111105131619.png','http://localhost:91/jingmizhuzaochanpin/117.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('118','68','1','admin','管理员','62','','1668135096','1668482698','11','11','26','<p>62</p>','网络','/uploads/202211/11/221111105142412.png','http://localhost:91/jingmizhuzaochanpin/118.html','','1','1','10','','','1','','','');
INSERT INTO `hc_product` VALUES ('119','68','1','admin','管理员','63','','1668135107','1668482707','12','12','38','<p>63</p>','网络','/uploads/202211/11/221111105153578.png','http://localhost:91/jingmizhuzaochanpin/119.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105153578.png\",\"alt\":\"12-1\"}}','');
INSERT INTO `hc_product` VALUES ('120','68','1','admin','管理员','64','','1668135121','1668482715','13','13','82','<p>64</p>','网络','/uploads/202211/11/221111105208790.png','http://localhost:91/jingmizhuzaochanpin/120.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105208790.png\",\"alt\":\"13-1\"}}','');
INSERT INTO `hc_product` VALUES ('121','69','1','admin','管理员','65','','1668135152','1668482760','1','1','82','<p>65</p>','网络','/uploads/202211/11/221111105241714.png','http://localhost:91/qita/121.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105241714.png\",\"alt\":\"1-1\"}}','');
INSERT INTO `hc_product` VALUES ('122','69','1','admin','管理员','66','','1668135188','1668482767','2','2','83','<p>66</p>','网络','/uploads/202211/11/221111105315755.png','http://localhost:91/qita/122.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105315755.png\",\"alt\":\"2-1\"}}','');
INSERT INTO `hc_product` VALUES ('123','69','1','admin','管理员','67','','1668135204','1668482775','3','3','98','<p>67</p>','网络','/uploads/202211/11/221111105331815.png','http://localhost:91/qita/123.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105331815.png\",\"alt\":\"3-1\"}}','');
INSERT INTO `hc_product` VALUES ('124','69','1','admin','管理员','68','','1668135218','1668482783','4','4','34','<p>68</p>','网络','/uploads/202211/11/221111105345189.png','http://localhost:91/qita/124.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105345189.png\",\"alt\":\"4-1\"}}','');
INSERT INTO `hc_product` VALUES ('125','69','1','admin','管理员','69','','1668135233','1668482791','5','5','54','<p>69</p>','网络','/uploads/202211/11/221111105359631.png','http://localhost:91/qita/125.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105359631.png\",\"alt\":\"5-1\"}}','');
INSERT INTO `hc_product` VALUES ('126','69','1','admin','管理员','70','','1668135247','1668482799','6','6','55','<p>70</p>','网络','/uploads/202211/11/221111105415739.png','http://localhost:91/qita/126.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105415739.png\",\"alt\":\"6-1\"}}','');
INSERT INTO `hc_product` VALUES ('127','69','1','admin','管理员','71','','1668135264','1668482808','7','7','51','<p>71</p>','网络','/uploads/202211/11/221111105430636.png','http://localhost:91/qita/127.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111105430636.png\",\"alt\":\"7-1\"}}','');
INSERT INTO `hc_product` VALUES ('128','45','1','admin','管理员','72','','1668133746','1668482877','7','13','98','<p>72</p>','网络','/uploads/202211/11/221111102913591.png','http://localhost:91/slanilongdayinchanpin/128.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111102913591.png\",\"alt\":\"12-1\"}}','');
INSERT INTO `hc_product` VALUES ('129','45','1','admin','管理员','73','','1668133806','1668482887','15','15','34','<p>73</p>','网络','/uploads/202211/11/221111103012434.png','http://localhost:91/slanilongdayinchanpin/129.html','','1','1','10','','','1','','{\"0\":{\"url\":\"\\/uploads\\/202211\\/11\\/221111103012434.png\",\"alt\":\"15-1\"}}','');

-- -----------------------------
-- Table structure for `hc_tag`
-- -----------------------------
DROP TABLE IF EXISTS `hc_tag`;
CREATE TABLE `hc_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(30) NOT NULL DEFAULT '',
  `total` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seo_title` varchar(100) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keywords` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `seo_description` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `siteid_catid` (`siteid`,`catid`),
  KEY `siteid_tag` (`siteid`,`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_tag_content`
-- -----------------------------
DROP TABLE IF EXISTS `hc_tag_content`;
CREATE TABLE `hc_tag_content` (
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `aid` int(10) unsigned NOT NULL DEFAULT '0',
  `tagid` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `tag_index` (`modelid`,`aid`),
  KEY `tagid_index` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_urlrule`
-- -----------------------------
DROP TABLE IF EXISTS `hc_urlrule`;
CREATE TABLE `hc_urlrule` (
  `urlruleid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '规则名称',
  `urlrule` varchar(100) NOT NULL DEFAULT '' COMMENT 'URL规则',
  `route` varchar(100) NOT NULL DEFAULT '' COMMENT '指向的路由',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '50' COMMENT '优先级排序',
  PRIMARY KEY (`urlruleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_auto_reply`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_auto_reply`;
CREATE TABLE `hc_wechat_auto_reply` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1关键字回复2自动回复3关注回复',
  `keyword` varchar(64) NOT NULL DEFAULT '' COMMENT '关键字回复的关键字',
  `keyword_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1完全匹配0模糊匹配',
  `relation_id` varchar(15) NOT NULL DEFAULT '' COMMENT '图文回复的关联内容ID',
  `content` text NOT NULL COMMENT '文本回复的内容',
  PRIMARY KEY (`id`),
  KEY `type_index` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_group`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_group`;
CREATE TABLE `hc_wechat_group` (
  `id` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_mass`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_mass`;
CREATE TABLE `hc_wechat_mass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_type` char(6) NOT NULL DEFAULT '' COMMENT '消息类型',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0通过openid群发1通过分组群发2全部',
  `media_id` varchar(200) NOT NULL DEFAULT '',
  `msg_id` varchar(10) NOT NULL DEFAULT '',
  `msg_data_id` varchar(10) NOT NULL DEFAULT '' COMMENT '图文消息的数据ID',
  `receive` varchar(255) NOT NULL DEFAULT '' COMMENT '按组群发为组id，否则为openid列表',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1任务提交成功2群发已结束',
  `masstime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_media`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_media`;
CREATE TABLE `hc_wechat_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `originname` varchar(50) NOT NULL DEFAULT '',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filepath` char(200) NOT NULL DEFAULT '',
  `type` char(6) NOT NULL DEFAULT '',
  `media_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0临时素材,1永久素材',
  `media_id` varchar(200) NOT NULL DEFAULT '',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(200) NOT NULL DEFAULT '' COMMENT '永久素材的图片url/图文素材标题',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_menu`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_menu`;
CREATE TABLE `hc_wechat_menu` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(6) NOT NULL DEFAULT '0',
  `name` varchar(48) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1关键字2跳转',
  `keyword` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `event` varchar(64) NOT NULL DEFAULT '',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_message`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_message`;
CREATE TABLE `hc_wechat_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `openid` char(100) NOT NULL DEFAULT '',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统回复',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `msgtype` varchar(32) NOT NULL DEFAULT '' COMMENT '消息类型',
  `isread` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1已读0未读',
  `content` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `openid` (`openid`),
  KEY `issystem` (`issystem`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_scan`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_scan`;
CREATE TABLE `hc_wechat_scan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scan` varchar(65) NOT NULL DEFAULT '' COMMENT '场景',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0永久,1临时',
  `expire_time` char(7) NOT NULL DEFAULT '0' COMMENT '二维码有效时间',
  `ticket` varchar(150) NOT NULL DEFAULT '',
  `remarks` varchar(255) NOT NULL DEFAULT '' COMMENT '场景备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_user`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_user`;
CREATE TABLE `hc_wechat_user` (
  `wechatid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `openid` char(100) NOT NULL DEFAULT '',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `subscribe` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1关注0取消',
  `nickname` varchar(50) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `city` char(50) NOT NULL DEFAULT '',
  `province` char(50) NOT NULL DEFAULT '',
  `country` char(50) NOT NULL DEFAULT '',
  `headimgurl` char(255) NOT NULL DEFAULT '',
  `subscribe_time` int(10) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(50) NOT NULL DEFAULT '',
  `scan` varchar(30) NOT NULL DEFAULT '' COMMENT '来源场景',
  PRIMARY KEY (`wechatid`),
  UNIQUE KEY `openid` (`openid`),
  KEY `groupid` (`groupid`),
  KEY `subscribe` (`subscribe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- YzmCMS MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : hccms
-- 
-- Part : #1
-- Date : 2022-11-04 10:20:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `hc_admin`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin`;
CREATE TABLE `hc_admin` (
  `adminid` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `adminname` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `rolename` varchar(30) NOT NULL DEFAULT '',
  `realname` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(30) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `loginip` varchar(15) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `errnum` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addpeople` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin`
-- -----------------------------
INSERT INTO `hc_admin` VALUES ('1','admin','ffe317ecad2405070e6f5ffefb3a38a5','1','超级管理员','','','','1667528430','127.0.0.1','1665387014','','创始人');

-- -----------------------------
-- Table structure for `hc_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_log`;
CREATE TABLE `hc_admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(15) NOT NULL DEFAULT '',
  `action` varchar(20) NOT NULL DEFAULT '',
  `querystring` varchar(255) NOT NULL DEFAULT '',
  `adminid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adminname` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `logtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `logtime` (`logtime`),
  KEY `adminid` (`adminid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_admin_login_log`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_login_log`;
CREATE TABLE `hc_admin_login_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adminname` varchar(30) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `loginip` varchar(15) NOT NULL DEFAULT '',
  `address` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `loginresult` tinyint(1) NOT NULL DEFAULT '0' COMMENT '登录结果1为登录成功0为登录失败',
  `cause` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `admin_index` (`adminname`,`loginresult`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin_login_log`
-- -----------------------------
INSERT INTO `hc_admin_login_log` VALUES ('1','admin','1665387037','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('2','admin','1665451075','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('3','admin','1665711596','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('4','admin','1665814065','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('5','admin','1665814617','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('6','admin','1665968920','127.0.0.1','','a11523518','','密码错误！');
INSERT INTO `hc_admin_login_log` VALUES ('7','admin','1665968932','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('8','admin','1665973667','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('9','admin','1666079104','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('10','admin','1666141626','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('11','admin','1667394060','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('12','admin','1667407867','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('13','admin','1667441848','127.0.0.1','','','1','登录成功！');
INSERT INTO `hc_admin_login_log` VALUES ('14','admin','1667528430','127.0.0.1','','','1','登录成功！');

-- -----------------------------
-- Table structure for `hc_admin_role`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_role`;
CREATE TABLE `hc_admin_role` (
  `roleid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `rolename` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleid`),
  KEY `disabled` (`disabled`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_admin_role`
-- -----------------------------
INSERT INTO `hc_admin_role` VALUES ('1','超级管理员','超级管理员','1','');
INSERT INTO `hc_admin_role` VALUES ('2','总编','总编','1','');
INSERT INTO `hc_admin_role` VALUES ('3','发布人员','发布人员','1','');

-- -----------------------------
-- Table structure for `hc_admin_role_priv`
-- -----------------------------
DROP TABLE IF EXISTS `hc_admin_role_priv`;
CREATE TABLE `hc_admin_role_priv` (
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL DEFAULT '',
  `c` char(20) NOT NULL DEFAULT '',
  `a` char(30) NOT NULL DEFAULT '',
  `data` char(100) NOT NULL DEFAULT '',
  KEY `roleid` (`roleid`,`m`,`c`,`a`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_adver`
-- -----------------------------
DROP TABLE IF EXISTS `hc_adver`;
CREATE TABLE `hc_adver` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1文字2代码3图片',
  `title` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `text` varchar(200) NOT NULL DEFAULT '',
  `img` varchar(200) NOT NULL DEFAULT '',
  `code` text NOT NULL,
  `describe` varchar(250) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_all_content`
-- -----------------------------
DROP TABLE IF EXISTS `hc_all_content`;
CREATE TABLE `hc_all_content` (
  `allid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `modelid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(30) NOT NULL DEFAULT '',
  `title` varchar(150) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`allid`),
  KEY `userid_index` (`userid`,`issystem`,`status`),
  KEY `modelid_index` (`modelid`,`id`),
  KEY `status` (`siteid`,`status`),
  KEY `issystem` (`siteid`,`issystem`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_all_content`
-- -----------------------------
INSERT INTO `hc_all_content` VALUES ('4','','2','8','2','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/hangkonghang/2.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('5','','2','9','3','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/jungong/3.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('3','','2','7','1','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/qichelingbujian/1.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('6','','2','9','4','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/jungong/4.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('7','','2','7','5','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/qichelingbujian/5.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('8','','2','28','6','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/bobimocahan/6.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('9','','2','27','7','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/jigoufuza/7.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('10','','2','27','8','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/jigoufuza/8.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('11','','2','26','9','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/yiliao/9.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('12','','2','26','10','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/yiliao/10.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('13','','2','8','11','1','admin','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','1665392990','1665473827','http://localhost:91/hangkonghang/11.html','/uploads/202210/11/221011014303722.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('14','','2','11','12','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/dayinshebei/12.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('15','','2','11','13','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/dayinshebei/13.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('16','','2','30','14','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/yangjiaozongchengbujian/14.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('17','','2','30','15','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/yangjiaozongchengbujian/15.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('18','','2','29','16','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/zhuanxiangzongchengbujian/16.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('19','','2','29','17','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/zhuanxiangzongchengbujian/17.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('20','','2','29','18','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/zhuanxiangzongchengbujian/18.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('21','','2','29','19','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/zhuanxiangzongchengbujian/19.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('22','','2','29','20','1','admin','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','1665392990','1665473827','http://localhost:91/zhuanxiangzongchengbujian/20.html','/uploads/202210/11/221011014303722.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('24','','2','24','21','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/chunjixiejiagong/21.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('25','','2','24','22','1','admin','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','1665392990','1665473827','http://localhost:91/chunjixiejiagong/22.html','/uploads/202210/11/221011014303722.jpg','1','1');
INSERT INTO `hc_all_content` VALUES ('26','','2','25','23','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/jingmi3ddayin/23.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('27','','2','25','24','1','admin','3D打印样式测试','1665392990','1665451250','http://localhost:91/jingmi3ddayin/24.html','/uploads/202210/11/221011092037999.png','1','1');
INSERT INTO `hc_all_content` VALUES ('28','','2','11','25','1','admin','SLA光固化3D打印机就','1665972444','1666079223','http://localhost:91/dayinshebei/25.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('29','','1','52','4','1','admin','2008年8月','1667460535','1667461014','http://localhost:91/Companyhonor/4.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('30','','1','52','5','1','admin','2008年11月','1667460564','1667461005','http://localhost:91/Companyhonor/5.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('31','','1','52','6','1','admin','2009年12月','1667460578','1667460986','http://localhost:91/Companyhonor/6.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('32','','1','52','7','1','admin','2009年1月','1667460593','1667460962','http://localhost:91/Companyhonor/7.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('33','','1','52','8','1','admin','2009年5月','1667460609','1667460948','http://localhost:91/Companyhonor/8.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('34','','1','52','9','1','admin','2009年7月','1667460625','1667460912','http://localhost:91/Companyhonor/9.html','','1','1');
INSERT INTO `hc_all_content` VALUES ('35','','1','53','10','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/10.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('36','','1','53','11','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/11.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('37','','1','53','12','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/12.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('38','','1','53','13','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/13.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('39','','1','53','14','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/14.html','/uploads/202211/03/221103055935990.jpeg','1','1');
INSERT INTO `hc_all_content` VALUES ('40','','1','53','15','1','admin','江苏3D能打印什么？','1667469451','1667469578','http://localhost:91/xinwenzhongxin/15.html','/uploads/202211/03/221103055935990.jpeg','1','1');

-- -----------------------------
-- Table structure for `hc_article`
-- -----------------------------
DROP TABLE IF EXISTS `hc_article`;
CREATE TABLE `hc_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(180) NOT NULL DEFAULT '',
  `color` char(9) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `copyfrom` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `flag` varchar(12) NOT NULL DEFAULT '' COMMENT '1置顶,2头条,3特荐,4推荐,5热点,6幻灯,7跳转',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groupids_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '收费类型',
  `is_push` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否百度推送',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`),
  KEY `catid` (`catid`,`status`),
  KEY `userid` (`userid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_article`
-- -----------------------------
INSERT INTO `hc_article` VALUES ('4','52','1','admin','管理员','2008年8月','','1667460535','1667461014','2008年,8月','卢秉恒院士被授予&quot;苏州工业园区科技领军人才&quot;称号','26','<p>卢秉恒院士被授予&quot;苏州工业园区科技领军人才&quot;称号</p>','网络','','http://localhost:91/Companyhonor/4.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('5','52','1','admin','管理员','2008年11月','','1667460564','1667461005','2008年,11月','卢秉恒院士被授予&quot;江苏省高层次创新创业&quot;','66','<p>卢秉恒院士被授予&quot;江苏省高层次创新创业&quot;</p>','网络','','http://localhost:91/Companyhonor/5.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('6','52','1','admin','管理员','2009年12月','','1667460578','1667460986','2009年,12月','卢秉恒院士被授予&quot;姑苏创新创业领军人才称号&quot;','13','<p>卢秉恒院士被授予&quot;姑苏创新创业领军人才称号&quot;</p>','网络','','http://localhost:91/Companyhonor/6.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('7','52','1','admin','管理员','2009年1月','','1667460593','1667460962','2009年,1月','获批成立数控系统性能评测中心；创建苏州工业园区快速制造公共技术服务f平台；&lt;br /&gt; 苏州工业园区企业博士后科研工作站秉创科技分站挂牌成','27','<p>获批成立数控系统性能评测中心；创建苏州工业园区快速制造公共技术服务f平台；<br/> 苏州工业园区企业博士后科研工作站秉创科技分站挂牌成</p>','网络','','http://localhost:91/Companyhonor/7.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('8','52','1','admin','管理员','2009年5月','','1667460609','1667460948','2009年,5月','加入苏州市汽车工程学会任名誉理事长、副理事单位。 &lt;br /&gt; 加入苏州市工业设计协作联盟任副秘书长单位， &lt;br /&gt; 与奇瑞汽车股份有限公司签订战略合','88','<p>加入苏州市汽车工程学会任名誉理事长、副理事单位。 <br/> 加入苏州市工业设计协作联盟任副秘书长单位， <br/> 与奇瑞汽车股份有限公司签订战略合</p>','网络','','http://localhost:91/Companyhonor/8.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('10','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','37','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/10.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('9','52','1','admin','管理员','2009年7月','','1667460625','1667460912','2009年,7月','被评为苏州高新技术企业。 &lt;br /&gt;获批成立快速成型工程技术研究中心；获批成立江苏省企业院士工作站。','35','<p>被评为苏州高新技术企业。<br style=\"white-space: normal;\"/>获批成立快速成型工程技术研究中心；获批成立江苏省企业院士工作站。</p>','网络','','http://localhost:91/Companyhonor/9.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('11','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/11.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('12','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/12.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('13','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/13.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('14','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/14.html','','1','1','10','','','1','');
INSERT INTO `hc_article` VALUES ('15','53','1','admin','管理员','江苏3D能打印什么？','','1667469451','1667469578','江苏,3D,打印,什么','即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定    即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需...','36','<p>即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;即使3d打印非常的神奇，但它不可能制造出任何物体，比如一些内 部复杂需要多种材料，而且有一定&nbsp; &nbsp;&nbsp;</p>','网络','/uploads/202211/03/221103055935990.jpeg','http://localhost:91/xinwenzhongxin/15.html','','1','1','10','','','1','');

-- -----------------------------
-- Table structure for `hc_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `hc_attachment`;
CREATE TABLE `hc_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `module` char(15) NOT NULL DEFAULT '',
  `contentid` varchar(20) NOT NULL DEFAULT '',
  `originname` varchar(50) NOT NULL DEFAULT '',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filepath` char(200) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` char(10) NOT NULL DEFAULT '',
  `isimage` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `downloads` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `uploadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `uploadip` char(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `userid_index` (`userid`),
  KEY `contentid` (`contentid`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_attachment`
-- -----------------------------
INSERT INTO `hc_attachment` VALUES ('1','','admin','','page-title-1.jpg','221010044521715.jpg','/uploads/202210/10/','96473','jpg','1','','1','admin','1665391521','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('2','','admin','','1651549213.jpg','221011092029917.jpg','/uploads/202210/11/','62380','jpg','1','','1','admin','1665451229','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('3','','admin','','t01d74ddf8b7c58360a.jpg','221011092036595.jpg','/uploads/202210/11/','22251','jpg','1','','1','admin','1665451236','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('4','','admin','','微信图片_20221008174230.jpg','221011092036254.jpg','/uploads/202210/11/','115677','jpg','1','','1','admin','1665451236','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('5','','admin','','1536643408740_2.jpg','221011092037177.jpg','/uploads/202210/11/','172603','jpg','1','','1','admin','1665451237','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('6','','admin','','图片4.png','221011092037999.png','/uploads/202210/11/','38718','png','1','','1','admin','1665451237','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('7','','admin','','t01d74ddf8b7c58360a.jpg','221011014303722.jpg','/uploads/202210/11/','22251','jpg','1','','1','admin','1665466983','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('45','','link','','ch-8.png','221103044206470.png','/uploads/202211/03/','20775','png','1','','1','admin','1667464926','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('46','','link','','ch-10.png','221103044237435.png','/uploads/202211/03/','19682','png','1','','1','admin','1667464957','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('47','','link','','ch-10.png','221103044315534.png','/uploads/202211/03/','19682','png','1','','1','admin','1667464995','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('48','','link','','ch-11.png','221103044332828.png','/uploads/202211/03/','14190','png','1','','1','admin','1667465012','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('49','','link','','ch-12.png','221103044357147.png','/uploads/202211/03/','8858','png','1','','1','admin','1667465037','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('50','','link','','ch-13.png','221103044428983.png','/uploads/202211/03/','11571','png','1','','1','admin','1667465068','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('51','','link','','ch-14.png','221103044443543.png','/uploads/202211/03/','18371','png','1','','1','admin','1667465083','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('52','','link','','ch-15.png','221103044458850.png','/uploads/202211/03/','13565','png','1','','1','admin','1667465098','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('53','','link','','ch-16.png','221103044529746.png','/uploads/202211/03/','15818','png','1','','1','admin','1667465129','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('54','','link','','ch-17.png','221103044554341.png','/uploads/202211/03/','10916','png','1','','1','admin','1667465154','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('55','','link','','ch-18.png','221103044611784.png','/uploads/202211/03/','13721','png','1','','1','admin','1667465171','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('56','','link','','ch-19.png','221103044628360.png','/uploads/202211/03/','13275','png','1','','1','admin','1667465188','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('42','','link','','ch-5.png','221103044055115.png','/uploads/202211/03/','19480','png','1','','1','admin','1667464855','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('43','','link','','ch-6.png','221103044114462.png','/uploads/202211/03/','16405','png','1','','1','admin','1667464874','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('44','','link','','ch-7.png','221103044154742.png','/uploads/202211/03/','23952','png','1','','1','admin','1667464914','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('40','','link','','ch-3.png','221103043855595.png','/uploads/202211/03/','17501','png','1','','1','admin','1667464735','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('41','','link','','ch-4.png','221103044001206.png','/uploads/202211/03/','17524','png','1','','1','admin','1667464801','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('39','','link','','ch-2.png','221103043831124.png','/uploads/202211/03/','18609','png','1','','1','admin','1667464711','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('38','','link','','ch-1.png','221103043758147.png','/uploads/202211/03/','20744','png','1','','1','admin','1667464678','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('30','','banner','','97177a98-8c84-40eb-a644-82afdaa97873.png','221103101925452.png','/uploads/202211/03/','1593938','png','1','','1','admin','1667441965','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('31','','banner','','banner2.jpg','221103102024937.jpg','/uploads/202211/03/','1275891','jpg','1','','1','admin','1667442024','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('32','','banner','','banner3.jpg','221103102035448.jpg','/uploads/202211/03/','774204','jpg','1','','1','admin','1667442035','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('33','','banner','','gsjj.png','221103105331395.png','/uploads/202211/03/','658735','png','1','','1','admin','1667444011','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('34','','banner','','gsjj2.jpg','221103105400866.jpg','/uploads/202211/03/','348426','jpg','1','','1','admin','1667444039','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('35','','admin','','荣誉证书-英文.png','221103035857827.png','/uploads/202211/03/','92528','png','1','','1','admin','1667462337','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('36','','admin','','荣誉证书-中文.png','221103035913952.png','/uploads/202211/03/','81580','png','1','','1','admin','1667462353','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('37','','admin','','荣誉证书-英文.png','221103035939248.png','/uploads/202211/03/','92528','png','1','','1','admin','1667462379','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('57','','link','','ch-20.png','221103044644371.png','/uploads/202211/03/','21343','png','1','','1','admin','1667465204','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('58','','admin','','组织框架.png','221103051826611.png','/uploads/202211/03/','42618','png','1','','1','admin','1667467106','127.0.0.1');
INSERT INTO `hc_attachment` VALUES ('59','','admin','','6c4744cc863d48bba41750991f6022f3.jpeg','221103055935990.jpeg','/uploads/202211/03/','111141','jpeg','1','','1','admin','1667469575','127.0.0.1');

-- -----------------------------
-- Table structure for `hc_banner`
-- -----------------------------
DROP TABLE IF EXISTS `hc_banner`;
CREATE TABLE `hc_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `image` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1显示0隐藏',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `typeid` (`typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_banner`
-- -----------------------------
INSERT INTO `hc_banner` VALUES ('1','最专业的3d打印机,海创三维科技(苏州)有限公司','/uploads/202211/03/221103101925452.png','http://www.baodu.com','我们有最新进最优秀的服务技术和团队','1667394394','1','1','1');
INSERT INTO `hc_banner` VALUES ('2','工业级高精度,3D打印机','/uploads/202211/03/221103102024937.jpg','http://www.baidu.com','','1667394539','2','1','1');
INSERT INTO `hc_banner` VALUES ('3','更智慧的3D打印综合服务商','/uploads/202211/03/221103102035448.jpg','http://www.baidu.com','','1667394595','3','1','1');
INSERT INTO `hc_banner` VALUES ('4','公司简介','/uploads/202211/03/221103105331395.png','http://www.baidu.com','','1667444016','1','2','1');
INSERT INTO `hc_banner` VALUES ('5','首页公司简介轮播','/uploads/202211/03/221103105400866.jpg','http://www.baidu.com','','1667444052','2','2','1');

-- -----------------------------
-- Table structure for `hc_banner_type`
-- -----------------------------
DROP TABLE IF EXISTS `hc_banner_type`;
CREATE TABLE `hc_banner_type` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_banner_type`
-- -----------------------------
INSERT INTO `hc_banner_type` VALUES ('1','首页轮播');
INSERT INTO `hc_banner_type` VALUES ('2','首页公司简介轮播');

-- -----------------------------
-- Table structure for `hc_category`
-- -----------------------------
DROP TABLE IF EXISTS `hc_category`;
CREATE TABLE `hc_category` (
  `catid` smallint(5) NOT NULL AUTO_INCREMENT COMMENT '栏目ID',
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `catname` varchar(50) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `arrparentid` varchar(255) NOT NULL DEFAULT '' COMMENT '父级路径',
  `arrchildid` mediumtext NOT NULL COMMENT '子栏目id集合',
  `catdir` varchar(30) NOT NULL DEFAULT '' COMMENT '栏目目录',
  `catimg` varchar(150) NOT NULL DEFAULT '' COMMENT '栏目图片',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '栏目类型:0普通栏目1单页2外部链接',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目排序',
  `target` char(10) NOT NULL DEFAULT '' COMMENT '打开方式',
  `member_publish` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否会员投稿',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '在导航显示',
  `pclink` varchar(100) NOT NULL DEFAULT '' COMMENT '电脑版地址',
  `domain` varchar(100) NOT NULL DEFAULT '' COMMENT '绑定域名',
  `entitle` varchar(80) NOT NULL DEFAULT '' COMMENT '英文标题',
  `subtitle` varchar(60) NOT NULL DEFAULT '' COMMENT '副标题',
  `mobname` varchar(30) NOT NULL DEFAULT '' COMMENT '手机版名称',
  `category_template` varchar(30) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `list_template` varchar(30) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `show_template` varchar(30) NOT NULL DEFAULT '' COMMENT '内容页模板',
  `seo_title` varchar(100) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keywords` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `seo_description` varchar(250) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  PRIMARY KEY (`catid`),
  KEY `siteid` (`siteid`),
  KEY `modelid` (`modelid`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_category`
-- -----------------------------
INSERT INTO `hc_category` VALUES ('6','','产品中心','2','','','6,7,8,9,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40','chanpinzhongxin','/uploads/202210/10/221010044521715.jpg','','3','_self','','1','http://localhost:91/chanpinzhongxin/','','','','产品中心','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('7','','汽车零部件','2','6','0,6','7,29,30,31,32,33,34','qichelingbujian','/uploads/202210/10/221010044521715.jpg','','','_self','','1','http://localhost:91/qichelingbujian/','','','','汽车零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('8','','航空航天精密零部件','2','6','0,6','8,35,36,37','hangkonghang','/uploads/202210/10/221010044521715.jpg','','','_self','','1','http://localhost:91/hangkonghang/','','','','航空航天精密零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('9','','军工产品精密零部件','2','6','0,6','9,38,39,40','jungong','/uploads/202210/10/221010044521715.jpg','','','_self','','1','http://localhost:91/jungong/','','','','军工产品精密零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('10','','设备介绍','2','','','10,11,12,13,47','shebei','/uploads/202210/10/221010044521715.jpg','','5','_self','','1','http://localhost:91/shebei/','','','','设备介绍','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('11','','打印设备','2','10','0,10','11','dayinshebei','/uploads/202210/10/221010044521715.jpg','','','_self','','1','http://localhost:91/dayinshebei/','','','','打印设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('12','','机加工设备','2','10','0,10','12','jijiagongshebei','/uploads/202210/10/221010044521715.jpg','','','_self','','1','http://localhost:91/jijiagongshebei/','','','','机加工设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('13','','检测设备','2','10','0,10','13','jianceshebei','/uploads/202210/10/221010044521715.jpg','','','_self','','1','http://localhost:91/jianceshebei/','','','','检测设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('52','','公司荣誉','1','','','52','Companyhonor','','','','_self','','','http://localhost:91/Companyhonor/','','Company honor','','公司荣誉','category_article','list_article','show_article','','','');
INSERT INTO `hc_category` VALUES ('53','','新闻中心','1','','','53','xinwenzhongxin','','','','_self','','','http://localhost:91/xinwenzhongxin/','','Company news','','新闻中心','category_article','list_article','show_article','','','');
INSERT INTO `hc_category` VALUES ('23','','生产工艺方法','2','','','23,24,25','shengchangongyifangfa','','','','_self','','1','http://localhost:91/shengchangongyifangfa/','','','','生产工艺方法','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('24','','纯机械加工','2','23','0,23','24','chunjixiejiagong','','','','_self','','1','http://localhost:91/chunjixiejiagong/','','','','纯机械加工','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('25','','精密3D打印','2','23','0,23','25','jingmi3ddayin','','','','_self','','1','http://localhost:91/jingmi3ddayin/','','','','精密3D打印','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('26','','医疗产品零部件','2','6','0,6','26','yiliao','','','','_self','','1','http://localhost:91/yiliao/','','','','医疗产品零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('27','','机构复杂零件','2','6','0,6','27','jigoufuza','','','','_self','','1','http://localhost:91/jigoufuza/','','','','机构复杂零件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('28','','薄壁、摩擦焊接零部件','2','6','0,6','28','bobimocahan','','','','_self','','1','http://localhost:91/bobimocahan/','','','','薄壁、摩擦焊接零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('29','','转向总成部件','2','7','0,6,7','29','zhuanxiangzongchengbujian','','','','_self','','1','http://localhost:91/zhuanxiangzongchengbujian/','','','','转向总成部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('30','','羊角总成部件','2','7','0,6,7','30','yangjiaozongchengbujian','','','','_self','','1','http://localhost:91/yangjiaozongchengbujian/','','','','羊角总成部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('31','','发动机部件','2','7','0,6,7','31','fadongjibujian','','','','_self','','1','http://localhost:91/fadongjibujian/','','','','发动机部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('32','','变速箱部件','2','7','0,6,7','32','biansuxiangbujian','','','','_self','','1','http://localhost:91/biansuxiangbujian/','','','','变速箱部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('33','','底盘零部件','2','7','0,6,7','33','dipanlingbujian','','','','_self','','1','http://localhost:91/dipanlingbujian/','','','','底盘零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('34','','汽车轮毂零部件','2','7','0,6,7','34','qichelungulingbujian','','','','_self','','1','http://localhost:91/qichelungulingbujian/','','','','汽车轮毂零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('35','','薄壁产品零部件','2','8','0,6,8','35','bobichanpinlingbujian','','','','_self','','1','http://localhost:91/bobichanpinlingbujian/','','','','薄壁产品零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('36','','水冷产品零部件','2','8','0,6,8','36','shuilingchanpinlingbujian','','','','_self','','1','http://localhost:91/shuilingchanpinlingbujian/','','','','水冷产品零部件','category_product_sub','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('37','','通讯产品零部件','2','8','0,6,8','37','tongxunchanpinlingbujian','','','','_self','','1','http://localhost:91/tongxunchanpinlingbujian/','','','','通讯产品零部件','category_product_sub','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('38','','薄壁产品零部件','2','9','0,6,9','38','junbobichanpinlingbujian','','','','_self','','1','http://localhost:91/junbobichanpinlingbujian/','','','','薄壁产品零部件','category_product_sub','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('39','','水冷产品零部件','2','9','0,6,9','39','shuilingjun','','','','_self','','1','http://localhost:91/shuilingjun/','','','','水冷产品零部件','category_product_sub','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('40','','通讯产品零部件','2','9','0,6,9','40','tongxunjun','','','','_self','','1','http://localhost:91/tongxunjun/','','','','通讯产品零部件','category_product_sub','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('41','','产品展示','2','','','41,42,43,44,45,46','chanpinzhanshi','','','4','_self','','1','http://localhost:91/chanpinzhanshi/','','','','产品展示','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('42','','汽车零部件','2','41','0,41','42','qichelingbujianzhan','','','','_self','','1','http://localhost:91/qichelingbujianzhan/','','','','汽车零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('43','','航空航天精密零部件','2','41','0,41','43','hangkonghangzhan','','','','_self','','1','http://localhost:91/hangkonghangzhan/','','','','航空航天精密零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('44','','军工产品精密零部件','2','41','0,41','44','jungongzhan','','','','_self','','1','http://localhost:91/jungongzhan/','','','','军工产品精密零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('45','','医疗产品零部件','2','41','0,41','45','yiliaozhan','','','','_self','','1','http://localhost:91/yiliaozhan/','','','','医疗产品零部件','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('46','','精密复杂零部件的工艺研发和制造','2','41','0,41','46','jingmizhan','','','','_self','','1','http://localhost:91/jingmizhan/','','','','精密复杂零部件的工艺研发和制造','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('47','','其它设备','2','10','0,10','47','qitashebei','','','','_self','','1','http://localhost:91/qitashebei/','','','','其它设备','category_product','list_product','show_product','','','');
INSERT INTO `hc_category` VALUES ('48','','服务专区','1','','','48','service','','','6','_self','','1','http://localhost:91/service/','','','','服务专区','category_article_service','list_article_service','show_article','','','');
INSERT INTO `hc_category` VALUES ('51','','联系我们','','','','51','lianxiwomen','','1','7','_self','','1','http://localhost:91/lianxiwomen/','','','','联系我们','category_page','','','','','');

-- -----------------------------
-- Table structure for `hc_collection_content`
-- -----------------------------
DROP TABLE IF EXISTS `hc_collection_content`;
CREATE TABLE `hc_collection_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:未采集,1:已采集,2:已导入',
  `url` char(255) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nodeid` (`nodeid`),
  KEY `status` (`status`),
  KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_collection_node`
-- -----------------------------
DROP TABLE IF EXISTS `hc_collection_node`;
CREATE TABLE `hc_collection_node` (
  `nodeid` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '采集节点ID',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '节点名称',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后采集时间',
  `sourcecharset` varchar(8) NOT NULL DEFAULT '' COMMENT '采集点字符集',
  `sourcetype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '网址类型:1序列网址,2单页',
  `urlpage` text NOT NULL COMMENT '采集地址',
  `pagesize_start` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '页码开始',
  `pagesize_end` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '页码结束',
  `par_num` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '每次增加数',
  `url_contain` char(100) NOT NULL DEFAULT '' COMMENT '网址中必须包含',
  `url_except` char(100) NOT NULL DEFAULT '' COMMENT '网址中不能包含',
  `url_start` char(100) NOT NULL DEFAULT '' COMMENT '网址开始',
  `url_end` char(100) NOT NULL DEFAULT '' COMMENT '网址结束',
  `title_rule` char(100) NOT NULL DEFAULT '' COMMENT '标题采集规则',
  `title_html_rule` text NOT NULL COMMENT '标题过滤规则',
  `time_rule` char(100) NOT NULL DEFAULT '' COMMENT '时间采集规则',
  `time_html_rule` text COMMENT '时间过滤规则',
  `content_rule` char(100) NOT NULL DEFAULT '' COMMENT '内容采集规则',
  `content_html_rule` text COMMENT '内容过滤规则',
  `down_attachment` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否下载图片',
  `watermark` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '图片加水印',
  `coll_order` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '导入顺序',
  PRIMARY KEY (`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_comment`
-- -----------------------------
DROP TABLE IF EXISTS `hc_comment`;
CREATE TABLE `hc_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commentid` char(30) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `userpic` varchar(100) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评论状态{0:未审核,1:通过审核}',
  `reply` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '是否为回复',
  `commonname` varchar(30) DEFAULT NULL,
  `commonphone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `userid` (`userid`),
  KEY `commentid` (`commentid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_comment_data`
-- -----------------------------
DROP TABLE IF EXISTS `hc_comment_data`;
CREATE TABLE `hc_comment_data` (
  `commentid` char(30) NOT NULL DEFAULT '',
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` char(255) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `total` int(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`commentid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_comment_data`
-- -----------------------------
INSERT INTO `hc_comment_data` VALUES ('2_8_11','','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','http://localhost:91/jijiayangpin/11.html','','8','2');

-- -----------------------------
-- Table structure for `hc_config`
-- -----------------------------
DROP TABLE IF EXISTS `hc_config`;
CREATE TABLE `hc_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(60) NOT NULL DEFAULT '' COMMENT '配置说明',
  `value` text NOT NULL COMMENT '配置值',
  `fieldtype` varchar(20) NOT NULL DEFAULT '' COMMENT '字段类型',
  `setting` text COMMENT '字段设置',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_config`
-- -----------------------------
INSERT INTO `hc_config` VALUES ('1','site_name','','站点名称','海创三维科技（苏州）有限公司','','','1');
INSERT INTO `hc_config` VALUES ('2','site_url','','站点根网址','http://localhost:91/','','','1');
INSERT INTO `hc_config` VALUES ('3','site_keyword','','站点关键字','3D,专业3d打印服务,3D打印部件,3D打印服务','','','1');
INSERT INTO `hc_config` VALUES ('4','site_description','','站点描述','海创三维科技,海创三维科技（苏州）有限公司,海创三维科技苏州有限公司,苏州海创三维科技有限公司','','','1');
INSERT INTO `hc_config` VALUES ('64','organization','99','组织架构','/uploads/202211/03/221103051826611.png','image','','1');
INSERT INTO `hc_config` VALUES ('5','site_copyright','','版权信息','Powered By YzmCMS内容管理系统 © 2014-2022 袁志蒙工作室','','','1');
INSERT INTO `hc_config` VALUES ('6','site_filing','','站点备案号','京ICP备666666号','','','1');
INSERT INTO `hc_config` VALUES ('7','site_code','','统计代码','','','','1');
INSERT INTO `hc_config` VALUES ('8','site_theme','','站点模板主题','company','','','1');
INSERT INTO `hc_config` VALUES ('9','site_logo','','站点logo','','','','1');
INSERT INTO `hc_config` VALUES ('10','url_mode','','前台URL模式','1','','','1');
INSERT INTO `hc_config` VALUES ('11','is_words','','是否开启前端留言功能','1','','','1');
INSERT INTO `hc_config` VALUES ('12','upload_maxsize','','允许上传附件大小','921600','','','1');
INSERT INTO `hc_config` VALUES ('13','upload_types','','允许上传附件类型','zip|rar|mp3|mp4','','','1');
INSERT INTO `hc_config` VALUES ('14','ishtml5','','选择上传附件插件类型','1','','','1');
INSERT INTO `hc_config` VALUES ('15','watermark_enable','','是否开启图片水印','','','','1');
INSERT INTO `hc_config` VALUES ('16','watermark_name','','水印图片名称','mark.png','','','1');
INSERT INTO `hc_config` VALUES ('17','watermark_position','','水印的位置','9','','','1');
INSERT INTO `hc_config` VALUES ('18','mail_server','1','SMTP服务器','ssl://smtp.qq.com','','','1');
INSERT INTO `hc_config` VALUES ('19','mail_port','1','SMTP服务器端口','25','','','1');
INSERT INTO `hc_config` VALUES ('20','mail_from','1','SMTP服务器的用户邮箱','','','','1');
INSERT INTO `hc_config` VALUES ('21','mail_auth','1','AUTH LOGIN验证','1','','','1');
INSERT INTO `hc_config` VALUES ('22','mail_user','1','SMTP服务器的用户帐号','','','','1');
INSERT INTO `hc_config` VALUES ('23','mail_pass','1','SMTP服务器的用户密码','','','','1');
INSERT INTO `hc_config` VALUES ('24','mail_inbox','1','收件邮箱地址','','','','1');
INSERT INTO `hc_config` VALUES ('25','admin_log','2','启用后台管理操作日志','','','','1');
INSERT INTO `hc_config` VALUES ('26','admin_prohibit_ip','2','禁止登录后台的IP','','','','1');
INSERT INTO `hc_config` VALUES ('27','prohibit_words','2','屏蔽词','她妈|它妈|他妈|你妈|去死|贱人','','','1');
INSERT INTO `hc_config` VALUES ('28','comment_check','2','是否开启评论审核','','','','1');
INSERT INTO `hc_config` VALUES ('29','comment_tourist','2','是否允许游客评论','1','','','1');
INSERT INTO `hc_config` VALUES ('30','is_link','2','允许用户申请友情链接','','','','1');
INSERT INTO `hc_config` VALUES ('31','member_register','3','是否开启会员注册','','','','1');
INSERT INTO `hc_config` VALUES ('32','member_email','3','新会员注册是否需要邮件验证','','','','1');
INSERT INTO `hc_config` VALUES ('33','member_check','3','新会员注册是否需要管理员审核','','','','1');
INSERT INTO `hc_config` VALUES ('34','member_point','3','新会员默认积分','','','','1');
INSERT INTO `hc_config` VALUES ('35','member_yzm','3','是否开启会员登录验证码','1','','','1');
INSERT INTO `hc_config` VALUES ('36','rmb_point_rate','3','1元人民币购买积分数量','10','','','1');
INSERT INTO `hc_config` VALUES ('37','login_point','3','每日登录奖励积分','1','','','1');
INSERT INTO `hc_config` VALUES ('38','comment_point','3','发布评论奖励积分','1','','','1');
INSERT INTO `hc_config` VALUES ('39','publish_point','3','投稿奖励积分','3','','','1');
INSERT INTO `hc_config` VALUES ('40','qq_app_id','3','QQ App ID','','','','1');
INSERT INTO `hc_config` VALUES ('41','qq_app_key','3','QQ App key','','','','1');
INSERT INTO `hc_config` VALUES ('42','weibo_key','4','微博登录App Key','','','','1');
INSERT INTO `hc_config` VALUES ('43','weibo_secret','4','微博登录App Secret','','','','1');
INSERT INTO `hc_config` VALUES ('44','wx_appid','4','微信开发者ID','','','','1');
INSERT INTO `hc_config` VALUES ('45','wx_secret','4','微信开发者密码','','','','1');
INSERT INTO `hc_config` VALUES ('46','wx_token','4','微信Token签名','','','','1');
INSERT INTO `hc_config` VALUES ('47','wx_encodingaeskey','4','微信EncodingAESKey','','','','1');
INSERT INTO `hc_config` VALUES ('48','wx_relation_model','4','微信关联模型','article','','','1');
INSERT INTO `hc_config` VALUES ('49','baidu_push_token','','百度推送token','','','','1');
INSERT INTO `hc_config` VALUES ('50','thumb_width','2','缩略图默认宽度','500','','','1');
INSERT INTO `hc_config` VALUES ('51','thumb_height','2','缩略图默认高度','300','','','1');
INSERT INTO `hc_config` VALUES ('52','site_seo_division','','站点标题分隔符','_','','','1');
INSERT INTO `hc_config` VALUES ('53','keyword_link','2','是否启用关键字替换','','','','1');
INSERT INTO `hc_config` VALUES ('54','keyword_replacenum','2','关键字替换次数','1','','','1');
INSERT INTO `hc_config` VALUES ('55','error_log_save','2','是否保存系统错误日志','1','','','1');
INSERT INTO `hc_config` VALUES ('56','comment_code','2','是否开启评论验证码','','','','1');
INSERT INTO `hc_config` VALUES ('57','site_wap_open','','是否启用手机站点','1','','','1');
INSERT INTO `hc_config` VALUES ('58','site_wap_theme','','WAP端模板风格','default','','','1');
INSERT INTO `hc_config` VALUES ('59','member_theme','3','会员中心模板风格','default','','','1');
INSERT INTO `hc_config` VALUES ('60','att_relation_content','1','是否开启内容附件关联','','','','1');
INSERT INTO `hc_config` VALUES ('61','site_seo_suffix','','站点SEO后缀','','','','1');
INSERT INTO `hc_config` VALUES ('62','is_words_chinese','3','前端留言须包含为中文内容','','','','1');
INSERT INTO `hc_config` VALUES ('65','comanydesc','99','公司简介','是一家依托于西安交通大学、国家增 材制造创新中心的专业技术服务公司；引进西安交大、国家创新中心 院士团队的核心技术。开发3D打印设备；先进制造的行业应用；为工厂，企业研发单位，研究所等提供技术服务，设备和应用的定制开发，新工艺新材料的应用；产品研发试制及小批量产品制造应用，为客户在新产品的开发提供更好的解决方案。应用领域包括：航空航天；辅助医疗器械；通讯电子；仪器仪表；汽车零部件； 汽车新车开发试制；教学模型；建筑设计；文化创意等。','textarea','','1');
INSERT INTO `hc_config` VALUES ('66','rongyuc','99','荣誉证书中文','/uploads/202211/03/221103035913952.png','image','','1');
INSERT INTO `hc_config` VALUES ('67','rongyue','99','荣誉证书英文','/uploads/202211/03/221103035939248.png','image','','1');

-- -----------------------------
-- Table structure for `hc_download`
-- -----------------------------
DROP TABLE IF EXISTS `hc_download`;
CREATE TABLE `hc_download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(180) NOT NULL DEFAULT '',
  `color` char(9) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `copyfrom` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `flag` varchar(12) NOT NULL DEFAULT '' COMMENT '1置顶,2头条,3特荐,4推荐,5热点,6幻灯,7跳转',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groupids_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '收费类型',
  `is_push` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否百度推送',
  `down_url` varchar(200) NOT NULL DEFAULT '' COMMENT '下载地址',
  `copytype` varchar(30) NOT NULL DEFAULT '' COMMENT '授权形式',
  `systems` varchar(100) NOT NULL DEFAULT '' COMMENT '平台',
  `language` varchar(30) NOT NULL DEFAULT '' COMMENT '语言',
  `version` varchar(30) NOT NULL DEFAULT '' COMMENT '版本',
  `filesize` varchar(10) NOT NULL DEFAULT '' COMMENT '文件大小',
  `classtype` varchar(30) NOT NULL DEFAULT '' COMMENT '软件类型',
  `stars` varchar(10) NOT NULL DEFAULT '' COMMENT '评分等级',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`),
  KEY `catid` (`catid`,`status`),
  KEY `userid` (`userid`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_favorite`
-- -----------------------------
DROP TABLE IF EXISTS `hc_favorite`;
CREATE TABLE `hc_favorite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` char(100) NOT NULL DEFAULT '',
  `url` char(100) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_guestbook`
-- -----------------------------
DROP TABLE IF EXISTS `hc_guestbook`;
CREATE TABLE `hc_guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '' COMMENT '主题',
  `booktime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '名字',
  `email` varchar(40) NOT NULL DEFAULT '' COMMENT '留言人电子邮箱',
  `phone` varchar(11) NOT NULL DEFAULT '' COMMENT '留言人电话',
  `qq` varchar(11) NOT NULL DEFAULT '' COMMENT '留言人qq',
  `address` varchar(100) NOT NULL DEFAULT '' COMMENT '留言人地址',
  `bookmsg` text NOT NULL COMMENT '内容',
  `ip` varchar(20) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `ischeck` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否审核',
  `isread` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否读过',
  `ispc` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1电脑,0手机',
  `replyid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复的id',
  PRIMARY KEY (`id`),
  KEY `index_booktime` (`booktime`),
  KEY `index_replyid` (`replyid`),
  KEY `index_ischeck` (`siteid`,`ischeck`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_guestbook`
-- -----------------------------
INSERT INTO `hc_guestbook` VALUES ('1','','111','1665973736','111','111@123.com','111','111','111','111','127.0.0.1','1','1','1','');
INSERT INTO `hc_guestbook` VALUES ('2','','dsa','1665973910','dsa','a11523518@126.com','das','dsa','das','dsadas','127.0.0.1','1','','1','');
INSERT INTO `hc_guestbook` VALUES ('3','','title','1665974718','admin','a11523518@126.com','','','','dsasd','127.0.0.1','1','1','1','');

-- -----------------------------
-- Table structure for `hc_keyword_link`
-- -----------------------------
DROP TABLE IF EXISTS `hc_keyword_link`;
CREATE TABLE `hc_keyword_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(36) NOT NULL DEFAULT '' COMMENT '关键字',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_link`
-- -----------------------------
DROP TABLE IF EXISTS `hc_link`;
CREATE TABLE `hc_link` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1首页,2列表页,3内容页',
  `linktype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:文字链接,1:logo链接',
  `name` varchar(50) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `msg` text NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(40) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未通过,1正常,2未审核',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_link`
-- -----------------------------
INSERT INTO `hc_link` VALUES ('36','','1','1','12','http://www.baidu13.com','/uploads/202211/03/221103044428983.png','','','','13','1','1667465070');
INSERT INTO `hc_link` VALUES ('35','','1','1','12','http://www.baidu12.com','/uploads/202211/03/221103044357147.png','','','','12','1','1667465040');
INSERT INTO `hc_link` VALUES ('34','','1','1','11','http://www.baidu11.com','/uploads/202211/03/221103044332828.png','','','','11','1','1667465015');
INSERT INTO `hc_link` VALUES ('33','','1','1','10','http://www.baidu10.com','/uploads/202211/03/221103044315534.png','','','','10','1','1667464999');
INSERT INTO `hc_link` VALUES ('24','','1','1','1','http://www.baidu.com','/uploads/202211/03/221103043758147.png','','','','1','1','1667464692');
INSERT INTO `hc_link` VALUES ('25','','1','1','2','http://www.baidu2.com','/uploads/202211/03/221103043831124.png','','','','2','1','1667464719');
INSERT INTO `hc_link` VALUES ('26','','1','1','3','http://www.baidu33.com','/uploads/202211/03/221103043855595.png','','','','3','1','1667464738');
INSERT INTO `hc_link` VALUES ('27','','1','1','4','http://www.baidu4.com','/uploads/202211/03/221103044001206.png','','','','4','1','1667464804');
INSERT INTO `hc_link` VALUES ('28','','1','1','5','http://www.baidu5.com','/uploads/202211/03/221103044055115.png','','','','5','1','1667464858');
INSERT INTO `hc_link` VALUES ('29','','1','1','6','http://www.baidu6.com','/uploads/202211/03/221103044114462.png','','','','6','1','1667464880');
INSERT INTO `hc_link` VALUES ('30','','1','1','7','http://www.baidu7.com','/uploads/202211/03/221103044154742.png','','','','7','1','1667464918');
INSERT INTO `hc_link` VALUES ('31','','1','1','8','http://www.baidu8.com','/uploads/202211/03/221103044206470.png','','','','8','1','1667464941');
INSERT INTO `hc_link` VALUES ('32','','1','1','9','http://www.baidu9.com','/uploads/202211/03/221103044237435.png','','','','9','1','1667464966');
INSERT INTO `hc_link` VALUES ('42','','1','1','19','http://www.baidu19.com','/uploads/202211/03/221103044628360.png','','','','19','1','1667465190');
INSERT INTO `hc_link` VALUES ('41','','1','1','18','http://www.baidu18.com','/uploads/202211/03/221103044611784.png','','','','18','1','1667465173');
INSERT INTO `hc_link` VALUES ('40','','1','1','17','http://www.baidu17.com','/uploads/202211/03/221103044554341.png','','','','17','1','1667465156');
INSERT INTO `hc_link` VALUES ('39','','1','','16','http://www.baidu16.com','/uploads/202211/03/221103044529746.png','','','','16','1','1667465131');
INSERT INTO `hc_link` VALUES ('38','','1','1','15','http://www.baidu15.com','/uploads/202211/03/221103044458850.png','','','','15','1','1667465103');
INSERT INTO `hc_link` VALUES ('37','','1','1','14','http://www.baidu14.com','/uploads/202211/03/221103044443543.png','','','','14','1','1667465086');
INSERT INTO `hc_link` VALUES ('43','','1','1','20','http://www.baidu20.com','/uploads/202211/03/221103044644371.png','','','','20','1','1667465209');

-- -----------------------------
-- Table structure for `hc_member`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member`;
CREATE TABLE `hc_member` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL DEFAULT '',
  `lastip` char(15) NOT NULL DEFAULT '',
  `loginnum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `email` char(32) NOT NULL DEFAULT '',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '金钱',
  `experience` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '经验',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0待审核,1正常,2锁定,3拒绝',
  `vip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `overduedate` int(10) unsigned NOT NULL DEFAULT '0',
  `email_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `problem` varchar(39) NOT NULL DEFAULT '' COMMENT '安全问题',
  `answer` varchar(30) NOT NULL DEFAULT '' COMMENT '答案',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_authorization`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_authorization`;
CREATE TABLE `hc_member_authorization` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `authname` varchar(10) NOT NULL DEFAULT '',
  `token` varchar(60) NOT NULL DEFAULT '',
  `userinfo` varchar(255) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `authindex` (`authname`,`token`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_detail`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_detail`;
CREATE TABLE `hc_member_detail` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sex` varchar(6) NOT NULL DEFAULT '',
  `realname` varchar(30) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `nickname` char(20) NOT NULL DEFAULT '',
  `qq` char(11) NOT NULL DEFAULT '',
  `mobile` char(11) NOT NULL DEFAULT '',
  `phone` char(10) NOT NULL DEFAULT '',
  `userpic` varchar(100) NOT NULL DEFAULT '',
  `birthday` char(10) NOT NULL DEFAULT '' COMMENT '生日',
  `industry` varchar(60) NOT NULL DEFAULT '' COMMENT '行业',
  `area` varchar(60) NOT NULL DEFAULT '',
  `motto` varchar(210) NOT NULL DEFAULT '' COMMENT '个性签名',
  `introduce` text COMMENT '个人简介',
  `guest` int(10) unsigned NOT NULL DEFAULT '0',
  `fans` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '粉丝数',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_follow`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_follow`;
CREATE TABLE `hc_member_follow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `followid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '被关注者id',
  `followname` varchar(30) NOT NULL DEFAULT '' COMMENT '被关注者用户名',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_group`;
CREATE TABLE `hc_member_group` (
  `groupid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(21) NOT NULL DEFAULT '',
  `experience` smallint(6) unsigned NOT NULL DEFAULT '0',
  `icon` char(30) NOT NULL DEFAULT '' COMMENT '图标',
  `authority` char(12) NOT NULL DEFAULT '' COMMENT '1短消息,2发表评论,3发表内容',
  `max_amount` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '每日最大投稿量',
  `description` char(100) NOT NULL DEFAULT '',
  `is_system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统内置',
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_member_group`
-- -----------------------------
INSERT INTO `hc_member_group` VALUES ('1','初来乍到','50','icon1.png','1,2','1','初来乍到组','1');
INSERT INTO `hc_member_group` VALUES ('2','新手上路','100','icon2.png','1,2','2','新手上路组','1');
INSERT INTO `hc_member_group` VALUES ('3','中级会员','200','icon3.png','1,2,3','3','中级会员组','1');
INSERT INTO `hc_member_group` VALUES ('4','高级会员','300','icon4.png','1,2,3','4','高级会员组','1');
INSERT INTO `hc_member_group` VALUES ('5','金牌会员','500','icon5.png','1,2,3,4','5','金牌会员组','1');

-- -----------------------------
-- Table structure for `hc_member_guest`
-- -----------------------------
DROP TABLE IF EXISTS `hc_member_guest`;
CREATE TABLE `hc_member_guest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `space_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guest_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `guest_name` varchar(30) NOT NULL DEFAULT '',
  `guest_pic` varchar(100) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `space_id` (`space_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_menu`
-- -----------------------------
DROP TABLE IF EXISTS `hc_menu`;
CREATE TABLE `hc_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL DEFAULT '',
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL DEFAULT '',
  `c` char(20) NOT NULL DEFAULT '',
  `a` char(30) NOT NULL DEFAULT '',
  `data` char(100) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `parentid` (`parentid`),
  KEY `module` (`m`,`c`,`a`)
) ENGINE=MyISAM AUTO_INCREMENT=314 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_menu`
-- -----------------------------
INSERT INTO `hc_menu` VALUES ('1','内容管理','','admin','content','top','yzm-iconneirong','1','1');
INSERT INTO `hc_menu` VALUES ('2','会员管理','','member','member','top','yzm-iconyonghu','2','1');
INSERT INTO `hc_menu` VALUES ('3','模块管理','','admin','module','top','yzm-icondaohang','3','1');
INSERT INTO `hc_menu` VALUES ('4','管理员管理','','admin','admin_manage','top','yzm-iconguanliyuan','4','1');
INSERT INTO `hc_menu` VALUES ('5','个人信息','','admin','admin_manage','top','yzm-iconrizhi','5','');
INSERT INTO `hc_menu` VALUES ('6','系统管理','','admin','system_manage','top','yzm-iconshezhi','6','1');
INSERT INTO `hc_menu` VALUES ('7','数据管理','','admin','database','top','yzm-iconshujuku','7','1');
INSERT INTO `hc_menu` VALUES ('8','稿件管理','1','admin','admin_content','init','','13','1');
INSERT INTO `hc_menu` VALUES ('9','稿件浏览','8','admin','admin_content','public_preview','','','');
INSERT INTO `hc_menu` VALUES ('10','稿件删除','8','admin','admin_content','del','','','');
INSERT INTO `hc_menu` VALUES ('11','通过审核','8','admin','admin_content','adopt','','','');
INSERT INTO `hc_menu` VALUES ('12','退稿','8','admin','admin_content','rejection','','','');
INSERT INTO `hc_menu` VALUES ('13','后台操作日志','6','admin','admin_log','init','','66','1');
INSERT INTO `hc_menu` VALUES ('14','操作日志删除','13','admin','admin_log','del_log','','','');
INSERT INTO `hc_menu` VALUES ('15','操作日志搜索','13','admin','admin_log','search_log','','','');
INSERT INTO `hc_menu` VALUES ('16','后台登录日志','6','admin','admin_log','admin_login_log_list','','67','1');
INSERT INTO `hc_menu` VALUES ('17','登录日志删除','16','admin','admin_log','del_login_log','','','');
INSERT INTO `hc_menu` VALUES ('18','管理员管理','4','admin','admin_manage','init','','','1');
INSERT INTO `hc_menu` VALUES ('19','删除管理员','18','admin','admin_manage','delete','','','');
INSERT INTO `hc_menu` VALUES ('20','添加管理员','18','admin','admin_manage','add','','','');
INSERT INTO `hc_menu` VALUES ('21','编辑管理员','18','admin','admin_manage','edit','','','');
INSERT INTO `hc_menu` VALUES ('22','修改资料','18','admin','admin_manage','public_edit_info','','','1');
INSERT INTO `hc_menu` VALUES ('23','修改密码','18','admin','admin_manage','public_edit_pwd','','','1');
INSERT INTO `hc_menu` VALUES ('24','栏目管理','1','admin','category','init','','11','1');
INSERT INTO `hc_menu` VALUES ('25','排序栏目','24','admin','category','order','','','');
INSERT INTO `hc_menu` VALUES ('26','删除栏目','24','admin','category','delete','','','');
INSERT INTO `hc_menu` VALUES ('27','添加栏目','24','admin','category','add','','','');
INSERT INTO `hc_menu` VALUES ('28','编辑栏目','24','admin','category','edit','','','');
INSERT INTO `hc_menu` VALUES ('29','编辑单页内容','24','admin','category','page_content','','','');
INSERT INTO `hc_menu` VALUES ('30','内容管理','1','admin','content','init','','10','1');
INSERT INTO `hc_menu` VALUES ('31','内容搜索','30','admin','content','search','','','');
INSERT INTO `hc_menu` VALUES ('32','添加内容','30','admin','content','add','','','');
INSERT INTO `hc_menu` VALUES ('33','修改内容','30','admin','content','edit','','','');
INSERT INTO `hc_menu` VALUES ('34','删除内容','30','admin','content','del','','','');
INSERT INTO `hc_menu` VALUES ('35','数据备份','7','admin','database','init','','70','1');
INSERT INTO `hc_menu` VALUES ('36','数据还原','7','admin','database','databack_list','','71','1');
INSERT INTO `hc_menu` VALUES ('37','优化表','35','admin','database','public_optimize','','','');
INSERT INTO `hc_menu` VALUES ('38','修复表','35','admin','database','public_repair','','','');
INSERT INTO `hc_menu` VALUES ('39','备份文件删除','36','admin','database','databack_del','','','');
INSERT INTO `hc_menu` VALUES ('40','备份文件下载','36','admin','database','databack_down','','','');
INSERT INTO `hc_menu` VALUES ('41','数据导入','36','admin','database','import','','','');
INSERT INTO `hc_menu` VALUES ('42','字段管理','54','admin','model_field','init','','','1');
INSERT INTO `hc_menu` VALUES ('43','添加字段','42','admin','model_field','add','','','');
INSERT INTO `hc_menu` VALUES ('44','修改字段','42','admin','model_field','edit','','','');
INSERT INTO `hc_menu` VALUES ('45','删除字段','42','admin','model_field','delete','','','');
INSERT INTO `hc_menu` VALUES ('46','排序字段','42','admin','model_field','order','','','');
INSERT INTO `hc_menu` VALUES ('47','模块管理','3','admin','module','init','','','1');
INSERT INTO `hc_menu` VALUES ('48','模块安装','47','admin','module','install','','','');
INSERT INTO `hc_menu` VALUES ('49','模块卸载','47','admin','module','uninstall','','','');
INSERT INTO `hc_menu` VALUES ('50','角色管理','4','admin','role','init','','','1');
INSERT INTO `hc_menu` VALUES ('51','删除角色','50','admin','role','delete','','','');
INSERT INTO `hc_menu` VALUES ('52','添加角色','50','admin','role','add','','','');
INSERT INTO `hc_menu` VALUES ('53','编辑角色','50','admin','role','edit','','','');
INSERT INTO `hc_menu` VALUES ('54','模型管理','1','admin','sitemodel','init','','15','1');
INSERT INTO `hc_menu` VALUES ('55','删除模型','54','admin','sitemodel','delete','','','');
INSERT INTO `hc_menu` VALUES ('56','添加模型','54','admin','sitemodel','add','','','');
INSERT INTO `hc_menu` VALUES ('57','编辑模型','54','admin','sitemodel','edit','','','');
INSERT INTO `hc_menu` VALUES ('58','系统设置','6','admin','system_manage','init','','60','1');
INSERT INTO `hc_menu` VALUES ('59','会员中心设置','2','admin','system_manage','member_set','','26','1');
INSERT INTO `hc_menu` VALUES ('60','屏蔽词管理','6','admin','system_manage','prohibit_words','','63','1');
INSERT INTO `hc_menu` VALUES ('61','自定义配置','6','admin','system_manage','user_config_list','','62','1');
INSERT INTO `hc_menu` VALUES ('62','添加配置','61','admin','system_manage','user_config_add','','','');
INSERT INTO `hc_menu` VALUES ('63','配置编辑','61','admin','system_manage','user_config_edit','','','');
INSERT INTO `hc_menu` VALUES ('64','配置删除','61','admin','system_manage','user_config_del','','','');
INSERT INTO `hc_menu` VALUES ('65','TAG管理','1','admin','tag','init','','16','1');
INSERT INTO `hc_menu` VALUES ('66','添加TAG','65','admin','tag','add','','','');
INSERT INTO `hc_menu` VALUES ('67','编辑TAG','65','admin','tag','edit','','','');
INSERT INTO `hc_menu` VALUES ('68','删除TAG','65','admin','tag','del','','','');
INSERT INTO `hc_menu` VALUES ('69','批量更新URL','1','admin','update_urls','init','','17','1');
INSERT INTO `hc_menu` VALUES ('70','附件管理','1','attachment','index','init','','14','1');
INSERT INTO `hc_menu` VALUES ('71','附件搜索','70','attachment','index','search_list','','','');
INSERT INTO `hc_menu` VALUES ('72','附件浏览','70','attachment','index','public_att_view','','','');
INSERT INTO `hc_menu` VALUES ('73','删除单个附件','70','attachment','index','del_one','','','');
INSERT INTO `hc_menu` VALUES ('74','删除多个附件','70','attachment','index','del','','','');
INSERT INTO `hc_menu` VALUES ('75','评论管理','1','comment','comment','init','','12','1');
INSERT INTO `hc_menu` VALUES ('76','评论搜索','75','comment','comment','search','','','');
INSERT INTO `hc_menu` VALUES ('77','删除评论','75','comment','comment','del','','','');
INSERT INTO `hc_menu` VALUES ('78','评论审核','75','comment','comment','adopt','','','');
INSERT INTO `hc_menu` VALUES ('79','留言管理','3','guestbook','guestbook','init','','1','1');
INSERT INTO `hc_menu` VALUES ('80','查看及回复留言','79','guestbook','guestbook','read','','','');
INSERT INTO `hc_menu` VALUES ('81','留言审核','79','guestbook','guestbook','toggle','','','');
INSERT INTO `hc_menu` VALUES ('82','删除留言','79','guestbook','guestbook','del','','','');
INSERT INTO `hc_menu` VALUES ('88','会员管理','2','member','member','init','','20','1');
INSERT INTO `hc_menu` VALUES ('89','会员搜索','88','member','member','search','','','');
INSERT INTO `hc_menu` VALUES ('90','添加会员','88','member','member','add','','','');
INSERT INTO `hc_menu` VALUES ('91','修改会员信息','88','member','member','edit','','','');
INSERT INTO `hc_menu` VALUES ('92','修改会员密码','88','member','member','password','','','');
INSERT INTO `hc_menu` VALUES ('93','删除会员','88','member','member','del','','','');
INSERT INTO `hc_menu` VALUES ('94','审核会员','2','member','member','check','','21','1');
INSERT INTO `hc_menu` VALUES ('95','通过审核','94','member','member','adopt','','','');
INSERT INTO `hc_menu` VALUES ('96','锁定用户','88','member','member','lock','','','');
INSERT INTO `hc_menu` VALUES ('97','解锁用户','88','member','member','unlock','','','');
INSERT INTO `hc_menu` VALUES ('98','账单管理','2','member','member','pay','','22','1');
INSERT INTO `hc_menu` VALUES ('99','入账记录搜索','98','member','member','pay_search','','','');
INSERT INTO `hc_menu` VALUES ('100','入账记录删除','98','member','member','pay_del','','','');
INSERT INTO `hc_menu` VALUES ('101','消费记录','98','member','member','pay_spend','','','');
INSERT INTO `hc_menu` VALUES ('102','消费记录搜索','98','member','member','pay_spend_search','','','');
INSERT INTO `hc_menu` VALUES ('103','消费记录删除','98','member','member','pay_spend_del','','','');
INSERT INTO `hc_menu` VALUES ('104','会员组管理','2','member','member_group','init','','25','1');
INSERT INTO `hc_menu` VALUES ('105','添加组别','104','member','member_group','add','','','');
INSERT INTO `hc_menu` VALUES ('106','修改组别','104','member','member_group','edit','','','');
INSERT INTO `hc_menu` VALUES ('107','删除组别','104','member','member_group','del','','','');
INSERT INTO `hc_menu` VALUES ('108','消息管理','2','member','member_message','init','','23','1');
INSERT INTO `hc_menu` VALUES ('109','消息搜索','108','member','member_message','search','','','');
INSERT INTO `hc_menu` VALUES ('110','删除消息','108','member','member_message','del','','','');
INSERT INTO `hc_menu` VALUES ('111','发送单个消息','108','member','member_message','add','','','');
INSERT INTO `hc_menu` VALUES ('112','群发消息','2','member','member_message','messages_list','','23','1');
INSERT INTO `hc_menu` VALUES ('113','新建群发','112','member','member_message','add_messages','','','');
INSERT INTO `hc_menu` VALUES ('114','删除群发消息','112','member','member_message','del_messages','','','');
INSERT INTO `hc_menu` VALUES ('115','权限管理','50','admin','role','role_priv','','','');
INSERT INTO `hc_menu` VALUES ('116','后台菜单管理','6','admin','menu','init','','64','1');
INSERT INTO `hc_menu` VALUES ('117','删除菜单','116','admin','menu','delete','','','');
INSERT INTO `hc_menu` VALUES ('118','添加菜单','116','admin','menu','add','','','');
INSERT INTO `hc_menu` VALUES ('119','编辑菜单','116','admin','menu','edit','','','');
INSERT INTO `hc_menu` VALUES ('120','菜单排序','116','admin','menu','order','','','');
INSERT INTO `hc_menu` VALUES ('121','邮箱配置','6','admin','system_manage','init','tab=3','61','1');
INSERT INTO `hc_menu` VALUES ('122','修改资料','5','admin','admin_manage','public_edit_info','','51','1');
INSERT INTO `hc_menu` VALUES ('123','修改密码','5','admin','admin_manage','public_edit_pwd','','52','1');
INSERT INTO `hc_menu` VALUES ('134','友情链接管理','3','link','link','init','','6','1');
INSERT INTO `hc_menu` VALUES ('135','添加友情链接','134','link','link','add','','','');
INSERT INTO `hc_menu` VALUES ('136','修改友情链接','134','link','link','edit','','','');
INSERT INTO `hc_menu` VALUES ('137','删除单个友情链接','134','link','link','del_one','','','');
INSERT INTO `hc_menu` VALUES ('138','删除多个友情链接','134','link','link','del','','','');
INSERT INTO `hc_menu` VALUES ('139','URL规则管理','6','admin','urlrule','init','','65','1');
INSERT INTO `hc_menu` VALUES ('140','添加URL规则','139','admin','urlrule','add','','','');
INSERT INTO `hc_menu` VALUES ('141','删除URL规则','139','admin','urlrule','del','','','');
INSERT INTO `hc_menu` VALUES ('142','编辑URL规则','139','admin','urlrule','edit','','','');
INSERT INTO `hc_menu` VALUES ('143','批量移动','30','admin','content','remove','','','');
INSERT INTO `hc_menu` VALUES ('144','SQL命令行','6','admin','sql','init','','63','1');
INSERT INTO `hc_menu` VALUES ('145','提交SQL命令','144','admin','sql','do_sql','','','');
INSERT INTO `hc_menu` VALUES ('156','轮播图管理','3','banner','banner','init','','1','1');
INSERT INTO `hc_menu` VALUES ('157','添加轮播','156','banner','banner','add','','','');
INSERT INTO `hc_menu` VALUES ('158','修改轮播','156','banner','banner','edit','','','');
INSERT INTO `hc_menu` VALUES ('159','删除轮播','156','banner','banner','del','','','');
INSERT INTO `hc_menu` VALUES ('160','添加轮播分类','156','banner','banner','cat_add','','','');
INSERT INTO `hc_menu` VALUES ('161','管理轮播分类','156','banner','banner','cat_manage','','','');
INSERT INTO `hc_menu` VALUES ('162','会员统计','2','member','member','member_count','','24','1');
INSERT INTO `hc_menu` VALUES ('165','采集管理','3','collection','collection_content','init','','','1');
INSERT INTO `hc_menu` VALUES ('166','添加采集节点','165','collection','collection_content','add','','','');
INSERT INTO `hc_menu` VALUES ('167','编辑采集节点','165','collection','collection_content','edit','','','');
INSERT INTO `hc_menu` VALUES ('168','删除采集节点','165','collection','collection_content','del','','','');
INSERT INTO `hc_menu` VALUES ('169','采集测试','165','collection','collection_content','collection_test','','','');
INSERT INTO `hc_menu` VALUES ('170','采集网址','165','collection','collection_content','collection_list_url','','','');
INSERT INTO `hc_menu` VALUES ('171','采集内容','165','collection','collection_content','collection_article_content','','','');
INSERT INTO `hc_menu` VALUES ('172','内容导入','165','collection','collection_content','collection_content_import','','','');
INSERT INTO `hc_menu` VALUES ('173','新建内容发布方案','165','collection','collection_content','create_programme','','','');
INSERT INTO `hc_menu` VALUES ('174','采集列表','165','collection','collection_content','collection_list','','','');
INSERT INTO `hc_menu` VALUES ('175','删除采集列表','165','collection','collection_content','collection_list_del','','','');
INSERT INTO `hc_menu` VALUES ('200','微信管理','','wechat','wechat','top','yzm-iconweixin','3','1');
INSERT INTO `hc_menu` VALUES ('201','微信配置','200','wechat','config','init','','','1');
INSERT INTO `hc_menu` VALUES ('202','保存配置','201','wechat','config','save','','','');
INSERT INTO `hc_menu` VALUES ('203','微信用户','200','wechat','user','init','','','1');
INSERT INTO `hc_menu` VALUES ('204','关注者搜索','203','wechat','user','search','','','');
INSERT INTO `hc_menu` VALUES ('205','获取分组名称','203','wechat','user','get_groupname','','','');
INSERT INTO `hc_menu` VALUES ('206','同步微信服务器用户','203','wechat','user','synchronization','','','');
INSERT INTO `hc_menu` VALUES ('207','批量移动用户分组','203','wechat','user','move_user_group','','','');
INSERT INTO `hc_menu` VALUES ('208','设置用户备注','203','wechat','user','set_userremark','','','');
INSERT INTO `hc_menu` VALUES ('209','查询用户所在组','203','wechat','user','select_user_group','','','');
INSERT INTO `hc_menu` VALUES ('210','分组管理','200','wechat','group','init','','','1');
INSERT INTO `hc_menu` VALUES ('211','创建分组','210','wechat','group','add','','','');
INSERT INTO `hc_menu` VALUES ('212','修改分组','210','wechat','group','edit','','','');
INSERT INTO `hc_menu` VALUES ('213','删除分组','210','wechat','group','delete','','','');
INSERT INTO `hc_menu` VALUES ('214','查询所有分组','210','wechat','group','select_group','','','');
INSERT INTO `hc_menu` VALUES ('215','微信菜单','200','wechat','menu','init','','','1');
INSERT INTO `hc_menu` VALUES ('216','添加菜单','215','wechat','menu','add','','','');
INSERT INTO `hc_menu` VALUES ('217','编辑菜单','215','wechat','menu','edit','','','');
INSERT INTO `hc_menu` VALUES ('218','删除菜单','215','wechat','menu','delete','','','');
INSERT INTO `hc_menu` VALUES ('219','菜单排序','215','wechat','menu','order','','','');
INSERT INTO `hc_menu` VALUES ('220','创建菜单提交微信','215','wechat','menu','create_menu','','','');
INSERT INTO `hc_menu` VALUES ('221','查询远程菜单','215','wechat','menu','select_menu','','','');
INSERT INTO `hc_menu` VALUES ('222','删除所有菜单提交微信','215','wechat','menu','delete_menu','','','');
INSERT INTO `hc_menu` VALUES ('223','消息回复','200','wechat','reply','init','','','1');
INSERT INTO `hc_menu` VALUES ('224','自动回复/关注回复','223','wechat','reply','reply_list','','','');
INSERT INTO `hc_menu` VALUES ('225','添加关键字回复','223','wechat','reply','add','','','');
INSERT INTO `hc_menu` VALUES ('226','修改关键字回复','223','wechat','reply','edit','','','');
INSERT INTO `hc_menu` VALUES ('227','删除关键字回复','223','wechat','reply','del','','','');
INSERT INTO `hc_menu` VALUES ('228','选择文章','223','wechat','reply','select_article','','','');
INSERT INTO `hc_menu` VALUES ('229','消息管理','200','wechat','message','init','','','1');
INSERT INTO `hc_menu` VALUES ('230','用户发送信息','229','wechat','message','send_message','','','');
INSERT INTO `hc_menu` VALUES ('231','标识已读','229','wechat','message','read','','','');
INSERT INTO `hc_menu` VALUES ('232','删除消息','229','wechat','message','del','','','');
INSERT INTO `hc_menu` VALUES ('233','微信场景','200','wechat','scan','init','','','1');
INSERT INTO `hc_menu` VALUES ('234','添加场景','233','wechat','scan','add','','','');
INSERT INTO `hc_menu` VALUES ('235','编辑场景','233','wechat','scan','edit','','','');
INSERT INTO `hc_menu` VALUES ('236','删除场景','233','wechat','scan','del','','','');
INSERT INTO `hc_menu` VALUES ('237','素材管理','200','wechat','material','init','','','1');
INSERT INTO `hc_menu` VALUES ('238','素材搜索','237','wechat','material','search','','','');
INSERT INTO `hc_menu` VALUES ('239','添加素材','237','wechat','material','add','','','');
INSERT INTO `hc_menu` VALUES ('240','添加图文素材','237','wechat','material','add_news','','','');
INSERT INTO `hc_menu` VALUES ('241','删除素材','237','wechat','material','delete','','','');
INSERT INTO `hc_menu` VALUES ('242','选择缩略图','237','wechat','material','select_thumb','','','');
INSERT INTO `hc_menu` VALUES ('243','获取永久素材列表','237','wechat','material','get_material_list','','','');
INSERT INTO `hc_menu` VALUES ('244','高级群发','200','wechat','mass','init','','','1');
INSERT INTO `hc_menu` VALUES ('245','新建群发','244','wechat','mass','add','','','');
INSERT INTO `hc_menu` VALUES ('246','查询群发状态','244','wechat','mass','select_status','','','');
INSERT INTO `hc_menu` VALUES ('247','删除群发','244','wechat','mass','del','','','');
INSERT INTO `hc_menu` VALUES ('248','选择素材','244','wechat','mass','select_material','','','');
INSERT INTO `hc_menu` VALUES ('249','选择用户','244','wechat','mass','select_user','','','');
INSERT INTO `hc_menu` VALUES ('250','自定义表单','3','diyform','diyform','init','','2','1');
INSERT INTO `hc_menu` VALUES ('251','添加表单','250','diyform','diyform','add','','','');
INSERT INTO `hc_menu` VALUES ('252','编辑表单','250','diyform','diyform','edit','','','');
INSERT INTO `hc_menu` VALUES ('253','删除表单','250','diyform','diyform','del','','','');
INSERT INTO `hc_menu` VALUES ('254','字段列表','250','diyform','diyform_field','init','','','');
INSERT INTO `hc_menu` VALUES ('255','添加字段','254','diyform','diyform_field','add','','','');
INSERT INTO `hc_menu` VALUES ('256','修改字段','254','diyform','diyform_field','edit','','','');
INSERT INTO `hc_menu` VALUES ('257','删除字段','254','diyform','diyform_field','delete','','','');
INSERT INTO `hc_menu` VALUES ('258','排序排序','254','diyform','diyform_field','order','','','');
INSERT INTO `hc_menu` VALUES ('259','表单信息列表','250','diyform','diyform_info','init','','','');
INSERT INTO `hc_menu` VALUES ('260','查看表单信息','259','diyform','diyform_info','view','','','');
INSERT INTO `hc_menu` VALUES ('261','删除表单信息','259','diyform','diyform_info','del','','','');
INSERT INTO `hc_menu` VALUES ('262','广告管理','3','adver','adver','init','','','1');
INSERT INTO `hc_menu` VALUES ('263','添加广告','262','adver','adver','add','','','');
INSERT INTO `hc_menu` VALUES ('264','修改广告','262','adver','adver','edit','','','');
INSERT INTO `hc_menu` VALUES ('265','删除广告','262','adver','adver','del','','','');
INSERT INTO `hc_menu` VALUES ('266','网站地图','1','admin','sitemap','init','','16','1');
INSERT INTO `hc_menu` VALUES ('267','生成地图','266','admin','sitemap','make_sitemap','','','');
INSERT INTO `hc_menu` VALUES ('268','导出模型','54','admin','sitemodel','import','','','');
INSERT INTO `hc_menu` VALUES ('269','导入模型','54','admin','sitemodel','export','','','');
INSERT INTO `hc_menu` VALUES ('270','导出配置','61','admin','system_manage','user_config_export','','','');
INSERT INTO `hc_menu` VALUES ('271','导入配置','61','admin','system_manage','user_config_import','','','');
INSERT INTO `hc_menu` VALUES ('283','支付模块','3','pay','pay','init','','','1');
INSERT INTO `hc_menu` VALUES ('284','支付配置','283','pay','pay','edit','','','');
INSERT INTO `hc_menu` VALUES ('285','订单管理','2','member','order','init','','22','1');
INSERT INTO `hc_menu` VALUES ('286','订单搜索','285','member','order','order_search','','','');
INSERT INTO `hc_menu` VALUES ('287','订单改价','285','member','order','change_price','','','');
INSERT INTO `hc_menu` VALUES ('288','订单删除','285','member','order','del','','','');
INSERT INTO `hc_menu` VALUES ('289','订单详情','285','member','order','order_details','','','');
INSERT INTO `hc_menu` VALUES ('290','推送至百度','30','admin','content','baidu_push','','','');
INSERT INTO `hc_menu` VALUES ('291','增加/删除内容属性','30','admin','content','attribute_operation','','','');
INSERT INTO `hc_menu` VALUES ('292','更改model','69','admin','update_urls','change_model','','','');
INSERT INTO `hc_menu` VALUES ('293','更新栏目URL','69','admin','update_urls','update_category_url','','','');
INSERT INTO `hc_menu` VALUES ('294','更新内容页URL','69','admin','update_urls','update_content_url','','','');
INSERT INTO `hc_menu` VALUES ('295','留言搜索','79','guestbook','guestbook','search','','','');
INSERT INTO `hc_menu` VALUES ('296','内容关键字','3','admin','keyword_link','init','','1','1');
INSERT INTO `hc_menu` VALUES ('297','添加关键字','296','admin','keyword_link','add','','','');
INSERT INTO `hc_menu` VALUES ('298','编辑关键字','296','admin','keyword_link','edit','','','');
INSERT INTO `hc_menu` VALUES ('299','删除关键字','296','admin','keyword_link','del','','','');
INSERT INTO `hc_menu` VALUES ('300','应用商店','3','admin','store','init','','','1');
INSERT INTO `hc_menu` VALUES ('301','批量添加栏目','24','admin','category','adds','','','');
INSERT INTO `hc_menu` VALUES ('302','内容复制','30','admin','content','copy','','','');
INSERT INTO `hc_menu` VALUES ('303','内容管理','65','admin','tag','content','','','');
INSERT INTO `hc_menu` VALUES ('304','加入/移除Tag','65','admin','tag','content_oper','','','');
INSERT INTO `hc_menu` VALUES ('305','删除地图','266','admin','sitemap','delete','','','');
INSERT INTO `hc_menu` VALUES ('306','保存配置','58','admin','system_manage','save','','','');
INSERT INTO `hc_menu` VALUES ('307','立即备份','35','admin','database','export_list','','','');
INSERT INTO `hc_menu` VALUES ('308','管理非自己发布的内容','30','admin','content','all_content','','','');
INSERT INTO `hc_menu` VALUES ('309','在线充值','88','member','member','recharge','','','');
INSERT INTO `hc_menu` VALUES ('310','登录到任意会员中心','88','member','member','login_user','','','');
INSERT INTO `hc_menu` VALUES ('311','友情链接排序','134','link','link','order','','','');
INSERT INTO `hc_menu` VALUES ('312','友情链接审核','134','link','link','adopt','','','');
INSERT INTO `hc_menu` VALUES ('313','标识已读','79','guestbook','guestbook','set_read','','','');

-- -----------------------------
-- Table structure for `hc_message`
-- -----------------------------
DROP TABLE IF EXISTS `hc_message`;
CREATE TABLE `hc_message` (
  `messageid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_from` varchar(30) NOT NULL DEFAULT '' COMMENT '发件人',
  `send_to` varchar(30) NOT NULL DEFAULT '' COMMENT '收件人',
  `message_time` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` char(80) NOT NULL DEFAULT '' COMMENT '主题',
  `content` text NOT NULL,
  `replyid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复的id',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '1正常0隐藏',
  `isread` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否读过',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统信息',
  PRIMARY KEY (`messageid`),
  KEY `replyid` (`replyid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_message_data`
-- -----------------------------
DROP TABLE IF EXISTS `hc_message_data`;
CREATE TABLE `hc_message_data` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `group_message_id` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '读过的信息ID',
  PRIMARY KEY (`id`),
  KEY `message` (`userid`,`group_message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_message_group`
-- -----------------------------
DROP TABLE IF EXISTS `hc_message_group`;
CREATE TABLE `hc_message_group` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组id',
  `subject` char(80) NOT NULL DEFAULT '',
  `content` text NOT NULL COMMENT '内容',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_model`
-- -----------------------------
DROP TABLE IF EXISTS `hc_model`;
CREATE TABLE `hc_model` (
  `modelid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` char(30) NOT NULL DEFAULT '',
  `tablename` char(20) NOT NULL DEFAULT '',
  `alias` varchar(30) NOT NULL DEFAULT '',
  `description` varchar(100) NOT NULL DEFAULT '',
  `setting` text,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `items` smallint(5) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isdefault` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`modelid`),
  KEY `siteid` (`siteid`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_model`
-- -----------------------------
INSERT INTO `hc_model` VALUES ('1','','文章模型','article','article','文章模型','','1466393786','','','','','1','1');
INSERT INTO `hc_model` VALUES ('2','','产品模型','product','product','产品模型','','1466393786','','','','','1','');
INSERT INTO `hc_model` VALUES ('3','','下载模型','download','download','下载模型','','1466393786','','','','','1','');

-- -----------------------------
-- Table structure for `hc_model_field`
-- -----------------------------
DROP TABLE IF EXISTS `hc_model_field`;
CREATE TABLE `hc_model_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(100) NOT NULL DEFAULT '',
  `css` varchar(30) NOT NULL DEFAULT '',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `errortips` varchar(100) NOT NULL DEFAULT '',
  `fieldtype` varchar(20) NOT NULL DEFAULT '',
  `defaultvalue` varchar(30) NOT NULL DEFAULT '',
  `setting` text,
  `isrequired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isunique` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isadd` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`fieldid`),
  KEY `modelid` (`modelid`,`disabled`),
  KEY `field` (`field`,`modelid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_model_field`
-- -----------------------------
INSERT INTO `hc_model_field` VALUES ('1','','title','标题','','','1','100','请输入标题','input','','','1','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('2','','catid','栏目','','','1','10','请选择栏目','select','','','1','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('3','','thumb','缩略图','','','','100','','image','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('4','','keywords','关键词','','','','50','','input','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('5','','description','摘要','','','','255','','textarea','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('6','','inputtime','发布时间','','','1','10','','datetime','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('7','','updatetime','更新时间','','','1','10','','datetime','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('8','','copyfrom','来源','','','','30','','input','','','','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('9','','url','URL','','','1','100','','input','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('10','','userid','用户ID','','','1','10','','input','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('11','','username','用户名','','','1','30','','input','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('12','','nickname','昵称','','','','30','','input','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('13','','template','模板','','','1','50','','select','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('14','','content','内容','','','1','999999','','editor','','','1','1','','1','','','','1');
INSERT INTO `hc_model_field` VALUES ('15','','click','点击数','','','1','10','','input','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('16','','tag','TAG','','','','50','','checkbox','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('17','','readpoint','阅读收费','','','1','5','','input','','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('18','','groupids_view','阅读权限','','','1','10','','checkbox','1','','','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('19','','status','状态','','','1','2','','checkbox','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('20','','flag','属性','','','1','16','','checkbox','','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('21','','listorder','排序','','','1','5','','input','1','','1','1','','','','','','1');
INSERT INTO `hc_model_field` VALUES ('22','2','brand','品牌','','','','30','','input','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('23','2','standard','型号','','','','30','','input','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('24','2','yieldly','产地','','','','50','','input','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('25','2','pictures','产品图集','','','','1000','','images','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('26','2','price','单价','请输入单价','','1','10','单价不能为空','input','','','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('27','2','unit','价格单位','','','1','10','','select','','{\"0\":\"件\",\"1\":\"斤\",\"2\":\"KG\",\"3\":\"吨\",\"4\":\"套\"}','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('28','2','stock','库存','库存量必须为数字','','1','5','库存不能为空','input','99999','','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('29','3','down_url','下载地址','','','1','100','下载地址不能为空','attachment','','','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('30','3','copytype','授权形式','','','','20','','select','','{\"0\":\"免费版\",\"1\":\"正式版\",\"2\":\"共享版\",\"3\":\"试用版\",\"4\":\"演示版\",\"5\":\"注册版\",\"6\":\"破解版\"}','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('31','3','systems','平台','','','1','30','','select','','{\"0\":\"Windows\",\"1\":\"Linux\",\"2\":\"MacOS\"}','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('32','3','language','语言','','','','20','','select','','{\"0\":\"简体中文\",\"1\":\"繁体中文\",\"2\":\"英文\",\"3\":\"多国语言\",\"4\":\"其他语言\"}','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('33','3','version','版本','','','1','15','版本号不能为空','input','','','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('34','3','filesize','文件大小','单位为字节','','','10','','input','','','','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('35','3','classtype','软件类型','','','1','30','','radio','','{\"0\":\"国产软件\",\"1\":\"国外软件\",\"2\":\"汉化补丁\",\"3\":\"程序源码\",\"4\":\"其他\"}','1','','','1','1','','','1');
INSERT INTO `hc_model_field` VALUES ('36','3','stars','评分等级','','','','20','','radio','','{\"0\":\"1星\",\"1\":\"2星\",\"2\":\"3星\",\"3\":\"4星\",\"4\":\"5星\"}','','','','1','1','','','1');

-- -----------------------------
-- Table structure for `hc_module`
-- -----------------------------
DROP TABLE IF EXISTS `hc_module`;
CREATE TABLE `hc_module` (
  `module` varchar(15) NOT NULL DEFAULT '',
  `name` varchar(20) NOT NULL DEFAULT '',
  `iscore` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `version` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `setting` text,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `installdate` date NOT NULL DEFAULT '2016-01-01',
  `updatedate` date NOT NULL DEFAULT '2016-01-01',
  PRIMARY KEY (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_module`
-- -----------------------------
INSERT INTO `hc_module` VALUES ('admin','后台模块','1','1.0','后台模块','','','','2016-08-27','2016-08-27');
INSERT INTO `hc_module` VALUES ('index','前台模块','1','1.0','前台模块','','','','2016-09-21','2016-09-21');
INSERT INTO `hc_module` VALUES ('api','接口模块','1','1.0','为整个系统提供接口','','','','2016-08-28','2016-08-28');
INSERT INTO `hc_module` VALUES ('install','安装模块','1','1.0','CMS安装模块','','','','2016-10-28','2016-10-28');
INSERT INTO `hc_module` VALUES ('attachment','附件模块','1','1.0','附件模块','','','','2016-10-10','2016-10-10');
INSERT INTO `hc_module` VALUES ('member','会员模块','1','1.0','会员模块','','','','2016-09-21','2016-09-21');
INSERT INTO `hc_module` VALUES ('guestbook','留言模块','1','1.0','留言板模块','','','','2016-10-25','2016-10-25');
INSERT INTO `hc_module` VALUES ('search','搜索模块','1','1.0','搜索模块','','','','2016-11-21','2016-11-21');
INSERT INTO `hc_module` VALUES ('link','友情链接','','1.0','友情链接模块','','','','2016-12-11','2016-09-28');
INSERT INTO `hc_module` VALUES ('comment','评论模块','1','1.0','全站评论','','','','2017-01-05','2017-01-05');
INSERT INTO `hc_module` VALUES ('mobile','手机模块','1','1.0','手机模块','','','','2017-04-05','2017-04-05');
INSERT INTO `hc_module` VALUES ('banner','轮播图管理','','2.0','轮播图管理模块','','','','2017-05-12','2020-05-17');
INSERT INTO `hc_module` VALUES ('collection','采集模块','1','1.0','采集模块','','','','2017-08-16','2017-08-16');
INSERT INTO `hc_module` VALUES ('wechat','微信模块','1','1.0','微信模块','','','','2017-11-03','2017-11-03');
INSERT INTO `hc_module` VALUES ('diyform','自定义表单模块','1','1.0','自定义表单模块','','','','2018-01-15','2018-01-15');
INSERT INTO `hc_module` VALUES ('adver','广告管理','','1.0','广告管理模块','','','','2018-01-18','2018-01-18');
INSERT INTO `hc_module` VALUES ('pay','支付模块','1','1.0','支付模块','','','','2018-07-03','2018-07-03');

-- -----------------------------
-- Table structure for `hc_order`
-- -----------------------------
DROP TABLE IF EXISTS `hc_order`;
CREATE TABLE `hc_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '订单状态0未付款1已付款',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '支付方式1支付宝2微信',
  `transaction` varchar(32) NOT NULL DEFAULT '' COMMENT '第三方交易单号',
  `money` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `quantity` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '数量',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1积分,2金钱',
  `ip` char(15) NOT NULL DEFAULT '',
  `desc` varchar(250) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `userid` (`userid`),
  KEY `order_sn` (`order_sn`),
  KEY `status` (`status`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单表';


-- -----------------------------
-- Table structure for `hc_page`
-- -----------------------------
DROP TABLE IF EXISTS `hc_page`;
CREATE TABLE `hc_page` (
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(160) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_page`
-- -----------------------------
INSERT INTO `hc_page` VALUES ('51','联系我们','','','1665971015');

-- -----------------------------
-- Table structure for `hc_pay`
-- -----------------------------
DROP TABLE IF EXISTS `hc_pay`;
CREATE TABLE `hc_pay` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `trade_sn` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `money` char(8) NOT NULL DEFAULT '' COMMENT '金钱或积分的量',
  `creat_time` int(10) unsigned NOT NULL DEFAULT '0',
  `msg` varchar(30) NOT NULL DEFAULT '' COMMENT '类型说明',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1积分,2金钱',
  `ip` char(15) NOT NULL DEFAULT '',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1成功,0失败',
  `remarks` varchar(250) NOT NULL DEFAULT '' COMMENT '备注说明',
  `adminnote` char(20) NOT NULL DEFAULT '' COMMENT '如是后台操作,管理员姓名',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `trade_sn` (`trade_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_pay_mode`
-- -----------------------------
DROP TABLE IF EXISTS `hc_pay_mode`;
CREATE TABLE `hc_pay_mode` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `logo` varchar(100) NOT NULL DEFAULT '',
  `desc` varchar(250) NOT NULL DEFAULT '',
  `config` text,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `author` varchar(60) NOT NULL DEFAULT '',
  `version` varchar(10) NOT NULL DEFAULT '',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '支付调用方法',
  `template` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_pay_mode`
-- -----------------------------
INSERT INTO `hc_pay_mode` VALUES ('1','支付宝','alipay.png','支付宝新版在线支付插件，要求PHP版本>=5.5','{\"app_id\":\"\",\"merchant_private_key\":\"\",\"alipay_public_key\":\"\"}','1','袁志蒙','1.0','alipay','alipay');
INSERT INTO `hc_pay_mode` VALUES ('2','微信','wechat.png','微信支付提供公众号支付、APP支付、扫码支付、刷卡支付等支付方式。','{\\\"app_id\\\":\\\"\\\",\\\"app_secret\\\":\\\"\\\",\\\"mch_id\\\":\\\"\\\",\\\"key\\\":\\\"\\\"}','','袁志蒙','1.0','wechat','wechat');

-- -----------------------------
-- Table structure for `hc_pay_spend`
-- -----------------------------
DROP TABLE IF EXISTS `hc_pay_spend`;
CREATE TABLE `hc_pay_spend` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `trade_sn` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `money` char(8) NOT NULL DEFAULT '' COMMENT '金钱或积分的量',
  `creat_time` int(10) unsigned NOT NULL DEFAULT '0',
  `msg` varchar(30) NOT NULL DEFAULT '' COMMENT '类型说明',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1积分,2金钱',
  `ip` char(15) NOT NULL DEFAULT '',
  `remarks` varchar(250) NOT NULL DEFAULT '' COMMENT '备注说明',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `trade_sn` (`trade_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_product`
-- -----------------------------
DROP TABLE IF EXISTS `hc_product`;
CREATE TABLE `hc_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `nickname` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(180) NOT NULL DEFAULT '',
  `color` char(9) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `copyfrom` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `flag` varchar(12) NOT NULL DEFAULT '' COMMENT '1置顶,2头条,3特荐,4推荐,5热点,6幻灯,7跳转',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `groupids_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '收费类型',
  `is_push` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否百度推送',
  `brand` varchar(50) NOT NULL DEFAULT '' COMMENT '品牌',
  `standard` varchar(100) NOT NULL DEFAULT '' COMMENT '型号',
  `yieldly` varchar(100) NOT NULL DEFAULT '' COMMENT '产地',
  `pictures` text COMMENT '产品图集',
  `price` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单价',
  `unit` varchar(30) NOT NULL DEFAULT '' COMMENT '价格单位',
  `stock` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`),
  KEY `catid` (`catid`,`status`),
  KEY `userid` (`userid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_product`
-- -----------------------------
INSERT INTO `hc_product` VALUES ('1','7','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','74','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/qichelingbujian/1.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('2','8','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','76','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/hangkonghang/2.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('3','9','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/jungong/3.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('4','9','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','76','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/jungong/4.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('5','7','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','74','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/qichelingbujian/5.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('6','28','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','74','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/bobimocahan/6.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('7','27','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','74','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/jigoufuza/7.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('8','27','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/jigoufuza/8.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('9','26','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/yiliao/9.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('10','26','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','91','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/yiliao/10.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('11','8','1','admin','管理员','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','','1665392990','1665473827','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','271','<p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">日前，沃尔沃汽车销售（上海）有限公司、大庆沃尔沃汽车制造有限公司、浙江豪情汽车制造有限公司根据《缺陷汽车产品召回管理条例》和《缺陷汽车产品召回管理条例实施办法》的要求，向国家市场监督管理总局备案了召回计划。<strong>召回以下车辆，共计4720辆。</strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">一、 沃尔沃汽车销售（上海）有限公司召回2019年6月4日至2021年3月8日生产的部分2020、2021年款进口XC90汽车，共计1379辆；</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">二、 大庆沃尔沃汽车制造有限公司召回2019年5月15日至2020年9月1日生产的部分2020、2021年款国产S60汽车，共计294辆；2019年3月28日至2020年10月8日生产的部分2020、2021年款国产S90长轴距汽车，共计2109辆；</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">三、 浙江豪情汽车制造有限公司召回2019年2月25日至2020年9月24日生产的部分2020、2021年款国产XC60汽车，共计938辆。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回范围内部分插电式混合动力车辆因动力电池模组电芯存在内短路，当动力电池处于高能量状态时可能出现电池模组过热，极端情况下导致动力电池热失控，存在安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上述生产者自2022年9月30日起，将对召回范围内的车辆暂时采取免费升级软件的方式以降低热失控风险。<span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; text-indent: 2em;\">同时，自2023年5月1日起，将开始为召回范围内的车辆免费更换全部动力电池模组，以消除安全隐患。</span></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\"><strong>应急处置措施：</strong>沃尔沃汽车建议在车辆下载软件前，用户应避免为车辆插电。用户应尽快联系沃尔沃汽车授权经销商，执行软件升级。沃尔沃汽车销售（上海）有限公司、大庆沃尔沃汽车制造有限公司、浙江豪情汽车制造有限公司将以挂号信等形式，通知相关用户。召回开始后，沃尔沃汽车授权经销商将主动联系相关车主，安排召回事宜。用户可通过手机和固定电话，拨打沃尔沃汽车售后服务热线：10108666进行咨询。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); text-indent: 0em; white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-align: center;\"><strong><span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(0, 112, 192);\">上汽通用五菱汽车股份有限公司</span></strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); text-indent: 0em; white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-align: center;\"><strong><span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(0, 112, 192);\">召回部分宝骏RM-5汽车</span></strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">日前，上汽通用五菱汽车股份有限公司根据《缺陷汽车产品召回管理条例》和《缺陷汽车产品召回管理条例实施办法》的要求，向国家市场监督管理总局备案了召回计划。<strong>自2022年11月15日起，召回2019年7月23日至2021年9月4日期间生产的部分宝骏RM-5汽车，共计63230辆。</strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回范围内车辆由于前照灯的透镜反射碗尺寸限制，前照灯照射范围偏窄。夜间极端场景下，在车辆转弯时驾驶员可能看不清两侧路面，存在安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上汽通用五菱汽车股份有限公司将为召回范围内的车辆免费加装左右辅助光源，以消除安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\"><strong>应急处置办法：</strong>夜间驾驶车辆时用户应注意观察，减速慢行，必要时可开启远光灯。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回活动是在国家市场监督管理总局启动缺陷调查情况下开展的。受调查影响，上汽通用五菱汽车股份有限公司决定主动采取召回措施，以消除安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上汽通用五菱汽车股份有限公司将以挂号信、邮件、电话、短信通知等形式邀约用户，安排免费召回检修事宜。用户可拨打客户服务热线：400-86-12345、400-889-5050进行咨询。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">（来源 国家市场监督管理总局 责任编辑 唐元）</p><p><br/></p>','网络','/uploads/202210/11/221011014303722.jpg','http://localhost:91/hangkonghang/11.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('12','11','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/dayinshebei/12.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('13','11','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','78','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/dayinshebei/13.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('14','30','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/yangjiaozongchengbujian/14.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('15','30','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','78','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/yangjiaozongchengbujian/15.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('16','29','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/zhuanxiangzongchengbujian/16.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('17','29','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','76','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/zhuanxiangzongchengbujian/17.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('18','29','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/zhuanxiangzongchengbujian/18.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('19','29','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','89','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/zhuanxiangzongchengbujian/19.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('20','29','1','admin','管理员','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','','1665392990','1665473827','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','317','<p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">日前，沃尔沃汽车销售（上海）有限公司、大庆沃尔沃汽车制造有限公司、浙江豪情汽车制造有限公司根据《缺陷汽车产品召回管理条例》和《缺陷汽车产品召回管理条例实施办法》的要求，向国家市场监督管理总局备案了召回计划。<strong>召回以下车辆，共计4720辆。</strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">一、 沃尔沃汽车销售（上海）有限公司召回2019年6月4日至2021年3月8日生产的部分2020、2021年款进口XC90汽车，共计1379辆；</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">二、 大庆沃尔沃汽车制造有限公司召回2019年5月15日至2020年9月1日生产的部分2020、2021年款国产S60汽车，共计294辆；2019年3月28日至2020年10月8日生产的部分2020、2021年款国产S90长轴距汽车，共计2109辆；</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">三、 浙江豪情汽车制造有限公司召回2019年2月25日至2020年9月24日生产的部分2020、2021年款国产XC60汽车，共计938辆。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回范围内部分插电式混合动力车辆因动力电池模组电芯存在内短路，当动力电池处于高能量状态时可能出现电池模组过热，极端情况下导致动力电池热失控，存在安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上述生产者自2022年9月30日起，将对召回范围内的车辆暂时采取免费升级软件的方式以降低热失控风险。<span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; text-indent: 2em;\">同时，自2023年5月1日起，将开始为召回范围内的车辆免费更换全部动力电池模组，以消除安全隐患。</span></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\"><strong>应急处置措施：</strong>沃尔沃汽车建议在车辆下载软件前，用户应避免为车辆插电。用户应尽快联系沃尔沃汽车授权经销商，执行软件升级。沃尔沃汽车销售（上海）有限公司、大庆沃尔沃汽车制造有限公司、浙江豪情汽车制造有限公司将以挂号信等形式，通知相关用户。召回开始后，沃尔沃汽车授权经销商将主动联系相关车主，安排召回事宜。用户可通过手机和固定电话，拨打沃尔沃汽车售后服务热线：10108666进行咨询。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); text-indent: 0em; white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-align: center;\"><strong><span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(0, 112, 192);\">上汽通用五菱汽车股份有限公司</span></strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); text-indent: 0em; white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-align: center;\"><strong><span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(0, 112, 192);\">召回部分宝骏RM-5汽车</span></strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">日前，上汽通用五菱汽车股份有限公司根据《缺陷汽车产品召回管理条例》和《缺陷汽车产品召回管理条例实施办法》的要求，向国家市场监督管理总局备案了召回计划。<strong>自2022年11月15日起，召回2019年7月23日至2021年9月4日期间生产的部分宝骏RM-5汽车，共计63230辆。</strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回范围内车辆由于前照灯的透镜反射碗尺寸限制，前照灯照射范围偏窄。夜间极端场景下，在车辆转弯时驾驶员可能看不清两侧路面，存在安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上汽通用五菱汽车股份有限公司将为召回范围内的车辆免费加装左右辅助光源，以消除安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\"><strong>应急处置办法：</strong>夜间驾驶车辆时用户应注意观察，减速慢行，必要时可开启远光灯。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回活动是在国家市场监督管理总局启动缺陷调查情况下开展的。受调查影响，上汽通用五菱汽车股份有限公司决定主动采取召回措施，以消除安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上汽通用五菱汽车股份有限公司将以挂号信、邮件、电话、短信通知等形式邀约用户，安排免费召回检修事宜。用户可拨打客户服务热线：400-86-12345、400-889-5050进行咨询。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">（来源 国家市场监督管理总局 责任编辑 唐元）</p><p><br/></p>','网络','/uploads/202210/11/221011014303722.jpg','http://localhost:91/zhuanxiangzongchengbujian/20.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('21','24','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','91','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/chunjixiejiagong/21.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('22','24','1','admin','管理员','3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试','','1665392990','1665473827','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','284','<p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">日前，沃尔沃汽车销售（上海）有限公司、大庆沃尔沃汽车制造有限公司、浙江豪情汽车制造有限公司根据《缺陷汽车产品召回管理条例》和《缺陷汽车产品召回管理条例实施办法》的要求，向国家市场监督管理总局备案了召回计划。<strong>召回以下车辆，共计4720辆。</strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">一、 沃尔沃汽车销售（上海）有限公司召回2019年6月4日至2021年3月8日生产的部分2020、2021年款进口XC90汽车，共计1379辆；</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">二、 大庆沃尔沃汽车制造有限公司召回2019年5月15日至2020年9月1日生产的部分2020、2021年款国产S60汽车，共计294辆；2019年3月28日至2020年10月8日生产的部分2020、2021年款国产S90长轴距汽车，共计2109辆；</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">三、 浙江豪情汽车制造有限公司召回2019年2月25日至2020年9月24日生产的部分2020、2021年款国产XC60汽车，共计938辆。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回范围内部分插电式混合动力车辆因动力电池模组电芯存在内短路，当动力电池处于高能量状态时可能出现电池模组过热，极端情况下导致动力电池热失控，存在安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上述生产者自2022年9月30日起，将对召回范围内的车辆暂时采取免费升级软件的方式以降低热失控风险。<span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; text-indent: 2em;\">同时，自2023年5月1日起，将开始为召回范围内的车辆免费更换全部动力电池模组，以消除安全隐患。</span></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\"><strong>应急处置措施：</strong>沃尔沃汽车建议在车辆下载软件前，用户应避免为车辆插电。用户应尽快联系沃尔沃汽车授权经销商，执行软件升级。沃尔沃汽车销售（上海）有限公司、大庆沃尔沃汽车制造有限公司、浙江豪情汽车制造有限公司将以挂号信等形式，通知相关用户。召回开始后，沃尔沃汽车授权经销商将主动联系相关车主，安排召回事宜。用户可通过手机和固定电话，拨打沃尔沃汽车售后服务热线：10108666进行咨询。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); text-indent: 0em; white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-align: center;\"><strong><span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(0, 112, 192);\">上汽通用五菱汽车股份有限公司</span></strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); text-indent: 0em; white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-align: center;\"><strong><span style=\"font-family: inherit; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(0, 112, 192);\">召回部分宝骏RM-5汽车</span></strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">日前，上汽通用五菱汽车股份有限公司根据《缺陷汽车产品召回管理条例》和《缺陷汽车产品召回管理条例实施办法》的要求，向国家市场监督管理总局备案了召回计划。<strong>自2022年11月15日起，召回2019年7月23日至2021年9月4日期间生产的部分宝骏RM-5汽车，共计63230辆。</strong></p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回范围内车辆由于前照灯的透镜反射碗尺寸限制，前照灯照射范围偏窄。夜间极端场景下，在车辆转弯时驾驶员可能看不清两侧路面，存在安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上汽通用五菱汽车股份有限公司将为召回范围内的车辆免费加装左右辅助光源，以消除安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\"><strong>应急处置办法：</strong>夜间驾驶车辆时用户应注意观察，减速慢行，必要时可开启远光灯。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">本次召回活动是在国家市场监督管理总局启动缺陷调查情况下开展的。受调查影响，上汽通用五菱汽车股份有限公司决定主动采取召回措施，以消除安全隐患。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">上汽通用五菱汽车股份有限公司将以挂号信、邮件、电话、短信通知等形式邀约用户，安排免费召回检修事宜。用户可拨打客户服务热线：400-86-12345、400-889-5050进行咨询。</p><p style=\"font-family: &quot;Microsoft YaHei&quot;; font-size: 18px; margin-top: 1em; margin-bottom: 1em; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(51, 51, 51); white-space: normal; background-color: rgb(255, 255, 255); line-height: 1.5; text-indent: 2em; text-align: justify;\">（来源 国家市场监督管理总局 责任编辑 唐元）</p><p><br/></p>','网络','/uploads/202210/11/221011014303722.jpg','http://localhost:91/chunjixiejiagong/22.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('23','25','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','75','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/jingmi3ddayin/23.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('24','25','1','admin','管理员','3D打印样式测试','','1665392990','1665451250','3D,打印,样式,测试','3D打印样式测试3D打印样式测试3D打印样式测试','85','<p>3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试3D打印样式测试</p>','网络','/uploads/202210/11/221011092037999.png','http://localhost:91/jingmi3ddayin/24.html','','1','1','10','','','1','','','','','{\"0\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092029917.jpg\",\"alt\":\"3D打印样式测试-1\"},\"1\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036595.jpg\",\"alt\":\"3D打印样式测试-2\"},\"2\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092036254.jpg\",\"alt\":\"3D打印样式测试-3\"},\"3\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037177.jpg\",\"alt\":\"3D打印样式测试-4\"},\"4\":{\"url\":\"\\/uploads\\/202210\\/11\\/221011092037999.png\",\"alt\":\"3D打印样式测试-5\"}}','1','件','99999');
INSERT INTO `hc_product` VALUES ('25','11','1','admin','管理员','SLA光固化3D打印机就','','1665972444','1666079223','SLA,固化,3D,打印机','SLA光固化3D打印机就SLA光固化3D打印机就SLA光固化3D打印机就SLA光固化3D打印机就SLA光固化3D打印机就','26','<p>SLA光固化3D打印机就SLA光固化3D打印机就SLA光固化3D打印机就SLA光固化3D打印机就SLA光固化3D打印机就</p>','网络','','http://localhost:91/dayinshebei/25.html','','1','1','10','','','1','','','','','','','件','99999');

-- -----------------------------
-- Table structure for `hc_tag`
-- -----------------------------
DROP TABLE IF EXISTS `hc_tag`;
CREATE TABLE `hc_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(30) NOT NULL DEFAULT '',
  `total` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `click` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seo_title` varchar(100) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keywords` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `seo_description` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `siteid_catid` (`siteid`,`catid`),
  KEY `siteid_tag` (`siteid`,`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_tag`
-- -----------------------------
INSERT INTO `hc_tag` VALUES ('1','','','打印机','3','3','','','','1665474051');
INSERT INTO `hc_tag` VALUES ('2','','','设备','3','1','','','','1665474051');
INSERT INTO `hc_tag` VALUES ('3','','','新闻','4','2','','','','1665474051');

-- -----------------------------
-- Table structure for `hc_tag_content`
-- -----------------------------
DROP TABLE IF EXISTS `hc_tag_content`;
CREATE TABLE `hc_tag_content` (
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `aid` int(10) unsigned NOT NULL DEFAULT '0',
  `tagid` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `tag_index` (`modelid`,`aid`),
  KEY `tagid_index` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hc_tag_content`
-- -----------------------------
INSERT INTO `hc_tag_content` VALUES ('2','8','11','3');
INSERT INTO `hc_tag_content` VALUES ('2','8','10','3');
INSERT INTO `hc_tag_content` VALUES ('2','8','9','3');
INSERT INTO `hc_tag_content` VALUES ('2','8','11','2');
INSERT INTO `hc_tag_content` VALUES ('2','7','8','2');
INSERT INTO `hc_tag_content` VALUES ('2','7','7','2');
INSERT INTO `hc_tag_content` VALUES ('2','7','6','1');
INSERT INTO `hc_tag_content` VALUES ('2','7','5','1');
INSERT INTO `hc_tag_content` VALUES ('2','9','4','1');

-- -----------------------------
-- Table structure for `hc_urlrule`
-- -----------------------------
DROP TABLE IF EXISTS `hc_urlrule`;
CREATE TABLE `hc_urlrule` (
  `urlruleid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '规则名称',
  `urlrule` varchar(100) NOT NULL DEFAULT '' COMMENT 'URL规则',
  `route` varchar(100) NOT NULL DEFAULT '' COMMENT '指向的路由',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '50' COMMENT '优先级排序',
  PRIMARY KEY (`urlruleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_auto_reply`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_auto_reply`;
CREATE TABLE `hc_wechat_auto_reply` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1关键字回复2自动回复3关注回复',
  `keyword` varchar(64) NOT NULL DEFAULT '' COMMENT '关键字回复的关键字',
  `keyword_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1完全匹配0模糊匹配',
  `relation_id` varchar(15) NOT NULL DEFAULT '' COMMENT '图文回复的关联内容ID',
  `content` text NOT NULL COMMENT '文本回复的内容',
  PRIMARY KEY (`id`),
  KEY `type_index` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_group`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_group`;
CREATE TABLE `hc_wechat_group` (
  `id` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_mass`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_mass`;
CREATE TABLE `hc_wechat_mass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_type` char(6) NOT NULL DEFAULT '' COMMENT '消息类型',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0通过openid群发1通过分组群发2全部',
  `media_id` varchar(200) NOT NULL DEFAULT '',
  `msg_id` varchar(10) NOT NULL DEFAULT '',
  `msg_data_id` varchar(10) NOT NULL DEFAULT '' COMMENT '图文消息的数据ID',
  `receive` varchar(255) NOT NULL DEFAULT '' COMMENT '按组群发为组id，否则为openid列表',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1任务提交成功2群发已结束',
  `masstime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_media`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_media`;
CREATE TABLE `hc_wechat_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `originname` varchar(50) NOT NULL DEFAULT '',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filepath` char(200) NOT NULL DEFAULT '',
  `type` char(6) NOT NULL DEFAULT '',
  `media_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0临时素材,1永久素材',
  `media_id` varchar(200) NOT NULL DEFAULT '',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(200) NOT NULL DEFAULT '' COMMENT '永久素材的图片url/图文素材标题',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_menu`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_menu`;
CREATE TABLE `hc_wechat_menu` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(6) NOT NULL DEFAULT '0',
  `name` varchar(48) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1关键字2跳转',
  `keyword` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `event` varchar(64) NOT NULL DEFAULT '',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_message`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_message`;
CREATE TABLE `hc_wechat_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `openid` char(100) NOT NULL DEFAULT '',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统回复',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `msgtype` varchar(32) NOT NULL DEFAULT '' COMMENT '消息类型',
  `isread` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1已读0未读',
  `content` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `openid` (`openid`),
  KEY `issystem` (`issystem`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_scan`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_scan`;
CREATE TABLE `hc_wechat_scan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scan` varchar(65) NOT NULL DEFAULT '' COMMENT '场景',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0永久,1临时',
  `expire_time` char(7) NOT NULL DEFAULT '0' COMMENT '二维码有效时间',
  `ticket` varchar(150) NOT NULL DEFAULT '',
  `remarks` varchar(255) NOT NULL DEFAULT '' COMMENT '场景备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hc_wechat_user`
-- -----------------------------
DROP TABLE IF EXISTS `hc_wechat_user`;
CREATE TABLE `hc_wechat_user` (
  `wechatid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `openid` char(100) NOT NULL DEFAULT '',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `subscribe` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1关注0取消',
  `nickname` varchar(50) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `city` char(50) NOT NULL DEFAULT '',
  `province` char(50) NOT NULL DEFAULT '',
  `country` char(50) NOT NULL DEFAULT '',
  `headimgurl` char(255) NOT NULL DEFAULT '',
  `subscribe_time` int(10) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(50) NOT NULL DEFAULT '',
  `scan` varchar(30) NOT NULL DEFAULT '' COMMENT '来源场景',
  PRIMARY KEY (`wechatid`),
  UNIQUE KEY `openid` (`openid`),
  KEY `groupid` (`groupid`),
  KEY `subscribe` (`subscribe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

